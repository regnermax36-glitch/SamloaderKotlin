# Valhalla — Noob-Friendly Setup & Usage Guide

This guide explains how to use **`main.py`** and the other scripts inside this project in a simple, beginner-friendly way.

The main idea is very simple:

> **Run `main.py` first.**  
> Do **not** start random scripts directly unless you know what they do.

---

## What is inside this project?

This package contains a launcher and several tools:

- **`main.py`** → the main launcher / hub
- **`intelligence_v102.py`** → scanning / reconnaissance tool
- **`logistics_v150.py`** → download, queue, operations, and workflow tool
- **`decrypter10.py`** → decrypt/build-finding tool
- **`valhalla_fus.py`** → FUS scan/download tool
- **`valhalla_themes.py`** → theme / visuals support
- **`FotaAgent/`** → backend library used by the scripts
- **`requirements.txt`** → Python dependencies

So for normal users:

## Start with `main.py`

---

## Recommended folder structure

After extracting the ZIP, keep all these files in the **same project folder**:

- `main.py`
- `intelligence_v102.py`
- `logistics_v150.py`
- `decrypter10.py`
- `valhalla_fus.py`
- `valhalla_themes.py`
- `requirements.txt`
- `FotaAgent/`

Do **not** move `main.py` somewhere else by itself.

---

# 1) Install Python and dependencies

## Linux

```bash
sudo apt update
sudo apt install python3 python3-pip -y
```

Then go into the extracted project folder and install requirements:

```bash
cd /path/to/Valhalla
pip install -r requirements.txt
```

---

## Termux

Install the common required packages first:

```bash
pkg update && pkg upgrade -y
pkg install python libxml2 libxslt openssl -y
```

Then install Python requirements:

```bash
cd /path/to/Valhalla
pip install -r requirements.txt
```

If `pip install -r requirements.txt` fails on your device, try this manual fallback:

```bash
pip uninstall crypto pycrypto pycryptodome -y
pip install requests pycryptodome pycryptodomex google-api-python-client google-auth google-auth-oauthlib google-auth-httplib2 rich inquirerpy psutil lxml urllib3
```

---

# 2) Go into the project folder

Examples:

## Linux

```bash
cd /path/to/Valhalla
```

## Termux

```bash
cd /sdcard/Valhalla
```

Use the real path where **you extracted the files**.

---

# 3) Start the project

Run:

```bash
python3 main.py
```

This opens the **main Valhalla launcher**.

---

# 4) What each menu/tool does

When you start `main.py`, you will see the main modules.

## HUGIN (Intelligence)
Use this when you want:
- scanning
- reconnaissance
- checking information/history
- model + region based checks

Good for people who want to inspect or search before downloading.

### Beginner use:
1. Open **HUGIN**
2. Choose the scanning/recon option
3. Enter model
4. Enter region/CSC
5. Let it run

---

## SLEIPNIR (Logistics)
Use this when you want:
- downloads
- operations flow
- queues
- timelines/history
- more advanced workflow handling

This is a more advanced module.

### Beginner use:
1. Open **SLEIPNIR**
2. Choose **START OPERATIONS**
3. Enter the requested model / CSC / version info
4. Let it process

If you are new, do not worry about queues or advanced options yet.

---

## MIMIR (Decrypter)
Use this when you want:
- decrypt builds
- discover build versions
- find firmware/build data

This is one of the easiest modules for beginners.

### Beginner use:
1. Open **MIMIR**
2. Choose **Single Decrypt**
3. Enter model
4. Enter CSC/region
5. Wait for the result

---

## ODIN (FUS Downloader)
Use this when you want:
- FUS scan
- FUS firmware download
- manual firmware input if needed

This is the easiest module for people who mainly want firmware downloads.

### Beginner use:
1. Open **ODIN**
2. Choose **Scan & Download**
3. Enter model
4. Enter region/CSC
5. Pick a firmware if shown
6. Start the download

### Advanced use:
Use **Manual Input (Force)** only if you already know the exact firmware/version details.

---

## BIFROST (Visuals)
Use this only for:
- theme selection
- banner style
- visual customization

It does not affect the core scanning/downloading logic.

---

# 5) Best beginner workflow

If someone is totally new, tell them to use one of these simple paths.

## Option A — easiest start
If they just want to test the app:

1. Run `python3 main.py`
2. Open **MIMIR**
3. Use **Single Decrypt**
4. Enter model + CSC
5. Learn the output first

---

## Option B — easiest firmware workflow
If they mainly want firmware download:

1. Run `python3 main.py`
2. Open **ODIN**
3. Use **Scan & Download**
4. Enter model + region
5. Pick firmware
6. Start download

---

## Option C — advanced usage
If they want the full power features:

1. Run `python3 main.py`
2. Open **SLEIPNIR**
3. Use **START OPERATIONS**
4. Learn queue/history/settings later

---

# 6) Simple rule for beginners

If you are confused, follow this:

- **Want to start the project?** → run `python3 main.py`
- **Want to decrypt builds?** → use **MIMIR**
- **Want to scan/download firmware from FUS?** → use **ODIN**
- **Want scanning/recon tools?** → use **HUGIN**
- **Want advanced operations/download handling?** → use **SLEIPNIR**
- **Want to change colors/theme?** → use **BIFROST**

---

# 7) Do I need `config.json`?

For **basic use**, usually **no**.

A beginner can often test the project without worrying about advanced config.

The extra config matters more for things like:
- Telegram integration
- Google Drive integration
- custom upload behavior
- advanced automation/workflow settings

So for beginners:

## Ignore advanced config at first
Test these first:
- `main.py`
- **MIMIR**
- **ODIN**

Only set up advanced config after the basic tools are working.

---

# 8) Optional starter config idea

If you later want a simple starter config, something like this is the kind of setup beginners can use as a base:

```json
{
  "theme": "VALHALLA",
  "banner": "TYR",
  "telegram": {
    "enabled": false,
    "bot_token": "",
    "chat_id": ""
  },
  "drive": {
    "enabled": false,
    "master_folder_id": "",
    "credentials_file": "credentials.json",
    "token_file": "token.pickle"
  },
  "download": {
    "use_aria2": true
  },
  "proxies": [],
  "agent_id": "VALHALLA"
}
```

This is just a starter example. Exact behavior depends on how your local setup is arranged.

---

# 9) Can I run the other scripts directly?

Yes, but most users **should not** do that unless debugging or testing a specific tool.

## Direct run commands

### Run the decrypter directly
```bash
python3 decrypter10.py
```

### Run the FUS tool directly
```bash
python3 valhalla_fus.py
```

### Run the intelligence tool directly
```bash
python3 intelligence_v102.py
```

### Run the logistics tool directly
```bash
python3 logistics_v150.py
```

Still, the recommended way is:

## Always start with `python3 main.py`

---

# 10) Common beginner mistakes and fixes

## Problem: running from the wrong folder
If imports fail or files cannot be found, you are probably in the wrong directory.

### Fix
```bash
cd /path/to/Valhalla
python3 main.py
```

---

## Problem: missing Python packages
Errors may mention modules like:
- `rich`
- `InquirerPy`
- `lxml`
- `google-auth`

### Fix
```bash
pip install -r requirements.txt
```

---

## Problem: `FotaAgent` folder missing
Some modules depend on `FotaAgent/`.

### Fix
Make sure the extracted folder still contains:

```text
FotaAgent/
```

Do not delete it.

---

## Problem: Termux install issues
If XML/crypto-related things fail, install base Termux packages first:

```bash
pkg install python libxml2 libxslt openssl -y
```

Then retry:

```bash
pip install -r requirements.txt
```

---

## Problem: Google Drive features do not work
Usually this means:
- no `credentials.json`
- no `token.pickle`
- Drive integration not configured yet

### Fix
Ignore Drive at first. Get the basic tools working before setting it up.

---

## Problem: Telegram features do not work
Usually this means:
- Telegram bot token not configured
- chat ID not set
- Telegram integration disabled

### Fix
Ignore Telegram at first. Set it up only after local scanning/decrypting works properly.

---

# 11) Friend-proof quick start

If you want the absolute simplest instructions for friends, send them this:

## Linux / Termux quick start

```bash
cd /path/to/Valhalla
pip install -r requirements.txt
python3 main.py
```

For Termux, if needed:

```bash
pkg update && pkg upgrade -y
pkg install python libxml2 libxslt openssl -y
cd /path/to/Valhalla
pip install -r requirements.txt
python3 main.py
```

---

# 12) What beginners should do first inside the app

Recommended order:

1. **MIMIR** → easiest way to test build decrypting
2. **ODIN** → easiest way to test FUS scan/download
3. **HUGIN** → when they want more scanning/recon
4. **SLEIPNIR** → once they understand the basics
5. **BIFROST** → only for visuals/themes

---

# 13) One-line summary

> Extract the project, install requirements, run `python3 main.py`, and start with **MIMIR** or **ODIN** if you are new.

---

# 14) Mini version for sharing in chat

```text
1. Extract the Valhalla files.
2. Open terminal in that folder.
3. Install requirements:
   pip install -r requirements.txt
4. Run:
   python3 main.py

Use:
- MIMIR = decrypt builds
- ODIN = FUS scan/download
- HUGIN = intelligence scan
- SLEIPNIR = advanced operations
- BIFROST = themes/visuals

If you are new, start with MIMIR or ODIN.
```

---

# 15) Final advice

For new users, do **not** overcomplicate things.

Start small:
- get the project running
- test `main.py`
- try **MIMIR**
- then try **ODIN**
- only move into advanced tools after that

That is the smoothest beginner path.
