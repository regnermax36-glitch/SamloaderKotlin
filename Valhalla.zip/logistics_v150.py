import os
import sys
import json
import time
import random
import shutil
import subprocess
import threading
import sqlite3
import glob
import pickle
import logging
import requests
import socket
import zipfile
import re
import csv
import base64
import urllib.parse
from requests.adapters import HTTPAdapter
from urllib3.util.retry import Retry
import xml.etree.ElementTree as ET
from concurrent.futures import ThreadPoolExecutor, as_completed
from collections import defaultdict, deque

# --- IMPORTS ---
import urllib3
from rich.console import Console
from rich.theme import Theme
from rich.table import Table
from rich.panel import Panel
from rich.text import Text
from rich.align import Align
from rich.progress import (
    Progress, SpinnerColumn, BarColumn, TextColumn, 
    TransferSpeedColumn, TimeRemainingColumn
)

# -----------------------------
# Valhalla theme bootstrap
# -----------------------------
# Ensure theme constants exist even when this module is run standalone.
try:
    from valhalla_themes import get_runtime_theme
    _VT = get_runtime_theme()
    C_PRIM = _VT.C_PRIM
    C_SEC = _VT.C_SEC
    C_ACC = _VT.C_ACC
    C_DIM = _VT.C_DIM
    C_OK = _VT.C_OK
    C_ERR = _VT.C_ERR
    C_TEXT = _VT.C_TEXT
    C_BORDER = getattr(_VT, "C_BORDER", "#8A8A8A")
    # Legacy aliases used in some UI blocks
    C_GOLD = getattr(_VT, "C_GOLD", C_PRIM)
    C_BLUE = getattr(_VT, "C_BLUE", C_ACC)
    C_STEEL = getattr(_VT, "C_STEEL", C_SEC)
    MENU_STYLE = getattr(_VT, "MENU_STYLE", None)
except Exception:
    # Safe fallbacks (pastel-ish)
    C_PRIM = "#d6b24b"
    C_SEC = "#a8a8a8"
    C_ACC = "#6c9cd4"
    C_ERR = "#d46c6c"
    C_OK = "#87d787"
    C_DIM = "#585858"
    C_BORDER = "#8a8a8a"
    C_TEXT = "#eeeeee"
    C_GOLD, C_BLUE, C_STEEL = C_PRIM, C_ACC, C_SEC
    MENU_STYLE = None
from rich import box
from InquirerPy import inquirer
from InquirerPy.base.control import Choice
from InquirerPy.separator import Separator
from InquirerPy.utils import get_style

try:
    from rich.group import Group
except ImportError:
    from rich.console import Group

# Disable Logging & Set Global Timeout
urllib3.disable_warnings(urllib3.exceptions.InsecureRequestWarning)
logging.getLogger().setLevel(logging.CRITICAL)
socket.setdefaulttimeout(600) 
# Valhalla Rich theme (keeps Progress bars/percent/speed on theme colors across Rich versions)
_VALHALLA_RICH_THEME = Theme({
    'bar.complete': C_PRIM,
    'bar.finished': C_OK,
    'bar.back': C_DIM,
    'progress.percentage': C_PRIM,
    'progress.data.speed': C_ACC,
    'progress.spinner': C_ACC,
})

console = Console(theme=_VALHALLA_RICH_THEME, highlight=False)
# ------------------------------------------------------------------
# THEME (from config.json via valhalla_themes.py)
# ------------------------------------------------------------------
try:
    from valhalla_themes import get_runtime_theme, render_header
    _THEME = get_runtime_theme(os.path.join(os.path.dirname(os.path.abspath(__file__)), "config.json"))
except Exception:
    _THEME = None

C_PRIM = getattr(_THEME, "C_PRIM", "#dab900")
C_SEC = getattr(_THEME, "C_SEC", "#a8a8a8")
C_ACC = getattr(_THEME, "C_ACC", "#6c9cd4")
C_ERR = getattr(_THEME, "C_ERR", "#d46c6c")
C_OK = getattr(_THEME, "C_OK", "#87d787")
C_DIM = getattr(_THEME, "C_DIM", "#585858")
C_BORDER = getattr(_THEME, "C_BORDER", "#8a8a8a")
C_TEXT = getattr(_THEME, "C_TEXT", "#eeeeee")

# Legacy aliases (some older blocks may still reference)
C_GOLD = getattr(_THEME, "C_GOLD", C_PRIM)
C_BLUE = getattr(_THEME, "C_BLUE", C_ACC)
C_STEEL = getattr(_THEME, "C_STEEL", C_SEC)

# Menu style (hide '?')
MENU_STYLE = getattr(_THEME, "MENU_STYLE", None)
if MENU_STYLE is None:
    MENU_STYLE = get_style({
        "questionmark": "hidden",
        "question": C_TEXT,
        "pointer": f"{C_PRIM} bold",
        "highlight": f"{C_PRIM} bold",
        "answer": C_PRIM,
        "input": C_PRIM,
        "validator": C_ERR,
    }, style_override=False)

# Legacy aliases (some older blocks may still reference these)
C_GOLD = getattr(_THEME, "C_GOLD", C_PRIM)
C_BLUE = getattr(_THEME, "C_BLUE", C_ACC)
C_STEEL = getattr(_THEME, "C_STEEL", C_SEC)

# --- RUNESTONES (ICONS) ---
R = {
    "header": "ᚱ",  # Raido (Journey)
    "guard": "ᛉ",   # Algiz (Protection)
    "cycle": "ᛃ",   # Jera (Queue/Cycle)
    "gate": "ᚦ",    # Thurisaz (Gateway)
    "star": "ᛋ",    # Sowilo (Success/Start)
    "man": "ᛗ",     # Mannaz (User)
    "gift": "ᚷ",    # Gebo (Exit/Gift)
    "tree": "ᛦ",    # Yr (Tree/History)
    "search": "ᛈ",  # Perthro (Search/Info)
    "law": "ᛏ",     # Tiwaz (Config)
    "wealth": "ᛠ",  # Ear (Database)
    "delta": "ᛞ",   # Dagaz (Change)
    "base": "ᛒ",    # Berkano (Base/Internal)
    "joy": "ᚹ",     # Wunjo (Download/Success)
    "back": "ᛇ",    # Eihwaz (Back/Defense)
}

# --- MENU THEME ---
MENU_STYLE = get_style({
    "questionmark": "hidden",
    "question": "#eeeeee",
    "pointer": "#dab900 bold",
    "highlight": "#dab900 bold",
    "answer": "#dab900",
    "input": "#dab900",
    "validator": "#d46c6c",
}, style_override=False)

# --- GLOBAL STATES ---
ban_lock = threading.Lock()
last_ban_time = 0
session_stats = {"uploaded": 0, "failed": 0, "volume": 0}
job_queue = deque()

# ==============================================================================
# 1. CONTINUUM SERVICE
# ==============================================================================
class Continuum:
    FILE_PATH = "database/continuum_state.json"

    @staticmethod
    def load():
        if os.path.exists(Continuum.FILE_PATH):
            try:
                with open(Continuum.FILE_PATH, 'r') as f: return json.load(f)
            except: return {}
        return {}

    @staticmethod
    def save(data):
        os.makedirs("database", exist_ok=True)
        with open(Continuum.FILE_PATH, 'w') as f: json.dump(data, f, indent=2)

    @staticmethod
    def update_entry(model, csc, latest_found):
        data = Continuum.load()
        key = f"{model}_{csc}"
        data[key] = {
            "model": model,
            "csc": csc,
            "last_check": time.time(),
            "frontier": latest_found
        }
        Continuum.save(data)

    @staticmethod
    def get_stale_targets(hours=20):
        data = Continuum.load()
        stale = []
        now = time.time()
        for k, v in data.items():
            if now - v.get("last_check", 0) > (hours * 3600):
                stale.append(v)
        return stale

# ==============================================================================
# 2. CONFIGURATION
# ==============================================================================
class Config:
    DIR_JSON        = "jsons"       
    DIR_DECRYPTED   = "Decrypted"   
    DIR_DB          = "database"
    DIR_DOWN        = "Downloads"
    DB_FILE         = "fumo_history.db"
    BLACKBOX_FILE   = "blackbox.json" 
    
    # [NEW] Identity System Default
    AGENT_ID        = "VALHALLA" 
    
    TG_ENABLED      = False
    TG_TOKEN        = ""
    TG_CHAT_ID      = ""
    
    DRIVE_ENABLED   = False
    DRIVE_MASTER_ID = ""
    CREDENTIALS     = "credentials.json"
    TOKEN           = "token.pickle"
    DRIVE_CLIENT_CONFIG = None 
    
    DRIVE_ACTIVE_STATE = False 
    USER_AGENT      = "SAMSUNG-Android"
    FOTA_URL_BASE   = "https://fota-cloud-dn.ospserver.net/firmware"
    
    DELETE_LOCAL_AFTER_UPLOAD = "YES" 
    ALLOW_DM_BUILDS = True           
    MAX_THREADS     = 2  
    USE_ARIA2       = True            
    PROXIES         = []
    STEALTH_MODE    = True
    UPLOAD_CHUNK_SIZE = 64 * 1024 * 1024
    VERIFY_ZIP      = True 

    UA_POOL = [
        "SAMSUNG-Android/14 (SM-S928B; S928BXXU1AWM9)",
        "SAMSUNG-Android/13 (SM-F946B; F946BXXU1CWL1)",
        "SAMSUNG-Android/14 (SM-S918B; S918BXXS3BWK5)",
        "SAMSUNG-Android/15 (SM-S938B; S938BXXU1AWM9)"
    ]

    CSC_MAP = {
        "OYN": ["VZW", "TMB", "ATT", "USC", "CCT", "CHA", "DSH", "SPR", "XAA", "AIO", "BST", "XAS"],
        "OYM": ["XAA", "VZW", "TMB", "ATT", "USC", "DSA", "DSG", "LRA", "ACG", "FKR"],
        "OXM": ["EUX", "EUY", "EUB", "DBT", "BTU", "ITV", "XEF", "XEU", "XEZ", "ROM", "SEE", "AUT", "PHN", "LUX", "NEE", "ATO", "SEB", "BGL", "ORX", "EUR", "AMO", "FTM", "OPV", "XEC", "BOG", "MOT", "MEO", "SFR", "PRT", "TPH", "XEH", "OXM", "VDF", "VIP", "CNX", "COA", "ORO", "TSR", "SIM", "CRO", "TRA", "TOP", "MSR", "SWC", "VDI", "EIR", "H3G", "O2U", "VOD", "EVR", "CPW", "BTB", "BTE", "EVR"],
        "OXE": ["SER", "CAU", "SKZ", "SEK", "CAC", "UZB", "KZK", "RUC"],
        "OJM": ["KSA", "UAE", "MID", "EGY", "PAK", "TUR", "AFR", "KEN", "TUN", "MEA", "LYS", "ACR", "AFG", "MWD", "FWD", "TUR", "KSA", "UAE", "MID", "EGY", "PAK", "TUN", "MRT", "ALG", "XFA", "XFE", "XFV", "DKR", "ECT", "EON", "FAU", "JDI", "OJV", "OJ1", "ILP", "ILO", "XSG", "INS", "INU", "NPL", "SLK", "BNG"],
        "OLM": ["XXV", "THL", "XID", "SIN", "STH", "GLB", "SMA", "XTE", "XME", "CAL", "MM1", "MYM", "LAO", "CAM", "NPL", "SLK", "BNG", "BKD", "INS", "INU", "NPB", "OLM", "XSP", "XTC", "ATC", "XNZ", "TNZ", "VNZ", "XSA", "OPS", "TEL", "VAU", "HUT"],
        "OWO": ["ZTO", "BVO", "ARO", "COO", "CHO", "PEO", "TPA", "MXO", "GTO", "BOG", "EON", "UPO", "ZTA", "MVL", "GTO", "GTG", "TIG", "CTI", "UFN", "PSN", "XAA", "VZW", "TMB", "ATT", "USC", "DSA", "DSG", "LRA", "ACG", "FKR", "SPR", "DSH", "XAC", "RWC", "TLS", "BWA", "FMC", "VTR", "BMC", "KDO"],
        "OKR": ["KOO", "SKC", "LUC", "KTC"],
        "IND": ["INS", "INU"]
    }

    @staticmethod
    def load_config():
        if os.path.exists("config.json"):
            try:
                with open("config.json", "r") as f:
                    data = json.load(f)
                    tg = data.get("telegram", {})
                    Config.TG_ENABLED = tg.get("enabled", False)
                    Config.TG_TOKEN = tg.get("bot_token", "")
                    Config.TG_CHAT_ID = tg.get("chat_id", "")
                    dr = data.get("drive", {})
                    Config.DRIVE_ENABLED = dr.get("enabled", False)
                    Config.DRIVE_MASTER_ID = dr.get("master_folder_id", "")
                    Config.CREDENTIALS = dr.get("credentials_file", "credentials.json")
                    Config.TOKEN = dr.get("token_file", "token.pickle")
                    Config.DRIVE_CLIENT_CONFIG = dr.get("client_config", None)
                    dl = data.get("download", {})
                    Config.USE_ARIA2 = dl.get("use_aria2", True)
                    Config.PROXIES = data.get("proxies", [])
                    
                    # [UPDATED] Load Persistent Identity
                    Config.AGENT_ID = data.get("agent_id", "VALHALLA")
                    
            except Exception as e: print(f"Config Load Error: {e}")

Config.load_config()

# ==============================================================================
# 3. UTILITIES
# ==============================================================================
class Utils:
    @staticmethod
    def normalize_model(m):
        m = m.strip().upper()
        return m if m.startswith("SM-") else f"SM-{m}"
    
    @staticmethod
    def bare_model(m): return m.replace("SM-", "").strip().upper()

    @staticmethod
    def split_model_variant(full):
        bare = full.replace("SM-", "").upper()
        return (bare[:4], bare[4:]) if len(bare) > 4 else (bare, "")
        
    @staticmethod
    def extract_safe_suffix(v): 
        # Extracts just the last 4 chars (Build) or Safe Suffix
        if not v: return ""
        v = str(v).replace(".DM", "").strip().upper()
        if "/" in v: v = v.split("/")[0]
        return v[-5:] if len(v) >= 5 else v

    @staticmethod
    def get_multi_csc_info(csc, model=""):
        csc = csc.upper()
        model_u = model.strip().upper()
        
        if model_u.endswith("U1") and csc in Config.CSC_MAP["OYM"]: return "OYM", Config.CSC_MAP["OYM"]
        if model_u.endswith("U") and not model_u.endswith("EU") and csc in Config.CSC_MAP["OYN"]: return "OYN", Config.CSC_MAP["OYN"]
        if model_u.endswith("0"): return csc, [csc]
        
        for group in ["OJM", "OLM", "OWO", "OXE", "IND"]:
            if csc in Config.CSC_MAP.get(group, []): return group, Config.CSC_MAP[group]
        
        if model_u.endswith("B") and csc in Config.CSC_MAP["OXM"]: return "OXM", Config.CSC_MAP["OXM"]
        return csc, [csc]
        
    @staticmethod
    def generate_filename(model, csc, src, tgt, is_dm=False):
        full = Utils.normalize_model(model)
        s, t = Utils.extract_safe_suffix(src), Utils.extract_safe_suffix(tgt)
        
        # [FIX] Priority 1: Extract actual Multi-CSC from the Triplet String (Middle Component)
        # This ensures that if we scan KSA (OJM) but get an OXM build, it saves as OXM.
        multi = None
        
        def extract_real_csc(ver_string):
            if not ver_string or "/" not in str(ver_string): return None
            try:
                # Triplet format: AP/CSC/CP or AP/CSC/MODEM/CP
                parts = str(ver_string).split('/')
                if len(parts) >= 2:
                    middle = parts[1].upper() # e.g. S721BOXM8CYL1
                    # Search for known Multi-CSC codes inside this string
                    for known_group in Config.CSC_MAP.keys():
                        if len(known_group) == 3 and known_group in middle:
                            return known_group
            except: pass
            return None

        # Check Target first (most accurate), then Source
        multi = extract_real_csc(tgt)
        if not multi:
            multi = extract_real_csc(src)

        # Priority 2: Fallback to Region-Based Inference if triplet parsing failed
        if not multi:
            multi_name, _ = Utils.get_multi_csc_info(csc, model=full)
            if multi_name:
                multi = multi_name
            else:
                # Priority 3: Hard Fallbacks based on Model Suffix
                if full.endswith("B"): multi = "OXM"
                elif full.endswith("U"): multi = "OYN"
                elif full.endswith("U1"): multi = "OYM"
                elif full.endswith("W"): multi = "OYA"
                elif full.endswith("N"): multi = "OKR"
                elif full.endswith("0"): multi = csc 
                else: multi = csc
        
        fname = f"{full}_{multi}_{s}_{t}.zip"
        return fname.replace(".zip", ".DM.zip") if is_dm else fname

    @staticmethod
    def generate_imei(): return "35" + str(random.randint(1000000000000, 9999999999999))
    
    @staticmethod
    def readable_size(size_in_bytes):
        try:
            s = int(size_in_bytes)
            for u in ['B', 'KB', 'MB', 'GB', 'TB']:
                if s < 1024: return f"{s:.2f} {u}"
                s /= 1024
            return f"{s:.2f} PB"
        except: return "Unknown"
    
    @staticmethod
    def get_date_score(version_str):
        try:
            safe = Utils.extract_safe_suffix(version_str)
            if len(safe) < 4: return 0
            y_char = safe[-3]; m_char = safe[-2]
            years = {'R':2019, 'S':2020, 'T':2021, 'U':2022, 'V':2023, 'W':2023, 'X':2024, 'Y':2025, 'Z':2026}
            months = {'A':1, 'B':2, 'C':3, 'D':4, 'E':5, 'F':6, 'G':7, 'H':8, 'I':9, 'J':10, 'K':11, 'L':12}
            yr = years.get(y_char, 0); mn = months.get(m_char, 0)
            if yr and mn: return int(f"{yr}{mn:02d}")
            return 0
        except: return 0

    @staticmethod
    def decode_date(version_str):
        s = Utils.get_date_score(version_str)
        if s == 0: return "-"
        s_str = str(s)
        try: return f"{['','Jan','Feb','Mar','Apr','May','Jun','Jul','Aug','Sep','Oct','Nov','Dec'][int(s_str[4:])]} {s_str[:4]}"
        except: return s_str[:4]

    @staticmethod
    def handle_ban_wait(e):
        global last_ban_time
        with ban_lock:
            if time.time() - last_ban_time < 15: time.sleep(2); return
            Dashboard.show_ban_warning(str(e))
            time.sleep(15); last_ban_time = time.time()
            
    @staticmethod
    def get_known_versions(model, target_group=None):
        """
        Smart Database Fetcher v160 (STRICT ISOLATION)
        Prevents Cross-Region Contamination (e.g., OWO builds in OXM scans).
        """
        full_model = Utils.normalize_model(model)
        short_model = full_model.replace("SM-", "").upper()
        
        base_core = short_model
        exact_suffix = ""
        if short_model.endswith("U1"):
            base_core = short_model[:-2]; exact_suffix = "U1"
        elif len(short_model) > 3:
            base_core = short_model[:-1]; exact_suffix = short_model[-1]

        allowed_cscs = []
        if target_group:
            if target_group in Config.CSC_MAP: allowed_cscs = Config.CSC_MAP[target_group]
            else: allowed_cscs = [target_group]

        forbidden_tags = []
        
        # [CRITICAL SECURITY] Major Group Isolation
        # If targeting OXM, we strictly ban OWO, OJM, etc. regardless of device type.
        major_groups = ["OXM", "OYN", "OYM", "OWO", "OXE", "OJM", "OLM", "IND"]
        
        if target_group and target_group in major_groups:
            # Block all other major groups
            forbidden_tags.extend([g for g in major_groups if g != target_group])
        
        # [HARDWARE WALLS]
        if exact_suffix == "0": # China Hardware
            forbidden_tags.extend(["OXM", "OYN", "OYM", "OWO", "OXE", "OJM", "OLM", "IND", "EUR"])
            
        elif exact_suffix in ["U", "U1", "W", "N"]: # US/Korea Hardware
            # These are already handled by major_groups logic above, but we double down here
            if target_group and target_group in major_groups:
                forbidden_tags.extend([g for g in major_groups if g != target_group])

        # Deduplicate tags
        forbidden_tags = list(set(forbidden_tags))

        candidates = set()
        
        # We search for ALL files initially, but filter aggressively below
        search_pattern = f"*{base_core}*.json"
        files = glob.glob(os.path.join(Config.DIR_JSON, search_pattern)) + \
                glob.glob(os.path.join(Config.DIR_DECRYPTED, search_pattern))
        
        for f in files:
            fname = os.path.basename(f).upper()
            
            # --- FILTER A: SUFFIX SAFETY ---
            if exact_suffix == "U" and "U1" in fname: continue
            if exact_suffix == "U1" and "U1" not in fname: continue

            # --- FILTER B: TAG SAFETY (FILE LEVEL) ---
            # If the filename itself contains a forbidden group (e.g. "_OWO.json"), skip it.
            is_file_bad = False
            for bad in forbidden_tags:
                # We check for boundaries so we don't accidentally match substrings
                if f"_{bad}_" in fname or f"_{bad}." in fname: 
                    is_file_bad = True; break
            if is_file_bad: continue

            # --- FILTER C: CONTENT SAFETY ---
            try:
                with open(f, 'r') as fd: data = json.load(fd)
                items = data if isinstance(data, list) else data.get("firmwares") or data.get("latest_firmwares") or []
                
                for item in items:
                    v = item if isinstance(item, str) else item.get("version") or item.get("triplet", "")
                    if not v or len(v) < 8: continue
                    v_upper = v.upper()

                    if short_model not in v_upper: continue
                    if exact_suffix == "U" and f"{base_core}U1" in v_upper: continue
                    
                    # Strict CHC vs HK
                    if exact_suffix == "0":
                        if "CHC" in allowed_cscs and "OZS" in v_upper: continue
                        if any(c in ["TGY", "BRI"] for c in allowed_cscs) and "CHC" in v_upper: continue

                    # --- FILTER D: TAG SAFETY (VERSION LEVEL) ---
                    # Check the actual version string for forbidden groups
                    is_triplet_bad = False
                    for bad in forbidden_tags:
                        if bad in v_upper: is_triplet_bad = True; break
                    
                    if is_triplet_bad: continue

                    candidates.add(v)
            except: continue
            
        return sorted(list(candidates), key=lambda x: Utils.get_date_score(x), reverse=True)


    @staticmethod
    def get_random_ua():
        """Returns a random User-Agent from the pool."""
        return random.choice(Config.UA_POOL)

    @staticmethod
    def test_samsung_server():
        """Pings Samsung FOTA server to check connectivity."""
        try:
            requests.head("https://fota-cloud-dn.ospserver.net", timeout=5, verify=False)
            return True
        except:
            return False

    @staticmethod
    def check_storage():
        """Checks for low disk space (under 5GB warning)."""
        try:
            if shutil.disk_usage(".")[2] // (2**30) < 5:
                console.print(f"[{C_ERR}]CRITICAL: Low Disk Space. Pausing...[/]")
                input("Clear space and press Enter...")
                return True
            return True
        except:
            return True

    @staticmethod
    def verify_zip(filepath):
        """Verifies zip integrity to prevent corrupt downloads."""
        if not Config.VERIFY_ZIP: return True
        try:
            with zipfile.ZipFile(filepath) as zf:
                return zf.testzip() is None
        except:
            return False

# ==============================================================================
# 4. UI SYSTEM
# ==============================================================================
class Dashboard:
    @staticmethod
    def header():
        logo_ascii = r"""
   [ P R O J E C T ]

 █▄▀ █ █   █   █▀▀ █ █ █▀█ ▀█▀
 █ █ █ █▄▄ █▄▄ ▄█▀ █▀█ █▄█  █

               >---( ✛ )---<
""".strip("\n")

        tg_ok = bool(Config.TG_ENABLED and Config.TG_TOKEN)
        dr_ok = bool(Config.DRIVE_ACTIVE_STATE)
        q_len = len(job_queue)

        if _THEME is not None and 'render_header' in globals():
            render_header(
                console,
                _THEME,
                module_name="LOGISTICS ᚡ150",
                subtitle="COMMAND CENTER",
                right_rows=(("TIME", time.strftime('%Y-%m-%d %H:%M:%S')),),
                badge_rows=(
                    ("TELEGRAM ᛇ", "ONLINE" if tg_ok else "OFFLINE", C_OK if tg_ok else C_ERR),
                    ("G-DRIVE ᛃ", "LINKED" if dr_ok else "UNLINKED", C_OK if dr_ok else C_ERR),
                    ("NIGHT SHIFT ᚦ", f"{q_len} FILES" if q_len > 0 else "EMPTY", C_OK if q_len > 0 else C_DIM),
                ),
                logo_override=logo_ascii,
                clear=True,
            )
            return

        # Fallback (old header)
        print("\033c", end="")
        os.system('cls' if os.name == 'nt' else 'clear')
        logo = Text(logo_ascii, style=f"bold {C_PRIM}")
        grid = Table.grid(expand=True, padding=(0, 2))
        grid.add_column(justify="center", ratio=1)
        grid.add_column(justify="center", ratio=1)
        grid.add_column(justify="center", ratio=1)
        tg_s = f"[bold {C_OK}]ONLINE[/]" if tg_ok else f"[dim {C_ERR}]OFFLINE[/]"
        dr_s = f"[bold {C_OK}]LINKED[/]" if dr_ok else f"[dim {C_ERR}]UNLINKED[/]"
        q_s = f"[bold {C_OK}]{q_len} FILES[/]" if q_len > 0 else f"[dim]EMPTY[/]"
        grid.add_row(
            f"[bold {C_TEXT}]TELEGRAM ᛇ[/]\n{tg_s}",
            f"[bold {C_TEXT}]G-DRIVE ᛃ[/]\n{dr_s}",
            f"[bold {C_TEXT}]NIGHT SHIFT ᚦ[/]\n{q_s}",
        )
        console.print(Align.center(logo))
        console.print(Align.center(f"[bold {C_SEC}]LOGISTICS[/] [bold {C_ACC}]ᚡ150[/] [dim]//[/] [bold {C_PRIM}]COMMAND CENTER[/]"))
        console.print(Panel(grid, border_style=C_BORDER, padding=(0, 0)))
        console.print()
        
    @staticmethod
    def show_ban_warning(error_msg):
        console.print()
        panel = Panel(
            Align.center(
                f"[bold {C_ERR}]ᛦ CONNECTION SEVERED ᛦ[/]\n"
                f"[{C_ACC}]Error: {error_msg}[/]\n\n"
                f"[bold {C_TEXT}]Waiting for Network Restoration...[/]\n"
                f"[bold {C_OK}]>>> TOGGLE VPN NOW - AUTO RESUME <<<[/]\n"
            ),
            title=f"[bold {C_ERR}]NETWORK PAUSE[/]",
            border_style=C_ERR,
            box=box.HEAVY
        )
        console.print(panel)

    @staticmethod
    def show_success_card(fname, link, size, cached=False):
        color = C_OK if cached else C_PRIM
        title = "CACHE HIT" if cached else "UPLOAD SUCCESS"
        icon = R['wealth'] if cached else R['joy']
        
        content = Table.grid(expand=True, padding=(0, 1))
        content.add_column(style=f"bold {C_TEXT}", width=10)
        content.add_column(style=f"{C_PRIM}")
        content.add_row("FILE", fname)
        content.add_row("SIZE", size)
        
        footer = f"[link={link}]ᚱ CLICK TO OPEN DRIVE LINK[/]" if link and "http" in str(link) else f"[{C_ERR}]ᚷ Upload Failed (Local Save Only)[/]"

        console.print(Panel(Group(content, Text("─"*40, style=C_DIM), Align.center(footer)), title=f"[bold {color}]{icon} {title}[/]", border_style=color, box=box.ROUNDED))

class DriveService:
    def __init__(self):
        self.service = None
        self.is_active = False
        if Config.DRIVE_ENABLED: self._auth()
        Config.DRIVE_ACTIVE_STATE = self.is_active

    def _auth(self):
        try:
            from googleapiclient.discovery import build
            from google_auth_oauthlib.flow import InstalledAppFlow
            from google.auth.transport.requests import Request
            creds = None
            if os.path.exists(Config.TOKEN):
                try: 
                    with open(Config.TOKEN, 'rb') as token: creds = pickle.load(token)
                except: os.remove(Config.TOKEN)

            if not creds or not creds.valid:
                if creds and creds.expired and creds.refresh_token:
                    try: creds.refresh(Request())
                    except: pass
                
                if not creds:
                    if Config.DRIVE_CLIENT_CONFIG:
                        flow = InstalledAppFlow.from_client_config(Config.DRIVE_CLIENT_CONFIG, ['https://www.googleapis.com/auth/drive'])
                        creds = flow.run_local_server(port=8080, open_browser=False)
                        with open(Config.TOKEN, 'wb') as token: pickle.dump(creds, token)
                    elif os.path.exists(Config.CREDENTIALS):
                        flow = InstalledAppFlow.from_client_secrets_file(Config.CREDENTIALS, ['https://www.googleapis.com/auth/drive'])
                        creds = flow.run_local_server(port=8080, open_browser=False)
                        with open(Config.TOKEN, 'wb') as token: pickle.dump(creds, token)

            if creds:
                self.service = build('drive', 'v3', credentials=creds)
                self.is_active = True
                Config.DRIVE_ACTIVE_STATE = True
        except Exception: 
            self.is_active = False
            Config.DRIVE_ACTIVE_STATE = False
            
    def list_files(self, query):
        """Helper for Context-Aware Drive Console."""
        if not self.is_active: return []
        try:
            res = self.service.files().list(
                q=query, 
                fields="files(id, name, mimeType, size, webViewLink, parents)", 
                supportsAllDrives=True, 
                includeItemsFromAllDrives=True,
                pageSize=1000
            ).execute()
            return res.get('files', [])
        except: return []

            
            
    def get_all_folders(self):
        """Fetches all model folders in the Master Directory."""
        if not self.is_active or not Config.DRIVE_MASTER_ID: return []
        try:
            q = f"'{Config.DRIVE_MASTER_ID}' in parents and mimeType = 'application/vnd.google-apps.folder' and trashed = false"
            res = self.service.files().list(
                q=q, 
                fields="files(id, name)", 
                supportsAllDrives=True, 
                includeItemsFromAllDrives=True,
                pageSize=1000
            ).execute()
            return res.get('files', [])
        except: return []
      
    def download_file(self, file_id, dest_path):
        """Downloads a file from Drive to the local path with a Valhalla-themed progress bar."""
        try:
            request = self.service.files().get_media(fileId=file_id)
            total_size = 0
            
            # Get file size for progress bar
            try:
                meta = self.service.files().get(fileId=file_id, fields="size").execute()
                total_size = int(meta.get('size', 0))
            except: 
                total_size = 0

            os.makedirs(os.path.dirname(dest_path), exist_ok=True)
            
            from googleapiclient.http import MediaIoBaseDownload
            import io

            with open(dest_path, "wb") as f:
                downloader = MediaIoBaseDownload(f, request)
                done = False
                
                # [FIXED] Removed 'style' argument from Speed/Time columns to prevent crash
                with Progress(
                    TextColumn(f"  [dim]└─[/] [{C_DIM}][[/]"),
                    BarColumn(bar_width=40, complete_style=f"bold {C_PRIM}", finished_style=f"bold {C_OK}"),
                    TextColumn(f"[{C_DIM}]][/]"),
                    TextColumn(f"[bold {C_PRIM}][progress.percentage]{{task.percentage:>3.0f}}%[/]"),
                    TextColumn(f"[{C_DIM}]•[/]"),
                    TransferSpeedColumn(),  # Standard speed column (style not supported in init)
                    TimeRemainingColumn(),  # Standard time column
                    console=console
                ) as progress:
                    task = progress.add_task("download", total=total_size)
                    
                    while done is False:
                        status, done = downloader.next_chunk()
                        if status:
                            progress.update(task, completed=status.resumable_progress)
            return True
        except Exception as e:
            console.print(f"[{C_ERR}]Download Error: {e}[/]")
            if os.path.exists(dest_path): os.remove(dest_path)
            return False

    def get_or_create_folder(self, model):
        if not self.service or not Config.DRIVE_MASTER_ID: return None
        try:
            sm_model = Utils.normalize_model(model)
            q = f"name = '{sm_model}' and '{Config.DRIVE_MASTER_ID}' in parents and trashed = false"
            res = self.service.files().list(q=q, fields="files(id)", supportsAllDrives=True, includeItemsFromAllDrives=True).execute()
            items = res.get('files', [])
            if items: return items[0]['id']
            
            meta = {'name': sm_model, 'mimeType': 'application/vnd.google-apps.folder', 'parents': [Config.DRIVE_MASTER_ID]}
            return self.service.files().create(body=meta, fields='id', supportsAllDrives=True).execute().get('id')
        except: return None
        
    def find_file_fuzzy(self, search_string, model):
        if not self.is_active: return None
        try:
            # 1. EXACT MATCH
            q = f"name = '{search_string}' and trashed = false"
            res = self.service.files().list(q=q, fields="files(id, name, webViewLink, size)", supportsAllDrives=True, includeItemsFromAllDrives=True).execute()
            items = res.get('files', [])
            if items: 
                f = items[0]
                if f.get('name') == search_string: return f.get('webViewLink'), int(f.get('size', 0)), f.get('name')
            
            # 2. FUZZY MATCH
            q_fuzzy = f"name contains '{search_string}' and trashed = false"
            res_fuzzy = self.service.files().list(q=q_fuzzy, fields="files(id, name, webViewLink, size)", supportsAllDrives=True, includeItemsFromAllDrives=True).execute()
            for f in res_fuzzy.get('files', []):
                if search_string in f.get('name', ''):
                    return f.get('webViewLink'), int(f.get('size', 0)), f.get('name')
            return None
        except: return None
        
    def list_model_files(self, model):
        """Fetches all files inside the specific model folder on Drive."""
        if not self.is_active: return []
        try:
            # Get the folder ID for the model (e.g., SM-S937B)
            fid = self.get_or_create_folder(model)
            if not fid: return []
            
            all_files = []
            page_token = None
            while True:
                # Query for all files in that folder
                q = f"'{fid}' in parents and trashed = false"
                res = self.service.files().list(
                    q=q, 
                    fields="nextPageToken, files(id, name, webViewLink, size)", 
                    supportsAllDrives=True, 
                    includeItemsFromAllDrives=True, 
                    pageToken=page_token
                ).execute()
                
                all_files.extend(res.get('files', []))
                page_token = res.get('nextPageToken')
                if not page_token: break
                
            return all_files
        except: return []
        
    def upload(self, file_path, model):
        self._auth()
        if not self.is_active: return None
        try:
            from googleapiclient.http import MediaFileUpload
            name = os.path.basename(file_path)
            fid = self.get_or_create_folder(model)
            if not fid: return None
                
            media = MediaFileUpload(file_path, resumable=True, chunksize=Config.UPLOAD_CHUNK_SIZE)
            meta = {'name': name, 'parents': [fid]}
            req = self.service.files().create(body=meta, media_body=media, fields='id, webViewLink', supportsAllDrives=True)
            
            response = None
            
            # [VALHALLA UPLOAD - FIXED STABILITY]
            console.print(f"[bold {C_PRIM}]ᛏ ESTABLISHING CLOUD UPLINK...[/]")
            
            with Progress(
                TextColumn(f"  [dim]└─[/] [{C_DIM}][[/]"),
                # [FIX] Removed incompatible 'complete_char' argument
                BarColumn(bar_width=40, complete_style=f"bold {C_PRIM}", finished_style=f"bold {C_OK}"),
                TextColumn(f"[{C_DIM}]][/]"),
                TextColumn(f"[bold {C_TEXT}][progress.percentage]{{task.percentage:>3.0f}}%[/]"),
                TextColumn(f"[{C_DIM}]•[/]"),
                TransferSpeedColumn(),
                console=console
            ) as p:
                task = p.add_task("up", total=100)
                while response is None:
                    status, response = req.next_chunk()
                    if status: p.update(task, completed=int(status.progress() * 100))
            
            return response.get('webViewLink')
        except Exception: return None


class TelegramService:
    SIGIL = (
        "+-------------+\n"
        "|   Y ᛟ ᚦ ᛋ   |\n"
        "|   V A L H   |\n"
        "|   A L L A   |\n"
        "+-------------+"
    )
    
    AGENTS = {
        "VALHALLA":     "ᚹᚨᛚᚺᚨᛚᛚᚨ",       
        "fahadali2315": "ᚠᚨᚺᚨᛞ ᚨᛚᛁ",      
        "reckaH2281":   "ᚱᛖᚲᚲᚨᚺ",         
        "Wr3ckless":    "ᚹᚱᛖᚲᛚᛖᛋᛋ",       
        "EL_BUSARDO":   "ᛖᛚ ᛒᚢᛋᚨᚱᛞᛟ"      
    }

    R = {
        "header": "ᚱ",  "device": "ᛟ",  "pack": "ᛒ",  
        "guard":  "ᛉ",  "path":   "ᛏ",  "cycle": "ᛃ",  
        "link":   "ᚱ",  "local":  "ᚦ",  "world": "ᛜ",
        "beta":   "ᛋ",  "delta":  "ᛞ",  "stable": "ᛟ",
        "count":  "ᛈ"
    }

    # [CRITICAL] This must be here, clearly visible at the top of the class
    FALLBACK_DB = {
        "F966": "Samsung Galaxy Z Fold 7", "F966B": "Samsung Galaxy Z Fold 7", "F966U": "Samsung Galaxy Z Fold 7",
        "F751": "Samsung Galaxy Z Flip 7", "F751B": "Samsung Galaxy Z Flip 7",
        "S948": "Samsung Galaxy S26 Ultra", "S948B": "Samsung Galaxy S26 Ultra",
        "S941": "Samsung Galaxy S26", "S946": "Samsung Galaxy S26+",
        "F956": "Samsung Galaxy Z Fold 6", "F741": "Samsung Galaxy Z Flip 6",
        "S928": "Samsung Galaxy S24 Ultra"
    }

    MODEL_DB = {}
    DB_LOADED = False

    @staticmethod
    def _load_intelligence():
        """Reads tacs.csv dynamically to populate model names."""
        if TelegramService.DB_LOADED: return
        
        # [FIXED] Safe path calculation
        try:
            script_dir = os.path.dirname(os.path.abspath(__file__))
        except NameError:
            script_dir = os.getcwd()
            
        candidates = [
            os.path.join(script_dir, "tacs.csv"),
            os.path.join(script_dir, "database", "tacs.csv"),
            os.path.join(os.getcwd(), "tacs.csv"),
            "tacs.csv"
        ]
        
        target_file = None
        for f in candidates:
            if os.path.exists(f): target_file = f; break
            
        if not target_file: return 

        try:
            with open(target_file, mode='r', encoding='utf-8-sig') as csvfile:
                reader = csv.DictReader(csvfile)
                for row in reader:
                    raw_code = row.get('Telstra Model Name', '')
                    marketing = row.get('Optus Model Name', '')
                    
                    if 'SM-' in raw_code and marketing:
                        parts = raw_code.split('SM-')
                        if len(parts) > 1:
                            clean_code = parts[1].split()[0].split('/')[0].strip().upper()
                            clean_name = marketing.strip().title().replace("Samsung ", "") 
                            TelegramService.MODEL_DB[clean_code] = f"Samsung {clean_name}"
                            if len(clean_code) >= 4:
                                prefix = clean_code[:4]
                                if prefix not in TelegramService.MODEL_DB:
                                    TelegramService.MODEL_DB[prefix] = f"Samsung {clean_name}"
            TelegramService.DB_LOADED = True
        except Exception: pass

    @staticmethod
    def _clean_html(text: str) -> str:
        return str(text).replace("&", "&amp;").replace("<", "&lt;").replace(">", "&gt;")

    @staticmethod
    def send_message(text: str) -> bool:
        if not getattr(Config, "TG_ENABLED", False) or not getattr(Config, "TG_TOKEN", ""): return False
        try:
            requests.post(f"https://api.telegram.org/bot{Config.TG_TOKEN}/sendMessage", data={"chat_id": Config.TG_CHAT_ID, "text": text, "parse_mode": "HTML", "disable_web_page_preview": True}, timeout=10)
            return True
        except: return False

    @staticmethod
    def _resolve_identity(model_code: str) -> str:
        TelegramService._load_intelligence()
        raw = str(model_code).upper().strip().replace("SM-", "").replace("SM_", "").replace("SAM_", "")
        
        if raw in TelegramService.MODEL_DB: return TelegramService.MODEL_DB[raw]
        if raw in TelegramService.FALLBACK_DB: return TelegramService.FALLBACK_DB[raw]
        
        prefix = raw[:4]
        if prefix in TelegramService.MODEL_DB: return TelegramService.MODEL_DB[prefix]
        if prefix in TelegramService.FALLBACK_DB: return TelegramService.FALLBACK_DB[prefix]

        return f"Samsung Device ({raw})"

    @staticmethod
    def _detect_smart_region(model: str, fname: str) -> str:
        m = (model or "").upper()
        f = (fname or "").upper()
        clean_name = f.replace("SM-", "").replace("SM_", "") 
        parts = clean_name.split('_')
        csc = parts[1] if len(parts) >= 2 else "UNK"

        if m.endswith("U") or m.endswith("U1"): return "USA"
        if m.endswith("W"): return "CAN"
        if m.endswith("N"): return "KOR"
        if m.endswith("0"):
            if csc in ["CHC", "CHM"]: return "CHN"
            if csc in ["TGY", "BRI"]: return "HK/TW"
            return "CHN/HK"
        
        if csc == "OWO" or csc in Config.CSC_MAP.get("OWO", []): return "LATAM"  
        if csc == "OXM" or csc in Config.CSC_MAP.get("OXM", []): return "EU/GLB" 
        if csc == "OJM" or csc in Config.CSC_MAP.get("OJM", []): return "MEA"    
        if csc == "OLM" or csc in Config.CSC_MAP.get("OLM", []): return "APAC"   
        if csc == "OXE" or csc in Config.CSC_MAP.get("OXE", []): return "CIS/RU" 
        if csc == "IND" or csc in Config.CSC_MAP.get("IND", []): return "IND"

        if m.endswith("B"): return "GLB"
        if m.endswith("E"): return "INTL"
        return csc

    @staticmethod
    def tg_ping_text() -> str:
        sig = TelegramService.AGENTS.get(Config.AGENT_ID, Config.AGENT_ID)
        return f"<pre>{TelegramService.SIGIL}</pre>\n<b>{TelegramService.R['guard']} LOGISTICS DIAGNOSTIC</b>\n<i>{TelegramService.R['path']} Signal verified by {sig}</i>"

    @staticmethod
    def send_batch(file_list):
        if not getattr(Config, "TG_ENABLED", False) or not getattr(Config, "TG_TOKEN", "") or not file_list: return
        TelegramService._load_intelligence()
        MAX_LEN = 3900

        if "count" not in TelegramService.R: TelegramService.R["count"] = "ᛈ"

        def _get_build_icon(fname):
            return TelegramService.R['delta'] if ".DM" in fname.upper() else TelegramService.R['stable']

        def _parse_versions(fname: str):
            base = (fname or "").replace(".zip", "").replace(".DM", "")
            parts = base.split("_")
            return (parts[-2], parts[-1]) if len(parts) >= 2 else ("---", "LATEST")

        def build_block(item) -> str:
            raw_model = TelegramService._clean_html(item.get("model", "UNKNOWN"))
            fname_clean = TelegramService._clean_html(item.get("fname", "UNKNOWN"))
            
            marketing_name = TelegramService._resolve_identity(raw_model)
            region_str = TelegramService._detect_smart_region(raw_model, fname_clean)
            
            size = TelegramService._clean_html(item.get("size", "N/A"))
            link = item.get("link")
            icon = _get_build_icon(fname_clean)
            old_v, new_v = _parse_versions(fname_clean)

            tag = " [DELTA]" if ".DM" in fname_clean.upper() else ""
            
            lines = [
                f"<b>{icon} {marketing_name}{tag}</b>",
                "", 
                f"{TelegramService.R['world']} <i>{region_str}</i>",
                f"{TelegramService.R['pack']} <code>{size}</code>",
                f"{TelegramService.R['path']} <code>{old_v}</code> → <code>{new_v}</code>",
                f"{TelegramService.R['cycle']} <code>{fname_clean}</code>"
            ]
            
            if link and "http" in str(link):
                lines.append(f"{TelegramService.R['link']} <a href=\"{TelegramService._clean_html(link)}\">GDRIVE LINK</a>")
            else:
                lines.append(f"{TelegramService.R['local']} <b>LOCAL ARCHIVE ONLY</b>")
            
            return "\n".join(lines) + "\n\n"

        current_agent = getattr(Config, "AGENT_ID", "VALHALLA")
        agent_rune = TelegramService.AGENTS.get(current_agent, current_agent)
        batch_type = "BATCH MANIFEST" if len(file_list) > 1 else "DEPLOYMENT"
        
        header = (
            f"<pre>{TelegramService.SIGIL}</pre>\n"
            f"<b>{TelegramService.R['header']} {batch_type} LOG</b>\n"
            f"{TelegramService.R['count']} COUNT: <b>{len(file_list)}</b>\n"
            f"━━━━━━━━━━━━━━━━━━━━━━\n\n"
        )
        footer = f"{TelegramService.R['guard']} <i>Overseen by {agent_rune}</i>"
        
        messages = []; current = header
        for item in file_list:
            blk = build_block(item)
            if len(current) + len(blk) + len(footer) + 20 > MAX_LEN:
                current += footer; messages.append(current); current = header
            current += blk
        current += footer; messages.append(current)
        
        for msg in messages: TelegramService.send_message(msg)

class DatabaseService:       
    def __init__(self): 
        # Ensure database directory exists
        os.makedirs(Config.DIR_DB, exist_ok=True)
        self.db_path = os.path.join(Config.DIR_DB, Config.DB_FILE)

    def get_hits(self):
        """Fetches aggregated hit counts for the main menu selection."""
        if not os.path.exists(self.db_path): return []
        try:
            conn = sqlite3.connect(self.db_path)
            conn.row_factory = sqlite3.Row
            c = conn.cursor()
            # Aggregate by Model + CSC
            c.execute("SELECT device_model, csc, COUNT(*) as count FROM firmware_hits GROUP BY device_model, csc ORDER BY device_model")
            return [dict(r) for r in c.fetchall()]
        except: return []

    def get_imeis(self, model, csc):
        """Fetches valid IMEIs for a specific Model/CSC combo to use in scanning."""
        try:
            conn = sqlite3.connect(self.db_path)
            c = conn.cursor()
            c.execute("SELECT DISTINCT imei FROM firmware_hits WHERE device_model = ? AND csc = ?", (model, csc))
            return [r[0] for r in c.fetchall() if r[0]]
        except: return []

# ==============================================================================
# 5. CONTROLLER & LOGIC
# ==============================================================================

# ==============================================================================
# 4.5 DIAGNOSTICS (Restored)
# ==============================================================================
class SystemDiagnostics:
    @staticmethod
    def run(controller):
        Dashboard.header()
        console.print(f"[bold {C_PRIM}]RUNNING SYSTEM DIAGNOSTICS...[/]\n")
        
        # 1. Network
        try:
            requests.head("https://fota-cloud-dn.ospserver.net", timeout=5, verify=False)
            net_status = f"[{C_OK}]PASS[/]"
        except: 
            net_status = f"[{C_ERR}]FAIL[/]"
        console.print(f"Network (Samsung FOTA): {net_status}")
        
        # 2. Telegram
        if Config.TG_ENABLED:
            tg_ok = TelegramService.send_message(TelegramService.tg_ping_text())
            tg_status = f"[{C_OK}]PASS[/]" if tg_ok else f"[{C_ERR}]FAIL[/]"
        else:
            tg_status = f"[{C_DIM}]DISABLED[/]"
        console.print(f"Telegram Link:          {tg_status}")
        
        # 3. Drive
        dr_ok = False
        if controller.drive.is_active:
            try: 
                controller.drive.service.files().list(pageSize=1).execute()
                dr_ok = True
            except: pass
        
        if Config.DRIVE_ENABLED:
            dr_status = f"[{C_OK}]PASS[/]" if dr_ok else f"[{C_ERR}]FAIL (Auth Error)[/]"
        else:
            dr_status = f"[{C_DIM}]DISABLED[/]"
        console.print(f"Drive API Connection:   {dr_status}")
        
        # 4. Storage
        import shutil
        total, used, free = shutil.disk_usage(".")
        free_gb = free // (2**30)
        disk_status = f"[{C_OK}]{free_gb} GB Free[/]" if free_gb > 10 else f"[{C_ERR}]{free_gb} GB (LOW)[/]"
        console.print(f"Local Storage:          {disk_status}")
        
        console.input(f"\n[{C_DIM}]Diagnostics complete. Press Enter...[/]")


class LogisticsController:
    def is_wifi_tablet(self, model_raw):
        m = model_raw.replace("SM-", "").strip().upper()
        if (m.startswith("X") or m.startswith("T") or m.startswith("P")) and m.endswith("0"):
            return True
        return False

    def __init__(self):
        self.db = DatabaseService()
        self.drive = DriveService()
        self.recover_blackbox()
        # [FIX] Initialize R inside the class to prevent "AttributeError: R"
        self.R = R 
        
    def _fota_build_download_headers(self, model=""):
        headers = {
            "User-Agent": "SyncML DM Client",
            "Accept": "*/*",
            "Cache-Control": "no-store,private",
            "Connection": "Keep-Alive",
            "Accept-Language": "en",
            "Accept-Charset": "utf-8",
        }
        if model:
            headers["User-Agent"] = f"{model} SyncML DM Client"
        return headers

    def _fota_make_session(self, model=""):
        s = requests.Session()
        s.headers.update(self._fota_build_download_headers(model))
        s.verify = False

        retry = Retry(
            total=3,
            connect=3,
            read=3,
            backoff_factor=1,
            status_forcelist=[500, 502, 503, 504],
            allowed_methods=frozenset(["GET", "HEAD"]),
        )
        adapter = HTTPAdapter(max_retries=retry, pool_connections=2, pool_maxsize=2)
        s.mount("https://", adapter)
        s.mount("http://", adapter)
        return s

    def _fota_mealy_machine(self, i2, i5):
        iArr = [
            [11, 0], [0, 4], [8, 15], [11, 2],
            [0, 3], [9, 0], [15, 0], [0, 0],
            [5, 0], [0, 0], [0, 0], [1, 6],
            [0, 0], [3, 13], [0, 0], [2, 13]
        ]
        cArr = [
            ('s', '3'), ('v', 'n'), ('1', '9'), ('m', '0'),
            ('e', 'c'), ('3', 'B'), ('7', 'N'), ('k', '2'),
            ('2', 'C'), ('a', 'C'), ('J', '2'), ('y', 'l'),
            ('8', 'd'), ('1', '0'), ('A', '^'), ('7', '0')
        ]
        bArr = []
        i6 = i2
        i7 = 0
        for _ in range(i5):
            i9 = i6 & 1
            i6 >>= 1
            bArr.append(ord(cArr[i7][i9]))
            i7 = iArr[i7][i9]
        return bytes(bArr)

    def _fota_add_optional_download_params(self, url):
        try:
            from Crypto.Cipher import AES
            import datetime

            key = self._fota_mealy_machine(5932, 16)
            px_nb = base64.b64encode(
                AES.new(key, AES.MODE_ECB).encrypt(b"WIFI" + bytes([12] * 12))
            ).decode()

            px_rmtime = datetime.datetime.now(datetime.timezone.utc).strftime("%Y-%m-%d%%20%H:%M:%S")
            sep = "&" if "?" in url else "?"
            return url + f"{sep}px-nb={urllib.parse.quote(px_nb)}&px-rmtime={px_rmtime}"
        except Exception:
            return url

    def _fota_download(self, url, local_path, model="", size_hint=0):
        os.makedirs(os.path.dirname(local_path), exist_ok=True)

        session = self._fota_make_session(model)

        resume_pos = os.path.getsize(local_path) if os.path.exists(local_path) else 0
        req_headers = {}
        if resume_pos > 0:
            req_headers["Range"] = f"bytes={resume_pos}-"

        attempt_urls = [url]
        extra_url = self._fota_add_optional_download_params(url)
        if extra_url != url:
            attempt_urls.append(extra_url)

        total_size = int(size_hint or 0)
        last_err = None

        with Progress(
            TextColumn(f"  [dim]└─[/] [{C_DIM}][[/]"),
            BarColumn(bar_width=40, complete_style=f"bold {C_PRIM}", finished_style=f"bold {C_OK}"),
            TextColumn(f"[{C_DIM}]][/]"),
            TextColumn(f"[bold {C_PRIM}][progress.percentage]{{task.percentage:>3.0f}}%[/]"),
            TextColumn(f"[{C_DIM}]•[/]"),
            TransferSpeedColumn(),
            TimeRemainingColumn(),
            console=console
        ) as p:
            task = p.add_task("dl", total=max(total_size, 1))

            for attempt_url in attempt_urls:
                try:
                    with session.get(
                        attempt_url,
                        headers=req_headers,
                        stream=True,
                        timeout=60,
                        allow_redirects=True,
                    ) as r:
                        r.raise_for_status()

                        cl = int(r.headers.get("content-length", 0) or 0)
                        if r.status_code == 206 and resume_pos > 0:
                            total_size = total_size or (resume_pos + cl if cl else 0)
                        else:
                            total_size = total_size or cl

                        if total_size > 0:
                            p.update(task, total=total_size)

                        mode = "ab" if (resume_pos > 0 and r.status_code == 206) else "wb"
                        written = resume_pos if mode == "ab" else 0

                        with open(local_path, mode) as f:
                            for chunk in r.iter_content(chunk_size=1024 * 1024):
                                if not chunk:
                                    continue
                                f.write(chunk)
                                written += len(chunk)
                                p.update(task, completed=written)

                        return total_size or written

                except Exception as e:
                    last_err = e

        raise last_err or Exception("FOTA download failed")
    def main_menu(self):
        self.run_continuum_check()
        while True:
            Dashboard.header()
            menu_choices = [
                Choice("scan",      f"{self.R['star']}  START OPERATIONS"),
                Choice("repo",      f"{self.R['wealth']} DRIVE REPOSITORY"),
                Choice("queue",     f"{self.R['cycle']}  NIGHT SHIFT ({len(job_queue)})"),
                Choice("continuum", f"{self.R['tree']}  CONTINUUM (History)"), 
                Choice("settings",  f"{self.R['law']}  SYSTEM CONFIG"),
                Separator(),
                Choice("back",      f"{self.R['back']}  BACK TO HUB") 
            ]
            action = inquirer.select(message="SELECT PROTOCOL:", choices=menu_choices, pointer="›", style=MENU_STYLE).execute()
            
            if action == "back": 
                self.show_mission_debrief()
                sys.exit(0) 
            elif action == "scan": self.deployment_console()
            elif action == "repo": self.drive_repository_console()
            elif action == "queue": self.night_shift_console()
            elif action == "continuum": self.run_continuum_manual()
            elif action == "settings": self.settings_menu()
            
    def _scan_thread(self, model, cscs, ver, prog, tid, target_version=None, custom_imeis=None):
        from FotaAgent.Client import Client
        from FotaAgent.Http import parse_descripter

        for csc in cscs:
            if prog: prog.update(tid, description=f"{csc}")
            
            # Resolve IMEIs
            imeis = custom_imeis if custom_imeis else (self.db.get_imeis(model, csc) or [Utils.generate_imei()])[:2]
            
            for imei in imeis:
                try:
                    mcc, mnc = ("460", "01") if csc in ["CHC","CHM"] else ("310", "410")
                    client = Client({"Model": model, "Registered": True, "Mcc": mcc, "Mnc": mnc, "FotaClientVersion": "4.4.14"})
                    client.UserAgent = Utils.get_random_ua()
                    client.DeviceId = f"IMEI:{imei}"
                    client.CustomerCode = csc
                    client.generate_password()

                    resp = str(client.check_update(ver))
                    
                    if "403" in resp: 
                        Utils.handle_ban_wait("403 - Server Blocked Request")
                        continue
                    
                    # [FIX] Catch "no_upd" explicitly to prevent "Invalid URL" errors
                    if "no_upd" in resp:
                        continue 

                    # [FIX] Catch "bad_csc" explicitly 
                    if "bad_csc" in resp:
                        continue

                    desc = parse_descripter(resp, ver) or {}
                    url = desc.get("objectURI")
                    
                    if url:
                        uv = desc.get("updateFwV", "Unknown")
                        dm = ".DM" in uv.upper() or ".DM" in url.upper()
                        
                        if target_version:
                            if target_version in uv: return uv, url, dm
                        else: return uv, url, dm
                        
                except Exception as e:
                    # [FIX] Clean error suppression
                    err_str = str(e)
                    # Suppress common non-critical errors
                    if any(x in err_str for x in ["no_upd", "bad_csc", "Invalid URL", "No scheme"]):
                        continue
                    elif "Connection" in err_str:
                        console.print(f"[bold {C_ERR}]! NET ERROR ({csc})[/] [dim]Connection dropped.[/]")
                    else:
                        # console.print(f"[dim]! Scan error {csc}: {err_str}[/]") # Uncomment for deep debug
                        pass
                    continue
        return "None", None, False
        
    def _load_triplets_from_decrypted_json(self, json_path: str) -> list:
	    try:
	        if not json_path or not os.path.exists(json_path):
	            return []
	
	        with open(json_path, "r", encoding="utf-8") as f:
	            data = json.load(f)
	
	        if isinstance(data, list):
	            firmwares = data
	        else:
	            firmwares = (
	                data.get("firmwares")
	                or data.get("latest_firmwares")
	                or data.get("results")
	                or data.get("builds")
	                or []
	            )
	
	        out = []
	        for fw in firmwares:
	            if isinstance(fw, str):
	                v = fw.strip()
	            else:
	                v = (
	                    fw.get("version")
	                    or fw.get("triplet")
	                    or fw.get("build")
	                    or ""
	                ).strip()
	
	            if v and "/" in v:
	                out.append(v)
	
	        seen = set()
	        uniq = []
	        for v in out:
	            if v not in seen:
	                seen.add(v)
	                uniq.append(v)
	        return uniq
	    except Exception:
	        return []

    def reverse_check_target_against_json(self, model, cscs, target_triplet, json_path, custom_imeis=None, silent=False):
        """
        Reverse check:
            Find which BASE triplet (from json) reaches TARGET triplet as updateFwV.
        Returns:
            (parent_base, found_update_uv, url, is_dm)
        or:
            (None, "None", None, False)
        """
        if not silent:
            Dashboard.header()

        target_triplet = (target_triplet or "").strip()
        if not target_triplet:
            if not silent:
                console.print(f"[{C_ERR}]No target triplet provided.[/]")
            return None, "None", None, False

        candidates = self._load_triplets_from_decrypted_json(json_path)
        if not candidates:
            if not silent:
                console.print(f"[{C_ERR}]No candidates loaded from:[/] [dim]{json_path}[/]")
            return None, "None", None, False

        # Newest-first helps find bridge faster (your Utils.get_date_score already exists)
        try:
            candidates = sorted(candidates, key=lambda x: Utils.get_date_score(x), reverse=True)
        except Exception:
            pass

        if not silent:
            console.print(f"[{C_DIM}]Reverse checking {len(candidates)} bases for target:[/] {target_triplet}")

        with Progress(
            SpinnerColumn(),
            TextColumn("{task.description}"),
            BarColumn(),
            TimeRemainingColumn(),
            console=console,
            transient=True
        ) as p:
            task = p.add_task("Reverse scan", total=len(candidates))
            
            for base in candidates:
                # Show what we are checking right now
                try:
                    p.update(task, description=f"Reverse scan • {base}")
                except Exception:
                    pass
            
                uv, url, is_dm = self._scan_thread(
                    model=model,
                    cscs=cscs,
                    ver=base,
                    prog=None,
                    tid=None,
                    target_version=target_triplet,
                    custom_imeis=custom_imeis
                )
            
                # Add a small status so you can tell it's alive / banned / etc
                status = "MISS"
                if uv and uv != "None":
                    status = "HIT"
                elif isinstance(url, str) and ("403" in url or "Access" in url or "Denied" in url):
                    status = "BAN?"
                elif isinstance(uv, str) and ("bad_csc" in uv.lower()):
                    status = "BAD_CSC"
                elif isinstance(uv, str) and ("auth" in uv.lower() or "401" in uv):
                    status = "AUTH"
                else:
                    status = "OK"
            
                # Update description with status + base
                try:
                    p.update(task, description=f"Reverse scan • {status} • {base}")
                except Exception:
                    pass
            
                p.advance(task, 1)
            
                # Optional: every N steps print a heartbeat line (helps a lot on Termux)
                if not silent and (p.tasks[0].completed % 10 == 0):
                    console.print(f"[{C_DIM}]CHECK[/] {base}  →  [{C_PRIM}]{status}[/]")
            
                if uv != "None":
                    if not silent:
                        console.print(f"[{C_OK}]FOUND PARENT BASE[/] {base}")
                        console.print(f"[{C_ACC}]OFFERS TARGET[/] {uv}")
                        console.print(f"[{C_DIM}]URL[/] {url}")
                    return base, uv, url, is_dm

        if not silent:
            console.print(f"[{C_ERR}]No parent base found for target in this JSON.[/]")
        return None, "None", None, False

    def reverse_lookup_console(self, model: str, target_group: str = None):
        """
        Reverse Lookup:
        Given a TARGET triplet (AP/CSC/CP), find which known triplets in jsons/ + Decrypted/
        are likely predecessors (parents) that could lead to it.
    
        Uses Utils.get_known_versions() so it respects your strict region isolation filters.
        """
        Dashboard.header()
        console.print(Panel(
            Align.left(
                f"[bold {C_TEXT}]Reverse Lookup[/]\n"
                f"[{C_DIM}]Paste a target triplet like:[/]\n"
                f"[{C_PRIM}]F966USQE7CZB1/F966UOYN7CZB1/F966USQU7BZAA[/]"
            ),
            border_style=C_BORDER,
            box=box.HEAVY
        ))
    
        target = inquirer.text(
            message=" Target Triplet",
            default="",
            style=MENU_STYLE
        ).execute().strip()
    
        if not target or "/" not in target:
            console.print(f"[{C_ERR}]Invalid target. Must be AP/CSC/CP triplet.[/]")
            input("Press Enter...")
            return
    
        def _split_triplet(t: str):
            parts = [p.strip().upper() for p in str(t).split("/") if p.strip()]
            # Some strings may have 4 parts; we only care about first 3 (AP/CSC/CP-like)
            if len(parts) >= 3:
                return parts[0], parts[1], parts[2]
            return "", "", ""
    
        def _extract_family_tag(mid: str):
            # Example middle: F966UOYN7CZB1 -> contains "OYN"
            mid_u = (mid or "").upper()
            for g in Config.CSC_MAP.keys():
                if len(g) == 3 and g in mid_u:
                    return g
            return None
    
        def _extract_bl_digit(comp: str):
            """
            Try to extract the bootloader digit.
            Example: F966USQE7CZB1 -> "7"
            We find the last digit before the last 4/5 build chars.
            """
            s = (comp or "").upper().replace(".DM", "")
            # Typical tail: ...7CZB1 (digit + 4 chars)
            m = re.search(r"(\d)[A-Z]{3}\d$", s)
            if m:
                return m.group(1)
            # Fallback: digit before last 5
            m2 = re.search(r"(\d)[A-Z0-9]{5}$", s)
            return m2.group(1) if m2 else ""
    
        def _score_triplet(trip: str):
            # Use existing date score logic from suffix extraction
            return Utils.get_date_score(trip)
    
        t_ap, t_mid, t_cp = _split_triplet(target)
        t_tag = _extract_family_tag(t_mid)
        t_bl  = _extract_bl_digit(t_ap) or _extract_bl_digit(t_cp)
    
        # Pull all known triplets using your existing hardened collector
        known = Utils.get_known_versions(model, target_group=target_group)  # 1
    
        candidates = []
        t_score = _score_triplet(target)
    
        for k in known:
            k_ap, k_mid, k_cp = _split_triplet(k)
    
            # Must share same family tag if we can detect it (OYN/OXM/OJM...)
            k_tag = _extract_family_tag(k_mid)
            if t_tag and k_tag and (k_tag != t_tag):
                continue
    
            # Bootloader digit should match (strong signal)
            k_bl = _extract_bl_digit(k_ap) or _extract_bl_digit(k_cp)
            if t_bl and k_bl and (k_bl != t_bl):
                continue
    
            # Must be older than target (otherwise it's not a "parent")
            k_score = _score_triplet(k)
            if t_score and k_score and (k_score >= t_score):
                continue
    
            # Prefer same CSC middle prefix (same model + same CSC-family string)
            # If mid strings share the same "FOO...OYN..." prefix, keep it
            if t_tag and t_tag not in (k_mid or "").upper():
                continue
    
            candidates.append((k_score, k))
    
        # Sort newest parents first
        candidates.sort(key=lambda x: x[0], reverse=True)
    
        Dashboard.header()
    
        if not candidates:
            console.print(Panel(
                Align.left(
                    f"[bold {C_ERR}]No parent candidates found.[/]\n\n"
                    f"[{C_DIM}]Target:[/] [{C_TEXT}]{target}[/]\n"
                    f"[{C_DIM}]Model:[/] [{C_TEXT}]{Utils.normalize_model(model)}[/]\n"
                    f"[{C_DIM}]Filter:[/] [{C_TEXT}]{target_group or 'AUTO'}[/]"
                ),
                border_style=C_ERR,
                box=box.HEAVY
            ))
            input("Press Enter...")
            return
    
        tbl = Table(
            title=f"[bold {C_PRIM}]REVERSE LOOKUP RESULTS[/]",
            box=box.SIMPLE_HEAVY,
            border_style=C_BORDER,
            show_lines=False
        )
        tbl.add_column("RANK", justify="right", width=4, style=C_DIM)
        tbl.add_column("PARENT TRIPLET", justify="left", style=C_TEXT)
        tbl.add_column("DATE", justify="left", width=10, style=C_PRIM)
    
        # Show top 40 to keep UI clean
        for i, (sc, trip) in enumerate(candidates[:40], start=1):
            tbl.add_row(str(i), trip, Utils.decode_date(trip))
    
        console.print(Panel(
            Align.left(
                f"[{C_DIM}]Target:[/] [{C_TEXT}]{target}[/]\n"
                f"[{C_DIM}]Detected Family:[/] [{C_TEXT}]{t_tag or '-'}[/]   "
                f"[{C_DIM}]BL:[/] [{C_TEXT}]{t_bl or '-'}[/]\n"
                f"[{C_DIM}]Showing:[/] [{C_TEXT}]{min(40, len(candidates))}[/] / [{C_TEXT}]{len(candidates)}[/]"
            ),
            border_style=C_BORDER,
            box=box.HEAVY
        ))
        console.print(tbl)
        input("\nPress Enter to return...")
    
    def execute_scan_logic(self,model,cscs,mode,auto_dl=False,queue_mode=False,manual_version=None,target_version=None,custom_imeis=None,silent=False):
	    if not silent:
	        Dashboard.header()
	        
	    target_group, _ = Utils.get_multi_csc_info(cscs[0], model=model)
	    known = Utils.get_known_versions(model, target_group=target_group)
	    
	    queue = []
	    if mode == "smart":
	        sorted_vers = sorted(list(set(known)), key=lambda x: Utils.get_date_score(x))
	        queue = sorted_vers[-5:]
	    elif mode == "manual" or mode == "base":
	        queue = [manual_version] if manual_version else [
	            inquirer.text("Base Version:", style=MENU_STYLE).execute().strip()
	        ]
	    
	    if not queue:
	        return
	    
	    results = {}
	    if not silent: 
	        console.print(f"[{C_DIM}]Scanning {len(queue)} bases...[/]")
	        
	    with Progress(
	        SpinnerColumn(), 
	        TextColumn("{task.description}"), 
	        BarColumn(), 
	        console=console, 
	        transient=True
	    ) as p:
	        task = p.add_task("Processing", total=len(queue))
	        with ThreadPoolExecutor(max_workers=Config.MAX_THREADS) as exe:
	            futs = {
	                exe.submit(
	                    self._scan_thread, 
	                    model, 
	                    cscs, 
	                    v, 
	                    p, 
	                    task, 
	                    target_version, 
	                    custom_imeis
	                ): v 
	                for v in queue
	            }
	            for f in as_completed(futs): 
	                results[futs[f]] = f.result()
	                p.advance(task, 1)
	    
	    valid_files = []
	    for src, (tgt, url, is_dm) in results.items():
	        if tgt == "None": 
	            continue
	        if is_dm and not Config.ALLOW_DM_BUILDS: 
	            continue
	        if not silent and not queue_mode: 
	            Continuum.update_entry(model, cscs[0], tgt)
	            
	        fname = Utils.generate_filename(model, cscs[0], src, tgt, is_dm)
	        valid_files.append({
	            "fname": fname, 
	            "url": url, 
	            "label": f"{fname}", 
	            "model": model
	        })
	    
	    if not valid_files: 
	        if not silent: 
	            console.print("No updates.")
	            time.sleep(1)
	        return
	    
	    if queue_mode:
	        for f in valid_files: 
	            job_queue.append(f)
	        self.save_blackbox()
	        if not silent: 
	            console.print(f"[{C_OK}]Added to Queue.[/]")
	            time.sleep(1)
	        return
	
	    selected = inquirer.checkbox(
	        "Select files:", 
	        choices=[Choice(f, f['label']) for f in valid_files], 
	        style=MENU_STYLE
	    ).execute()
	    
	    if selected:
	        self.handle_post_selection_actions(selected, model)
	
             
    def deployment_console(self, queue_mode=False):
        # [THEME FIX]
        ChoiceClass = globals().get('Choice', Choice)

        hits = self.db.get_hits()
        if not hits: console.print(f"[{C_ERR}]Database Empty.[/]"); input("Enter..."); return
        
        fam_map = defaultdict(lambda: defaultdict(list))
        for h in hits:
            if hasattr(self, 'is_wifi_tablet') and self.is_wifi_tablet(h["device_model"]): continue
            fam, var = Utils.split_model_variant(h["device_model"])
            fam_map[fam][var].append(h)

        step = 1; selected_fam = None; selected_var = None; full_model = None
        
        while True:
            Dashboard.header()
            
            # --- STEP 1: FAMILY SELECTION ---
            if step == 1:
                choices = [ChoiceClass(f, f"SM-{f:<5} │ {len(fam_map[f])} Variants") for f in sorted(fam_map.keys())]
                choices.append(ChoiceClass("back", "Return to Main"))
                sel = inquirer.select(message="Select Family:", choices=choices, style=MENU_STYLE).execute()
                if sel == "back": return
                selected_fam = sel; step = 2
            
            # --- STEP 2: VARIANT SELECTION ---
            elif step == 2:
                choices = [ChoiceClass(v, f"Model {v:<2}   │ {sum(h['count'] for h in fam_map[selected_fam][v])} Hits") for v in sorted(fam_map[selected_fam].keys())]
                choices.append(ChoiceClass("back", "Go Back"))
                sel = inquirer.select(message="Select Variant:", choices=choices, style=MENU_STYLE).execute()
                if sel == "back": step = 1; continue
                selected_var = sel; full_model = f"SM-{selected_fam}{selected_var}"; target_data = fam_map[selected_fam][selected_var]; step = 3

            # --- STEP 3: REGION SELECTION ---
            elif step == 3:
                choices = [ChoiceClass("ALL", ">> ENGAGE ALL SECTORS")] + [ChoiceClass(h['csc'], f"{h['csc']:<6} │ {h['count']} Hits") for h in target_data]
                choices.append(ChoiceClass("back", "Go Back"))
                sel = inquirer.checkbox(message="Select Regions:", choices=choices, style=MENU_STYLE).execute()
                if "back" in sel or not sel: step = 2; continue
                final_cscs = [h['csc'] for h in target_data] if "ALL" in sel else sel; step = 4
                
            # --- STEP 4: IMEI & PROTOCOL ---
            elif step == 4:
                db_imeis = set()
                for c in final_cscs:
                    found = self.db.get_imeis(full_model, c)
                    if found: db_imeis.update(found)
                
                custom_imeis = None
                if db_imeis:
                    # [FIX] Added 'Back' option to IMEI menu
                    imei_menu = [ChoiceClass("AUTO", ">> AUTO (Default)"), ChoiceClass("ALL", ">> SELECT ALL")] + [ChoiceClass(i, i) for i in sorted(db_imeis)]
                    imei_menu.append(ChoiceClass("back", "Go Back"))
                    
                    sel_imeis = inquirer.checkbox("Select IMEIs:", choices=imei_menu, style=MENU_STYLE).execute()
                    
                    if "back" in sel_imeis: step = 3; continue # Handle Back Logic
                    
                    if "ALL" in sel_imeis: custom_imeis = list(db_imeis)
                    elif "AUTO" in sel_imeis or not sel_imeis: custom_imeis = None
                    else: custom_imeis = sel_imeis
                    
                console.print(f"[bold {C_ACC}]TARGET: {full_model} {final_cscs}[/]")
                mode = inquirer.select("Scan Protocol:", choices=[
                    ChoiceClass("smart", "Smart Scan"),
                    ChoiceClass("timeline", "Timeline Tree"),
                    Choice("reverse", f"{R['search']} REVERSE LOOKUP"),
                    ChoiceClass("drive", "Drive Repository Search"), 
                    ChoiceClass("decrypt", "Mimir (Decrypt & History)"), 
                    ChoiceClass("base", "Specific Base(s)"),
                    ChoiceClass("manual", "Manual Input"), 
                    ChoiceClass("back", "Back")
                ], style=MENU_STYLE).execute()

                if mode == "back": step = 3; continue

                # [FIXED] Decrypter Integration with Interactive Menu
                if mode == "decrypt":
                    try:
                        import decrypter10
                        target_csc = final_cscs[0] if final_cscs else "EUX"
                        result = decrypter10.run_decrypter(full_model, target_csc, selection_mode=True)
                        if result:
                            batch = result if isinstance(result, list) else [result]
                            console.print(f"[bold {C_OK}]>> PROCESSING {len(batch)} BUILDS...[/]")
                            
                            for res in batch:
                                if isinstance(res, dict) and "version" in res:
                                    # CHANGE: queue_mode=False, silent=False triggers the menu
                                    self.execute_scan_logic(
                                        full_model, 
                                        final_cscs, 
                                        "base", 
                                        queue_mode=False,       # <--- Enables Selection Menu
                                        manual_version=res['version'], 
                                        custom_imeis=custom_imeis, 
                                        silent=False            # <--- Enables UI Output
                                    )
                        continue
                    except Exception as e: 
                        console.print(f"[{C_ERR}]Error: {e}[/]"); time.sleep(2); continue

                # [FIX] Base Selection + Theme + Pinning
                elif mode == "base":
                    target_group, _ = Utils.get_multi_csc_info(final_cscs[0], model=full_model)
                    json_path = os.path.join(Config.DIR_DECRYPTED, f"{full_model}_{final_cscs[0]}_full.json")
                    known = self._load_triplets_from_decrypted_json(json_path)

                    if not known:
                        known = Utils.get_known_versions(full_model, target_group=target_group)

                    if known:
                        sorted_vers = sorted(
                            known,
                            key=lambda x: Utils.get_date_score(x),
                            reverse=True
                        )
                        latest_stable = None
                        for v in sorted_vers:
                            clean_v = v.split('/')[0] if '/' in v else v
                            if clean_v and not clean_v[-1].isdigit():
                                latest_stable = v
                                break
                                
                        final_list = []
                        if latest_stable: final_list.append(latest_stable)
                        for v in sorted_vers:
                            if v != latest_stable: final_list.append(v)
                        
                        base_choices = [ChoiceClass("CUSTOM", ">> Manual Input")] + [ChoiceClass(v, v) for v in final_list[:15]] + [ChoiceClass("back", "Back")]
                        sel = inquirer.checkbox("Select Base(s):", choices=base_choices, style=MENU_STYLE).execute()
                        
                        if "back" in sel: continue
                        if "CUSTOM" in sel:
                            man = inquirer.text("Type Version:", style=MENU_STYLE).execute().strip()
                            if man: self.execute_scan_logic(full_model, final_cscs, "base", queue_mode=queue_mode, manual_version=man, custom_imeis=custom_imeis)
                        
                        for s in sel:
                            if s not in ["CUSTOM", "back"]:
                                self.execute_scan_logic(full_model, final_cscs, "base", queue_mode=queue_mode, manual_version=s, custom_imeis=custom_imeis)
                        continue
                    else:
                        console.print(f"[{C_DIM}]No history found. Switching to manual input.[/]")
                        selected_base = inquirer.text("Enter Base Version:", style=MENU_STYLE).execute().strip()
                        if selected_base: self.execute_scan_logic(full_model, final_cscs, "base", queue_mode=queue_mode, manual_version=selected_base, custom_imeis=custom_imeis)

                elif mode == "drive": self.drive_repository_console(full_model)
                elif mode == "timeline": self.run_timeline_mode(full_model, final_cscs)
                elif mode == "reverse":
                    target_triplet = inquirer.text("Target Triplet:", style=MENU_STYLE).execute().strip()
                    json_path = os.path.join("Decrypted", f"{full_model}_{final_cscs[0]}_full.json")
                    self.reverse_check_target_against_json(
                        model=full_model,
                        cscs=final_cscs,
                        target_triplet=target_triplet,
                        json_path=json_path,
                        custom_imeis=custom_imeis,
                        silent=False
                    )
                    input("\nPress Enter...")
                elif mode == "manual": self.execute_scan_logic(full_model, final_cscs, "manual", queue_mode=queue_mode, custom_imeis=custom_imeis)
                else: self.execute_scan_logic(full_model, final_cscs, mode, queue_mode=queue_mode, custom_imeis=custom_imeis)
                
                console.input(f"\n[{C_DIM}]Cycle complete. Press Enter...[/]")

    def run_continuum_check(self):
        targets = Continuum.get_stale_targets(hours=12)
        if not targets: return
        Dashboard.header()
        console.print(f"[bold {C_PRIM}]{self.R['cycle']} CONTINUUM DETECTED[/]")
        console.print(f"[dim]Found {len(targets)} active targets from previous sessions.[/]")
        if inquirer.confirm(f"Resume scanning from last known frontiers?", default=True, style=MENU_STYLE).execute():
            for t in targets:
                console.print(f" > {t['model']} ({t['csc']}) starts at {t['frontier']}")
                self.execute_scan_logic(t['model'], [t['csc']], "manual", manual_version=t['frontier'], auto_dl=False, queue_mode=True, silent=True)
            console.print(f"\n[bold {C_OK}]Targets added to Night Shift Queue.[/]")
            time.sleep(2)
            
    def run_continuum_manual(self):
        targets = Continuum.load()
        if not targets: console.print(f"[{C_ERR}]Continuum Registry Empty.[/]"); time.sleep(2); return
        Dashboard.header()
        choices = []
        for key, t in targets.items(): choices.append(Choice(key, f"{t['model']} ({t['csc']}) │ Last: {t.get('frontier', 'N/A')}"))
        choices.append(Separator()); choices.append(Choice("back", f"{self.R['back']} Back"))
        sel = inquirer.select("CONTINUUM REGISTRY:", choices=choices, style=MENU_STYLE).execute()
        if sel == "back": return
        t = targets[sel]
        self.execute_scan_logic(t['model'], [t['csc']], "manual", manual_version=t['frontier'], auto_dl=False, queue_mode=True)

    def save_blackbox(self):
        try:
            with open(Config.BLACKBOX_FILE, 'w') as f: json.dump(list(job_queue), f)
        except: pass

    def recover_blackbox(self):
        if os.path.exists(Config.BLACKBOX_FILE):
            try:
                with open(Config.BLACKBOX_FILE, 'r') as f: saved = json.load(f)
                if saved:
                    console.print(f"[bold {C_SEC}]⚠ RESTORING SESSION ({len(saved)} items)[/]")
                    for item in saved: job_queue.append(item)
            except: pass

    def show_mission_debrief(self):
        if session_stats['uploaded'] > 0: console.print(f"\n[bold]SESSION CLOSED. Uploads: {session_stats['uploaded']}[/]")
        
    def settings_menu(self):
        while True:
            Dashboard.header()
            p_cloud = f"[{C_PRIM}]{Config.DELETE_LOCAL_AFTER_UPLOAD}[/]"
            p_dm = f"[{C_OK}]Yes[/]" if Config.ALLOW_DM_BUILDS else f"[{C_DIM}]No[/]"
            p_aria = f"[{C_OK}]Active[/]" if Config.USE_ARIA2 and shutil.which("aria2c") else f"[{C_DIM}]Inactive[/]"
            agent_rune = TelegramService.AGENTS.get(Config.AGENT_ID, Config.AGENT_ID)
            p_agent = f"[{C_ACC}]{Config.AGENT_ID}[/] ({agent_rune})"

            console.print(Panel(f"Identity: {p_agent}\nCloud Cleanup: {p_cloud}\nAllow .DM: {p_dm}\nTurbo DL: {p_aria}", title="SYSTEM CONFIGURATION", border_style=C_BORDER, width=60))
            
            sel = inquirer.select("CONFIGURATION:", choices=[
                Choice("identity", f"{self.R['man']}  Identity Protocol"), Separator(), 
                Choice("test",     f"{self.R['search']}  System Diagnostics"), 
                Choice("policy",   f"{self.R['gate']}  Cleanup Policy"), 
                Choice("dm",       f"{self.R['delta']}  Allow Delta (.DM)"), 
                Choice("aria",     f"{self.R['star']}  Turbo Download"), 
                Choice("thread",   f"{self.R['header']}  Scan Threads"), 
                Choice("back",     f"{self.R['back']}  Return")
            ], style=MENU_STYLE).execute()

            if sel == "back": break
            if sel == "identity":
                agent_choices = []
                for name, rune in TelegramService.AGENTS.items(): agent_choices.append(Choice(name, f"{name.ljust(15)} {rune}"))
                new_agent = inquirer.select("Select Active Agent:", choices=agent_choices, style=MENU_STYLE).execute()
                Config.AGENT_ID = new_agent
                if inquirer.confirm(f"Make '{new_agent}' default for future boots?", default=True, style=MENU_STYLE).execute():
                    try:
                        if os.path.exists("config.json"):
                            with open("config.json", "r") as f: data = json.load(f)
                        else: data = {}
                        data["agent_id"] = new_agent
                        with open("config.json", "w") as f: json.dump(data, f, indent=4)
                        console.print(f"[{C_OK}]Identity saved to configuration.[/]"); time.sleep(1)
                    except Exception as e: console.print(f"[{C_ERR}]Failed to save config: {e}[/]"); time.sleep(2)

            if sel == "test": SystemDiagnostics.run(self)
            if sel == "policy": Config.DELETE_LOCAL_AFTER_UPLOAD = inquirer.select("Delete local?", choices=["YES","NO","ASK"], default=Config.DELETE_LOCAL_AFTER_UPLOAD, style=MENU_STYLE).execute()
            if sel == "dm": Config.ALLOW_DM_BUILDS = inquirer.confirm("Show .DM files?", default=Config.ALLOW_DM_BUILDS, style=MENU_STYLE).execute()
            if sel == "aria": Config.USE_ARIA2 = inquirer.confirm("Use Aria2c?", default=Config.USE_ARIA2, style=MENU_STYLE).execute()
            if sel == "thread":
                try:
                    t_count = inquirer.text("Set Thread Count (4-32):", default=str(Config.MAX_THREADS), style=MENU_STYLE).execute()
                    if t_count.isdigit(): Config.MAX_THREADS = int(t_count)
                except: pass
      
    def drive_repository_console(self, filter_model=None):
        if not self.drive.is_active:
            console.print(f"[{C_ERR}]Drive not linked. Check credentials.[/]")
            time.sleep(2); return

        target_model = filter_model
        
        # 1. NAVIGATION (If no model pre-selected)
        if not target_model:
            Dashboard.header()
            with console.status(f"[bold {C_PRIM}]Indexing Repository...[/]"):
                folders = self.drive.get_all_folders() # Returns list of dicts: {'name': 'SM-S948B', 'id': ...}
            
            if not folders:
                console.print(f"[{C_ERR}]Repository Empty.[/]"); time.sleep(2); return

            # Build Hierarchy: Family -> Variant
            fam_map = defaultdict(lambda: defaultdict(str)) # {Family: {Variant: FolderName}}
            
            for f in folders:
                name = f.get('name', 'Unknown')
                # Reuse Utils logic to split SM-S948B -> S94, 8B
                if name.startswith("SM-"):
                    fam, var = Utils.split_model_variant(name)
                    fam_map[fam][var] = name
                else:
                    # Fallback for non-standard folders
                    fam_map["MISC"][name] = name

            # STEP A: FAMILY SELECTION
            fam_choices = [Choice(k, f"SM-{k} Series") for k in sorted(fam_map.keys())]
            fam_choices.append(Separator())
            fam_choices.append(Choice("back", "Back"))
            
            sel_fam = inquirer.select("SELECT FAMILY:", choices=fam_choices, style=MENU_STYLE).execute()
            if sel_fam == "back": return
            
            # STEP B: VARIANT SELECTION
            variants = fam_map[sel_fam]
            var_choices = [Choice(folder_name, folder_name) for v, folder_name in sorted(variants.items())]
            var_choices.append(Separator())
            var_choices.append(Choice("back", "Back"))
            
            target_model = inquirer.select("SELECT MODEL:", choices=var_choices, style=MENU_STYLE).execute()
            if target_model == "back": return self.drive_repository_console() # Loop back

        # 2. FILE LISTING
        while True:
            Dashboard.header()
            console.print(f"[bold {C_PRIM}]REPO ACCESS: {target_model}[/]")
            
            with console.status(f"[bold {C_ACC}]Fetching Manifest...[/]"):
                files = self.drive.list_model_files(target_model)
            
            if not files:
                console.print(f"[{C_DIM}]Folder empty.[/]")
                if filter_model: return
                input("Enter to return..."); return self.drive_repository_console()

            # [FIXED] Clean File List (No Raw Markup for InquirerPy)
            file_choices = []
            for f in files:
                f_name = f.get('name', 'Unknown')
                f_size = Utils.readable_size(f.get('size', 0))
                
                # Visual Indicator logic
                is_dm = ".DM" in f_name.upper()
                icon = "ᛞ" if is_dm else "ᛒ"
                
                # Clean Label for InquirerPy (No color tags like [#FFF])
                # We use simple unicode icons and text to prevent the "raw code" look
                label = f"{icon} {f_name}  ({f_size})"
                
                file_choices.append(Choice(value={'id': f.get('id'), 'name': f_name}, name=label))
            
            file_choices.append(Separator())
            file_choices.append(Choice("back", "Back"))

            selected = inquirer.checkbox("DOWNLOAD SELECTION:", choices=file_choices, style=MENU_STYLE).execute()

            if "back" in selected or not selected:
                if filter_model: return
                break # Return to hierarchy

            # 3. DOWNLOAD SEQUENCE
            Dashboard.header()
            for item in selected:
                if item == "back": continue
                dest = os.path.join(Config.DIR_DOWN, Utils.normalize_model(target_model), item['name'])
                
                if os.path.exists(dest):
                    console.print(f"[{C_DIM}]Skipping {item['name']} (Exists)[/]")
                    continue
                
                console.print(f"\n[bold {C_ACC}]Downloading: {item['name']}[/]")
                self.drive.download_file(item['id'], dest)
                session_stats['volume'] += os.path.getsize(dest) if os.path.exists(dest) else 0

            console.input(f"\n[{C_OK}]Batch Complete. Press Enter...[/]")
            if filter_model: return


    def night_shift_console(self):
        while True:
            Dashboard.header()
            op = inquirer.select(f"QUEUE ({len(job_queue)}):", choices=[
                Choice("run", f"{self.R['star']}  EXECUTE QUEUE"), 
                Choice("add", f"{self.R['gate']}  Add More Files"), 
                Choice("clear", f"{self.R['gate']}  Clear Queue"), 
                Choice("back", f"{self.R['back']}  Back")
            ], style=MENU_STYLE).execute()
            if op == "back": break
            elif op == "clear": job_queue.clear(); os.remove(Config.BLACKBOX_FILE) if os.path.exists(Config.BLACKBOX_FILE) else None
            elif op == "add": self.deployment_console(queue_mode=True)
            elif op == "run": self.process_queue()
            
    def process_queue(self):
        Dashboard.header()
        completed_jobs = []
        while job_queue:
            job = job_queue.popleft()
            self.save_blackbox()
            mode = job.get('mode', 'auto')
            console.print(f"\n[bold {C_PRIM}]{self.R['cycle']} PROCESSING QUEUE ({mode.upper()}): {job['fname']} ...[/]")
            res = self.process_file(job['fname'], job['url'], job['model'], mode=mode)
            if res and res.get('status') in ['fresh', 'cached', 'local_only']: completed_jobs.append(res)
        if os.path.exists(Config.BLACKBOX_FILE): os.remove(Config.BLACKBOX_FILE)
        if completed_jobs: TelegramService.send_batch(completed_jobs)
        input("Night Shift Concluded. Press Enter...")

    def run_timeline_mode(self, model, cscs):
        from rich.tree import Tree
        from rich.table import Table as RichTable 
        target_group, _ = Utils.get_multi_csc_info(cscs[0], model=model)
        known_vers = Utils.get_known_versions(model, target_group=target_group)
        if not known_vers: console.print(f"[{C_ERR}]No history found. Run a normal scan first to populate DB.[/]"); return
        sorted_hist = sorted(known_vers, key=lambda x: Utils.get_date_score(x), reverse=True)
        Dashboard.header(); console.print(f"[bold {C_PRIM}]TIMELINE: ANCHOR SELECTION[/]"); console.print("[dim]Select the version to start scanning FROM.[/]\n")
        choices = [Choice(v, f"{v}  ({Utils.decode_date(v)})") for v in sorted_hist]
        anchor_ver = inquirer.select("Select Anchor Version:", choices=choices, style=MENU_STYLE).execute()
        try:
            depth_str = inquirer.text("Scan Depth:", default="5", style=MENU_STYLE).execute()
            depth = int(depth_str) if depth_str.isdigit() else 5
        except: depth = 5
        try: start_idx = sorted_hist.index(anchor_ver); selected_seeds = sorted_hist[start_idx : start_idx + depth]
        except ValueError: selected_seeds = [anchor_ver]
        if not selected_seeds: console.print(f"[{C_ERR}]Selection Error.[/]"); return
        live_stable = None
        try:
            r = requests.get(f"{Config.FOTA_URL_BASE}/{cscs[0]}/{model}/version.xml", headers={"User-Agent": Config.USER_AGENT}, timeout=3)
            if r.status_code == 200: live_stable = ET.fromstring(r.content).find(".//latest").text.strip()
        except: pass
        console.print(f"\n[bold {C_PRIM}]SCANNING {len(selected_seeds)} VERSIONS...[/]")
        results_map = {} 
        with Progress(SpinnerColumn(), TextColumn("[dim]{task.description}"), BarColumn(), console=console, transient=True) as p:
            task = p.add_task("Scanning...", total=len(selected_seeds))
            with ThreadPoolExecutor(max_workers=Config.MAX_THREADS) as exe:
                futs = {exe.submit(self._scan_thread, model, cscs, seed, None, None, None): seed for seed in selected_seeds}
                for f in as_completed(futs):
                    seed = futs[f]; tgt, url, is_dm = f.result(); p.advance(task)
                    if tgt != "None" and tgt != seed:
                        tag = "STABLE"
                        safe_tgt = Utils.extract_safe_suffix(tgt); tgt_score = Utils.get_date_score(tgt); stable_score = Utils.get_date_score(live_stable) if live_stable else 99999999
                        if "Z" in safe_tgt.upper(): tag = "BETA"
                        elif live_stable and tgt_score > stable_score: tag = "INTERNAL"
                        else: tag = "STABLE"
                        results_map[seed] = {"target": tgt, "url": url, "is_dm": is_dm, "type": tag}
        Dashboard.header()
        legend_grid = RichTable.grid(expand=True, padding=(0, 2))
        legend_grid.add_column(justify="center", ratio=1); legend_grid.add_column(justify="center", ratio=1)
        legend_grid.add_column(justify="center", ratio=1); legend_grid.add_column(justify="center", ratio=1)
        def leg_item(icon, title, subtitle, color): return f"[bold {color}]{icon} {title}[/]\n[dim]{subtitle}[/]"
        legend_grid.add_row(leg_item("ᛋ", "SOWILO", "Beta (Z)", "#d6b24b"), leg_item("ᛒ", "BERKANO", "Internal", "#87d787"), leg_item("ᛟ", "OTHALA", "Stable", "#8aa4b8"), leg_item("ᛞ", "DAGAZ", "Delta Build", "#d46c6c"))
        console.print(Panel(legend_grid, title=f"[bold {C_PRIM}]RUNE LEGEND[/]", border_style=C_DIM))
        console.print(f"[bold {C_ACC}]TRANSITION MATRIX: {model} ({cscs[0]})[/]\n")
        tree_table = Table(box=box.SQUARE, expand=True, show_lines=True, header_style=f"bold {C_PRIM}", border_style=C_BORDER)
        tree_table.add_column("SOURCE BUILD", justify="left"); tree_table.add_column("  ", justify="center", width=2); tree_table.add_column("TARGET BUILD", justify="left"); tree_table.add_column("TYPE", justify="right")
        downloadable_choices = []
        sorted_seeds = sorted(results_map.keys(), key=lambda x: Utils.get_date_score(x))
        def clean_ver(v): return v.split('/')[0] if '/' in v else v
        for seed in sorted_seeds:
            info = results_map[seed]; tgt = info['target']; c_type = info['type']; is_dm = info['is_dm']
            seed_disp = clean_ver(seed); tgt_disp = clean_ver(tgt)
            if c_type == "BETA": style_tgt = f"bold #d6b24b"; icon = "ᛋ"
            elif c_type == "INTERNAL": style_tgt = f"bold #87d787"; icon = "ᛒ"
            else: style_tgt = f"bold #8aa4b8"; icon = "ᛟ"
            if is_dm: style_tgt = f"bold #d46c6c"; icon = "ᛞ"; c_type = "DELTA"
            if is_dm and not Config.ALLOW_DM_BUILDS: continue 
            tree_table.add_row(f"[dim]{seed_disp}[/]", "→", f"[{style_tgt}]{tgt_disp}[/]", f"[{style_tgt}]{icon} {c_type}[/]")
            f_type_plain = "DELTA" if is_dm else "FULL"
            menu_label = f"{seed_disp} -> {tgt_disp}  {icon} [{f_type_plain}]"
            downloadable_choices.append(Choice(value={"fname": Utils.generate_filename(model, cscs[0], seed, tgt, is_dm), "url": info['url'], "model": model}, name=menu_label))
        console.print(tree_table); console.print()
        if not downloadable_choices: console.print(f"[{C_DIM}]No active transitions found from this batch.[/]"); input("Enter..."); return
        selected = inquirer.checkbox("Select Transitions:", choices=downloadable_choices, style=MENU_STYLE).execute()
        if selected: self.handle_post_selection_actions(selected, model)
            
    def handle_post_selection_actions(self, selected_items, model):
        action = inquirer.select("TACTICAL DECISION:", choices=[
            Choice("queue",  f"{self.R['cycle']}  NIGHT SHIFT (Add to Queue)"), Separator(),
            Choice("auto",   f"{self.R['star']}  AUTO-PILOT (Sync & Clean)"),
            Choice("local",  f"{self.R['base']}  LOCAL ARCHIVE (Download Only)"),
            Choice("hybrid", f"{self.R['guard']}  HYBRID SYNC (Keep Both)"), Separator(),
            Choice("back",   f"{self.R['back']}  Abort / Return")
        ], style=MENU_STYLE).execute()
        if action == "back": return
        elif action == "queue":
            for item in selected_items: item['mode'] = 'auto'; job_queue.append(item)
            console.print(f"[{C_OK}]{self.R['cycle']} Added {len(selected_items)} units to Night Shift.[/]")
            self.save_blackbox(); time.sleep(1)
        elif action in ["auto", "local", "hybrid"]:
            processed = []
            console.print(f"\n[bold {C_PRIM}]>>> INITIATING {action.upper()} PROTOCOL <<<[/]")
            for item in selected_items:
                res = self.process_file(item['fname'], item['url'], model, mode=action)
                if res: processed.append(res)
            if processed: TelegramService.send_batch(processed)
            console.input(f"\n[{C_DIM}]Sequence Complete. Press Enter...[/]")
            
    def process_file(self, fname, url, model, mode="auto", size_hint=0):
        if not Utils.check_storage(): return None
        url = url.replace("&amp;", "&")
        local_path = os.path.join(Config.DIR_DOWN, Utils.normalize_model(model), fname)
        
        # --- PHASE 1: INTELLIGENCE GATHERING ---
        cloud_file_info = None
        if mode != "local":
            cloud_file_info = self.drive.find_file_fuzzy(fname, model)
        
        is_on_cloud = cloud_file_info is not None
        is_on_disk = os.path.exists(local_path)
        
        # --- PHASE 2: TACTICAL DECISION ---
        if mode == "auto":
            if is_on_cloud:
                link, size, real_name = cloud_file_info
                Dashboard.show_success_card(real_name, link, Utils.readable_size(size), cached=True)
                if is_on_disk and Config.DELETE_LOCAL_AFTER_UPLOAD == "YES": 
                    os.remove(local_path)
                return {'fname': real_name, 'link': link, 'size': Utils.readable_size(size), 'model': model, 'status': 'cached'}

        if mode == "hybrid":
            if is_on_cloud and is_on_disk:
                link, size, real_name = cloud_file_info
                Dashboard.show_success_card(real_name, link, Utils.readable_size(size), cached=True)
                return {'fname': real_name, 'link': link, 'size': Utils.readable_size(size), 'model': model, 'status': 'cached'}
                
        # --- PHASE 3: EXECUTION (Download) ---
        should_download = not is_on_disk

        if should_download:
            os.makedirs(os.path.dirname(local_path), exist_ok=True)
            try:
                is_fota_url = ("ospserver.net" in (url or "")) or ("/nspx/" in (url or ""))

                total_size = int(size_hint or 0)
                free_space = shutil.disk_usage(os.path.dirname(local_path))[2]

                if total_size > 0 and free_space < total_size:
                    console.print(f"[{C_ERR}]{self.R['guard']} CRITICAL: Insufficient Disk Space for {fname}[/]")
                    return None

                console.print(f"[bold {C_PRIM}]ᚹ INITIATING DOWNLINK PROTOCOL...[/]")

                if is_fota_url:
                    total_size = self._fota_download(
                        url=url,
                        local_path=local_path,
                        model=model,
                        size_hint=total_size
                    )
                else:
                    with requests.head(url, headers={"User-Agent": Config.USER_AGENT}, verify=False, timeout=10) as r:
                        total_size = int(r.headers.get('content-length', 0))

                    if total_size > 0 and free_space < total_size:
                        console.print(f"[{C_ERR}]{self.R['guard']} CRITICAL: Insufficient Disk Space for {fname}[/]")
                        return None

                    if Config.USE_ARIA2 and shutil.which("aria2c"):
                        cmd = [
                            "aria2c", "-x16", "-s16", "-j16", "-k1M",
                            "--file-allocation=none",
                            "--summary-interval=1",
                            "--console-log-level=warn",
                            f"--header=User-Agent: {Config.USER_AGENT}",
                            "-d", os.path.dirname(local_path),
                            "-o", os.path.basename(local_path), url
                        ]

                        with Progress(
                            TextColumn(f"  [dim]└─[/] [{C_DIM}][[/]"),
                            BarColumn(bar_width=40, complete_style=f"bold {C_PRIM}", finished_style=f"bold {C_OK}"),
                            TextColumn(f"[{C_DIM}]][/]"),
                            TextColumn(f"[bold {C_PRIM}][progress.percentage]{{task.percentage:>3.0f}}%[/]"),
                            TextColumn(f"[{C_DIM}]•[/]"),
                            TextColumn(f"[{C_DIM}]{{task.fields[speed]}}[/]"),
                            console=console
                        ) as p:
                            task = p.add_task("dl", total=100, speed="Init..")
                            process = subprocess.Popen(
                                cmd, stdout=subprocess.PIPE, stderr=subprocess.STDOUT,
                                text=True, bufsize=1, universal_newlines=True
                            )

                            for line in process.stdout:
                                if "DL:" in line:
                                    try:
                                        pct_match = re.search(r"\((\d+)%\)", line)
                                        if pct_match:
                                            p.update(task, completed=int(pct_match.group(1)))
                                        spd_match = re.search(r"DL:(\S+)", line)
                                        if spd_match:
                                            p.update(task, speed=spd_match.group(1))
                                    except Exception:
                                        pass

                            process.wait()
                            if process.returncode != 0:
                                raise Exception(f"Aria2c code {process.returncode}")

                    else:
                        with requests.get(url, stream=True, verify=False) as r, open(local_path, "wb") as f, Progress(
                            TextColumn(f"  [dim]└─[/] [{C_DIM}][[/]"),
                            BarColumn(bar_width=40, complete_style=f"bold {C_PRIM}"),
                            TextColumn(f"[{C_DIM}]][/]"),
                            TextColumn(f"[bold {C_PRIM}][progress.percentage]{{task.percentage:>3.0f}}%[/]"),
                            TextColumn(f"[{C_DIM}]•[/]"),
                            TransferSpeedColumn(),
                            TimeRemainingColumn(),
                            console=console
                        ) as p:
                            r.raise_for_status()
                            t = p.add_task("dl", total=max(total_size, 1))
                            for chunk in r.iter_content(8192):
                                if not chunk:
                                    continue
                                f.write(chunk)
                                p.update(t, advance=len(chunk))

            except Exception as e:
                console.print(f"[{C_ERR}]Download Aborted: {e}[/]")
                if os.path.exists(local_path):
                    os.remove(local_path)
                return None
            
            if Config.VERIFY_ZIP and not Utils.verify_zip(local_path): 
                console.print(f"[{C_ERR}]Corrupt Packet. Destroying...[/]")
                os.remove(local_path) 
                return None
        
        if not os.path.exists(local_path): return None
        size_str = Utils.readable_size(os.path.getsize(local_path))
        session_stats['volume'] += os.path.getsize(local_path)

        # --- PHASE 4: EXECUTION (Upload) ---
        link = None
        should_upload = (mode != "local") and (not is_on_cloud)
        
        if should_upload:
            link = self.drive.upload(local_path, model)
            if link: is_on_cloud = True 
        elif is_on_cloud:
            link = cloud_file_info[0]

        # --- PHASE 5: CLEANUP ---
        final_status = 'failed'
        
        if mode == "local":
            console.print(Panel(f"Location: {local_path}", title=f"[bold {C_OK}]{self.R['base']} ARCHIVED LOCALLY[/]", border_style=C_OK))
            final_status = 'local_only'; link = None 
            
        elif mode == "auto":
            if link:
                session_stats['uploaded'] += 1
                Dashboard.show_success_card(fname, link, size_str, cached=False)
                if Config.DELETE_LOCAL_AFTER_UPLOAD == "YES": os.remove(local_path)
                final_status = 'fresh'
                
        elif mode == "hybrid":
            if link:
                session_stats['uploaded'] += (1 if should_upload else 0)
                Dashboard.show_success_card(fname, link, size_str, cached=not should_upload)
                final_status = 'fresh' if should_upload else 'cached'

        return {'fname': fname, 'link': link, 'size': size_str, 'model': model, 'status': final_status}

if __name__ == "__main__":
    try: LogisticsController().main_menu()
    except KeyboardInterrupt: sys.exit(0)
    except Exception as e: console.print_exception()
