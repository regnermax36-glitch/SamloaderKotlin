"""
High-level FOTA client.

Improvements:
- Safer URL checks (startswith('http'))
- Basic retry backoff in do_auth
- Avoids printing during object init (library-friendly)
- Keeps existing return codes/strings for compatibility with your bot
"""

from __future__ import annotations

from datetime import datetime
import base64
import random
import hashlib
import time
import logging

from FotaAgent.Crypto.CryptUtils import generate_client_password
from FotaAgent.SyncML import SyncML
from FotaAgent.Http import register_device, send_wbxml

log = logging.getLogger(__name__)


class Client:
    def __init__(self, data: dict):
        self.Model = data.get("Model", "")
        self.DeviceId = data.get("DeviceId", "")
        self.CustomerCode = data.get("CustomerCode", "")
        self.SerialNumber = data.get("SerialNumber", "")
        self.FirmwareVersion = data.get("FirmwareVersion", "")
        self.Mcc = data.get("Mcc", "001")
        self.Mnc = data.get("Mnc", "01")
        self.FotaClientVersion = data.get("FotaClientVersion", "4.4.14")
        self.Registered = data.get("Registered", False)

        now = datetime.now()
        self.ssid = format(now.minute, "X") + format(now.second, "X")
        self.nonce = b""
        self.CurrentMessageId = 1

        self.generate_password()

        # Keep original behavior (auto-register), but don't print from inside a library.
        if not self.Registered:
            try:
                self.register()
                time.sleep(0.5)
            except Exception as e:
                log.debug("register() failed: %s", e)

    def compute_md5_auth(self) -> str:
        if not self.nonce or self.CurrentMessageId == 1:
            self.nonce = base64.b64decode(
                base64.b64encode(
                    (str(random.randint(0, 2**31 - 1)) + "SSNextNonce").encode("utf-8")
                ).decode("utf-8")
            )

        concat_str = f"{self.DeviceId}:{self.ClientPassword}"
        concat2_str = (
            f"{base64.b64encode(hashlib.md5(concat_str.encode('utf-8')).digest()).decode('utf-8')}:"
        )
        combined_b_arr = concat2_str.encode("utf-8") + self.nonce
        return base64.b64encode(hashlib.md5(combined_b_arr).digest()).decode("utf-8")

    def set_server_nonce(self, nonce_b64: str) -> None:
        self.nonce = base64.b64decode(nonce_b64)
        self.CurrentMessageId += 1

    def register(self):
        self.Registered = True
        return register_device(self)

    def generate_password(self) -> None:
        self.ClientPassword = generate_client_password(self.DeviceId, "x6g1q14r75")

    def build_device_request(self, url: str) -> bytes:
        builder = SyncML()

        builder.add_header(
            session_id=self.ssid,
            msg_id=self.CurrentMessageId,
            target_uri=url,
            source_uri=self.DeviceId,
            cred_data=self.compute_md5_auth(),
        )

        builder.add_alert(data="1201")

        builder.add_replace(
            items={
                "./DevInfo/DevId": self.DeviceId,
                "./DevInfo/Man": "Samsung",
                "./DevInfo/Mod": self.Model,
                "./DevInfo/DmV": "1.2",
                "./DevInfo/Lang": "en-US",
                "./DevInfo/Ext/DevNetworkConnType": "WIFI",
                "./DevInfo/Ext/TelephonyMcc": self.Mcc,
                "./DevInfo/Ext/TelephonyMnc": self.Mnc,
                "./DevInfo/Ext/OmcCode": self.CustomerCode,
                "./DevInfo/Ext/FotaClientVer": self.FotaClientVersion,
                "./DevInfo/Ext/DMClientVer": self.FotaClientVersion,
                "./DevInfo/Ext/ModemZeroBilling": "1",
                "./DevInfo/Ext/SIMCardMcc": self.Mcc,
                "./DevInfo/Ext/SIMCardMnc": self.Mnc,
                "./DevInfo/Ext/AidCode": self.CustomerCode,
                "./DevInfo/Ext/CountryISOCode": "sk",
            }
        )

        builder.add_alert(
            data="1226",
            item_uri="./FUMO/DownloadAndUpdate",
            item_data="0",
            item_type="org.openmobilealliance.dm.firmwareupdate.devicerequest",
        )

        return builder.get()

    def build_update_request(self, url: str, fwv: str) -> bytes:
        builder = SyncML()

        builder.add_header(
            session_id=self.ssid,
            msg_id=self.CurrentMessageId,
            target_uri=url,
            source_uri=self.DeviceId,
            cred_data="",
        )

        ref = self.CurrentMessageId - 1

        builder.add_status(
            data="212",
            msg_ref=ref,
            cmd_ref=0,
            cmd="SyncHdr",
            target_ref=self.DeviceId,
            source_ref=url.split("?")[0],
        )
        builder.add_status(
            data="200",
            msg_ref=ref,
            cmd_ref=5,
            cmd="Get",
            target_ref="./DevDetail/FwV",
        )
        builder.add_results(
            loc_uri="./DevDetail/FwV",
            data=fwv,
            msg_ref=ref,
            cmd_ref=5,
        )
        builder.add_status(
            data="200",
            msg_ref=ref,
            cmd_ref=6,
            cmd="Get",
            target_ref="./DevInfo/Ext/DevNetworkConnType",
        )
        builder.add_results(
            loc_uri="./DevInfo/Ext/DevNetworkConnType",
            data="WIFI",
            msg_ref=ref,
            cmd_ref=6,
        )
        return builder.get()

    def do_auth(self) -> str:
        url = "https://dms.ospserver.net/v1/device/magicsync/mdm"
        max_attempts = 5

        for attempt in range(max_attempts):
            try:
                resp = send_wbxml(url, self.build_device_request(url), self.Model)
            except Exception:
                time.sleep(0.5 * (attempt + 1))
                continue

            # Parse nonce and status code
            nonce_start_marker = b"SyncHdr\x00"
            nonce_start_idx = resp.find(nonce_start_marker)
            if nonce_start_idx != -1:
                nonce_start_idx += len(nonce_start_marker)
                nonce_end_idx = resp.find(b"\x00", nonce_start_idx)
                server_nonce = resp[nonce_start_idx:nonce_end_idx].decode(
                    "utf-8", errors="ignore"
                )

                code_start = nonce_end_idx + 1
                code_end = resp.find(b"\x00", code_start)
                status_code = resp[code_start:code_end].decode(
                    "utf-8", errors="ignore"
                )
            else:
                server_nonce = None
                status_code = None

            # Extract next URL (b64 marker)
            end_marker = b"\x00b64"
            end_idx = resp.find(end_marker)
            resp_url = None
            if end_idx != -1:
                start_idx = resp.rfind(b"\x00", 0, end_idx - 1)
                if start_idx != -1:
                    url_bytes = resp[start_idx + 1 : end_idx]
                    try:
                        resp_url = url_bytes.decode("utf-8")
                    except UnicodeDecodeError:
                        resp_url = None

            if server_nonce == "425":
                return "auth_failed: banned device"

            if server_nonce and server_nonce != "401":
                self.set_server_nonce(server_nonce)
                if status_code and status_code != "401" and resp_url:
                    return resp_url

            if resp_url:
                url = resp_url

            time.sleep(0.2 * (attempt + 1))

        return "auth_failed"

    def check_update(self, fvw: str) -> str:
        url = self.do_auth()
        if not url or not url.startswith("http"):
            return url or "auth_failed"

        resp = send_wbxml(url, self.build_update_request(url, fvw), self.Model)

        if b"DevInfo/Ext/DeviceRegistrationStatus" in resp:
            return "bad_csc"

        pkg_start_pattern = b"chr\x00"
        pkg_start_index = resp.find(pkg_start_pattern)
        if pkg_start_index == -1:
            return "no_pkg"

        pkg_start_index += len(pkg_start_pattern)
        pkg_end_index = resp.find(b"\x00", pkg_start_index)

        if b"\x00220\x00IMEI:" in resp and str(self.DeviceId).startswith("IMEI:"):
            return "unk_fw"

        ret = resp[pkg_start_index:pkg_end_index].decode("utf-8", errors="ignore")

        if ret == "260":
            return "no_upd"
        if ret == "261":
            return "unk_error"
        if ret == "220":
            return "unk_fw"
        return ret