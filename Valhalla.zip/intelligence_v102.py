#!/usr/bin/env python3
# -*- coding: utf-8 -*-

"""
PROJECT KILLSHOT: INTELLIGENCE V103 (OPTIMIZED)
True Integrated Grid // Command Center
"""

import os
import sys
import time
import random
import threading
import queue
import sqlite3
import csv
import glob
import json
import requests
import urllib3
import xml.etree.ElementTree as ET
from datetime import datetime
from collections import deque
import tty
import termios
import select

# --- RICH UI IMPORTS ---
try:
    from rich.console import Console
    from rich.theme import Theme
    from rich.table import Table
    from rich.panel import Panel
    from rich.text import Text
    from rich.align import Align
    from rich.live import Live
    from rich.layout import Layout
    from rich.progress import Progress, SpinnerColumn, BarColumn, TextColumn
    from rich import box
    from InquirerPy import inquirer
    from InquirerPy.base.control import Choice
    from InquirerPy.separator import Separator
    from InquirerPy.utils import get_style
except ImportError:
    print("Please install 'rich' and 'InquirerPy': pip install rich InquirerPy")
    sys.exit(1)

# -----------------------------
# Valhalla theme bootstrap
# -----------------------------
# Ensure theme constants exist even when this module is run standalone.
try:
    from valhalla_themes import get_runtime_theme
    _VT = get_runtime_theme()
    C_PRIM = _VT.C_PRIM
    C_SEC = _VT.C_SEC
    C_ACC = _VT.C_ACC
    C_DIM = _VT.C_DIM
    C_OK = _VT.C_OK
    C_ERR = _VT.C_ERR
    C_TEXT = _VT.C_TEXT
    C_BORDER = getattr(_VT, "C_BORDER", "#8A8A8A")
    # Legacy aliases used in some UI blocks
    C_GOLD = getattr(_VT, "C_GOLD", C_PRIM)
    C_BLUE = getattr(_VT, "C_BLUE", C_ACC)
    C_STEEL = getattr(_VT, "C_STEEL", C_SEC)
    MENU_STYLE = getattr(_VT, "MENU_STYLE", None)
except Exception:
    # Safe fallbacks (pastel-ish)
    C_PRIM = "#d6b24b"
    C_SEC = "#a8a8a8"
    C_ACC = "#6c9cd4"
    C_ERR = "#d46c6c"
    C_OK = "#87d787"
    C_DIM = "#585858"
    C_BORDER = "#8a8a8a"
    C_TEXT = "#eeeeee"
    C_GOLD, C_BLUE, C_STEEL = C_PRIM, C_ACC, C_SEC
    MENU_STYLE = None

# --- FOTA AGENT CHECK & OPTIMIZATION ---
try:
    from FotaAgent.Client import Client
    from FotaAgent.Http import parse_descripter, send_wbxml
    import FotaAgent.Http as FotaHttp
    from FotaAgent.SyncML import SyncML
except ImportError:
    print("CRITICAL ERROR: 'FotaAgent' library not found.")
    sys.exit(1)

# Disable SSL Warnings
import urllib3
urllib3.disable_warnings(urllib3.exceptions.InsecureRequestWarning)

# ==============================================================================
# ENGINE UPGRADE: CONNECTION POOLING & MONKEY PATCHES
# ==============================================================================
import requests
from requests.adapters import HTTPAdapter

# 1. EXPAND CONNECTION POOL
# Expand the internal session pool from 10 to 100 to easily support 16-32 threads
if hasattr(FotaHttp, 'session'):
    adapter = HTTPAdapter(pool_connections=100, pool_maxsize=100)
    FotaHttp.session.mount('http://', adapter)
    FotaHttp.session.mount('https://', adapter)

# 2. CHINA ROUTING & SPOOFING PATCHES
def custom_build_device_request(self, url):
    builder = SyncML()
    builder.add_header(session_id=self.ssid, msg_id=self.CurrentMessageId, target_uri=url, source_uri=self.DeviceId, cred_data=self.compute_md5_auth())
    builder.add_alert(data="1201")
    iso_code = "CN" if self.Mcc == "460" else "US"
    lang = "zh-CN" if self.Mcc == "460" else "en-US"
    builder.add_replace(items={
        "./DevInfo/DevId": self.DeviceId, "./DevInfo/Man": "Samsung", "./DevInfo/Mod": self.Model,
        "./DevInfo/DmV": "1.2", "./DevInfo/Lang": lang, "./DevInfo/Ext/DevNetworkConnType": "WIFI",
        "./DevInfo/Ext/TelephonyMcc": self.Mcc, "./DevInfo/Ext/TelephonyMnc": self.Mnc,
        "./DevInfo/Ext/OmcCode": self.CustomerCode, "./DevInfo/Ext/FotaClientVer": self.FotaClientVersion,
        "./DevInfo/Ext/DMClientVer": self.FotaClientVersion, "./DevInfo/Ext/ModemZeroBilling": "1",
        "./DevInfo/Ext/SIMCardMcc": self.Mcc, "./DevInfo/Ext/SIMCardMnc": self.Mnc,
        "./DevInfo/Ext/AidCode": self.CustomerCode, "./DevInfo/Ext/CountryISOCode": iso_code,
    })
    builder.add_alert(data="1226", item_uri="./FUMO/DownloadAndUpdate", item_data="0", item_type="org.openmobilealliance.dm.firmwareupdate.devicerequest")
    return builder.get()

def custom_do_auth(self):
    url = "https://chn-fota-dms.samsungdm.com/v1/device/magicsync/mdm" if self.Mcc == "460" else "https://dms.ospserver.net/v1/device/magicsync/mdm"
    for attempt in range(5):
        resp = send_wbxml(url, self.build_device_request(url), self.Model)
        
        nonce_start_idx = resp.find(b'SyncHdr\x00')
        if nonce_start_idx != -1:
            nonce_start_idx += 8
            server_nonce = resp[nonce_start_idx:resp.find(b'\x00', nonce_start_idx)].decode('utf-8')
            code_start = resp.find(b'\x00', nonce_start_idx) + 1
            status_code = resp[code_start:resp.find(b'\x00', code_start)].decode('utf-8')
        else: server_nonce = status_code = None

        end_idx = resp.find(b'\x00b64')
        if end_idx != -1:
            start_idx = resp.rfind(b'\x00', 0, end_idx - 1)
            resp_url = resp[start_idx + 1:end_idx].decode('utf-8') if start_idx != -1 else None
        else: resp_url = None
        
        if resp_url is not None: url = resp_url
        if server_nonce == "425": return "auth_failed: banned device"
        elif server_nonce != "401":
            self.set_server_nonce(server_nonce)
            if status_code != "401": return url
    return "auth_failed"

Client.build_device_request = custom_build_device_request
Client.do_auth = custom_do_auth
# ==============================================================================

# Disable SSL Warnings
urllib3.disable_warnings(urllib3.exceptions.InsecureRequestWarning)

# Valhalla Rich theme (forces Progress visuals to theme colors, avoids default Rich purple/green)
_VALHALLA_RICH_THEME = Theme({
    "bar.back": C_DIM,
    "bar.complete": C_PRIM,
    "bar.finished": C_OK,
    "progress.percentage": f"bold {C_PRIM}",
    "progress.data.speed": C_ACC,
    "progress.spinner": C_ACC,
})
console = Console(theme=_VALHALLA_RICH_THEME, highlight=False)
# --- THEME: VALHALLA GOLD ---
C_PRIM    = "#d6b24b"   # Valhalla Gold
C_SEC     = "#a8a8a8"   # Slate Grey
C_ACC     = "#6c9cd4"   # Soft Blue
C_ERR     = "#d46c6c"   # Soft Red
C_OK      = "#87d787"   # Pale Green
C_DIM     = "#585858"   # Dark Grey
C_BORDER  = "#8a8a8a"   # Border Grey
C_TEXT    = "#eeeeee"   # Off-White

# Place this at the top level of the file, before class Config
GLOBAL_BANNER = """
   ᛉ ᛟ ᚦ ᛋ
   V A L H
   A L L A"""

# --- CONFIG & STATE ---
class Config:
    DIR_DB        = "database"
    DIR_JSON      = "jsons"
    DIR_DECRYPTED = "Decrypted"
    DB_FILE       = "fumo_history.db"
    USER_AGENT    = "SAMSUNG-Android"
    
    # Flags
    PAUSE_EVENT = threading.Event()
    PAUSE_EVENT.set() 
    BAN_DETECTED = False
    STOP_FLAG = False  # Controlled by Scanner init

    # --- PRIORITY SORTING ---
    PRIORITY_CSCS = [
        "EUX", "INS", "XXV", "THL", "XID", "XSG", "ILO", "SER", "ZTO", 
        "GCF", "TFN", "XAA", "KOO", "CHC" 
    ]

    _OXM = ["EUX", "EUY", "EUB", "DBT", "BTU", "ITV", "XEF", "XEU", "XEZ", "ROM", "SEE", "AUT", "PHN", "LUX", "NEE", "ATO", "SEB", "BGL", "ORX", "EUR", "AMO", "FTM", "OPV", "XEC", "BOG", "MOT", "MEO", "SFR", "PRT", "TPH", "XEH", "VDF", "VIP", "CNX", "COA", "ORO", "TSR", "SIM", "CRO", "TRA", "TOP", "MSR", "SWC", "VDI", "EIR", "H3G", "O2U", "VOD", "EVR", "CPW", "BTB", "BTE"]
    _OXE = ["SER", "CAU", "SKZ", "SEK", "CAC", "UZB", "KZK", "RUC"]
    _OJM = ["KSA", "UAE", "XSG", "MID", "EGY", "PAK", "TUR", "AFR", "KEN", "TUN", "MEA", "LYS", "ACR", "AFG", "MWD", "FWD", "MRT", "ALG", "XFA", "XFE", "XFV", "DKR", "ECT", "EON", "FAU", "JDI", "ILP", "ILO"]
    _OLM = ["XXV", "THL", "XID", "SIN", "STH", "GLB", "SMA", "XTE", "XME", "CAL", "MM1", "MYM", "LAO", "CAM", "NPL", "SLK", "BNG", "BKD", "INS", "INU", "NPB", "XSP", "XTC", "ATC", "XNZ", "TNZ", "VNZ", "XSA", "OPS", "TEL", "VAU", "HUT"]
    _OWO = ["ZTO", "ZTM", "ZVV", "ZCL", "MXO", "TCE", "ARO", "ANC", "CTI", "PSN","CHO", "CHL", "CHT", "CHE", "COO", "COM", "COB", "COL", "PEO", "PET","SAM", "TPA", "TPR", "GTO", "PGU", "TGU", "BVO", "BVE", "EON", "UPO","ZTA", "MVL", "GTG", "TIG", "UFN", "DSA", "DSG", "LRA", "FMC", "VTR","BMC", "KDO"]

    _IND = ["INS", "INU"] 

    CSC_MAP = {
        "MASTER OXM (Euro/Asia/ME/India)": list(set(_OXM + _OXE + _OJM + _OLM + _IND)), 
        "OXM (Europe/Global)": _OXM,
        "OXE (Russia/CIS)": _OXE,
        "OJM (Middle East/Africa)": _OJM,
        "OLM (Asia/Pacific)": _OLM,
        "OWO (Latin America)": _OWO,
        "IND (India)": _IND,
        "USA (U - Carrier)": ["VZW", "TMB", "ATT", "USC", "CCT", "CHA", "DSH", "SPR", "XAA", "AIO", "BST", "XAS", "TFN", "TMK", "XAG", "GCF", "WWD"],
        "USA (U1 - Unlocked)": ["XAA", "VZW", "TMB", "ATT", "USC", "DSA", "DSG", "LRA", "ACG", "FKR", "XAR", "TFN", "TMK", "GCF"],
        "KOREA (N Model)": ["KOO", "SKC", "LUC", "KTC"],
        "CHINA (0 Model)": ["CHC", "CHM", "CTC"],
        "CANADA (W Model)": ["XAC", "VMC", "RWC", "TLS", "KDO", "PMB", "VTR", "BMC", "ESK"],
        "JAPAN": ["DCM", "KDI", "SBM", "RAK", "XJP"],
        "TEST / FACTORY": ["GCF", "WWD", "VPP", "UEI"] 
    }


# ==============================================================================
# 1. DATABASE & DATA HANDLING
# ==============================================================================
class Database:
    @staticmethod
    def init():
        if not os.path.exists(Config.DIR_DB): os.makedirs(Config.DIR_DB)
        path = os.path.join(Config.DIR_DB, Config.DB_FILE)
        conn = sqlite3.connect(path)
        c = conn.cursor()
        c.execute('''
            CREATE TABLE IF NOT EXISTS firmware_hits (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                finder_name TEXT, device_model TEXT, imei TEXT, csc TEXT,
                request_base_version TEXT, found_pda TEXT, is_fumo INTEGER,
                fota_url TEXT, dm_url TEXT, raw_response TEXT,
                timestamp DATETIME DEFAULT CURRENT_TIMESTAMP,
                UNIQUE (imei) ON CONFLICT REPLACE
            )
        ''')
        c.execute('''
            CREATE TABLE IF NOT EXISTS valid_imeis (
                imei TEXT PRIMARY KEY,
                model TEXT,
                last_seen DATETIME DEFAULT CURRENT_TIMESTAMP
            )
        ''')
        conn.commit()
        conn.close()

    @staticmethod
    def save_hit(data):
        try:
            path = os.path.join(Config.DIR_DB, Config.DB_FILE)
            conn = sqlite3.connect(path)
            c = conn.cursor()
            c.execute('''
                INSERT OR REPLACE INTO firmware_hits (
                    finder_name, device_model, imei, csc, request_base_version,
                    found_pda, is_fumo, fota_url, dm_url, raw_response, timestamp
                ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, CURRENT_TIMESTAMP)
            ''', (
                data.get("finder"), data.get("model"), data.get("imei"), 
                data.get("csc"), data.get("base"), data.get("pda"), 
                1 if data.get("type") == "FUMO" else 0,
                data.get("url") if data.get("type") != "DM" else "",
                data.get("url") if data.get("type") == "DM" else "",
                data.get("raw")
            ))
            c.execute("INSERT OR REPLACE INTO valid_imeis (imei, model) VALUES (?, ?)", 
                      (data.get("imei"), data.get("model")))
            conn.commit()
            conn.close()
        except Exception: pass

    @staticmethod
    def save_valid_imei(imei, model):
        try:
            path = os.path.join(Config.DIR_DB, Config.DB_FILE)
            conn = sqlite3.connect(path)
            c = conn.cursor()
            c.execute("INSERT OR REPLACE INTO valid_imeis (imei, model) VALUES (?, ?)", (imei, model))
            conn.commit()
            conn.close()
        except: pass

    @staticmethod
    def get_last_valid_imei(model):
        try:
            path = os.path.join(Config.DIR_DB, Config.DB_FILE)
            conn = sqlite3.connect(path)
            c = conn.cursor()
            c.execute("SELECT imei FROM firmware_hits WHERE device_model LIKE ? ORDER BY timestamp DESC LIMIT 1", (f"%{model}%",))
            res = c.fetchone()
            if res: return res[0]
            c.execute("SELECT imei FROM valid_imeis WHERE model LIKE ? ORDER BY last_seen DESC LIMIT 1", (f"%{model}%",))
            res = c.fetchone()
            return res[0] if res else None
        except: return None

    @staticmethod
    def get_stats():
        if not os.path.exists(os.path.join(Config.DIR_DB, Config.DB_FILE)): return 0, 0
        try:
            conn = sqlite3.connect(os.path.join(Config.DIR_DB, Config.DB_FILE))
            c = conn.cursor()
            c.execute("SELECT COUNT(*) FROM firmware_hits")
            hits = c.fetchone()[0]
            c.execute("SELECT COUNT(*) FROM valid_imeis")
            valid = c.fetchone()[0]
            conn.close()
            return hits, valid
        except: return 0, 0
        
    @staticmethod
    def get_recent_tacs(model):
        try:
            path = os.path.join(Config.DIR_DB, Config.DB_FILE)
            conn = sqlite3.connect(path)
            c = conn.cursor()
            c.execute("""
                SELECT DISTINCT substr(imei, 1, 8) as tac 
                FROM valid_imeis 
                WHERE model = ? 
                ORDER BY last_seen DESC LIMIT 5
            """, (model,))
            rows = c.fetchall()
            conn.close()
            return [r[0] for r in rows if r[0] and len(r[0]) == 8]
        except: return []

    @staticmethod
    def get_smart_csc_priority(model, tac=None):
        try:
            path = os.path.join(Config.DIR_DB, Config.DB_FILE)
            conn = sqlite3.connect(path)
            c = conn.cursor()
            if tac:
                c.execute("""
                    SELECT csc, COUNT(*) as hits 
                    FROM firmware_hits 
                    WHERE device_model = ? AND imei LIKE ? 
                    GROUP BY csc 
                    ORDER BY hits DESC
                """, (model, f"{tac}%"))
            else:
                c.execute("""
                    SELECT csc, COUNT(*) as hits 
                    FROM firmware_hits 
                    WHERE device_model = ? 
                    GROUP BY csc 
                    ORDER BY hits DESC
                """, (model,))
            rows = c.fetchall()
            conn.close()
            return [r[0] for r in rows]
        except: return []
       

# ==============================================================================
# 2. CORE LOGIC
# ==============================================================================
class Utils:
    @staticmethod
    def luhn(imei_prefix):
        digits = [int(x) for x in imei_prefix]
        checksum = 0
        for i, digit in enumerate(reversed(digits)):
            if i % 2 == 0:
                doubled = digit * 2
                checksum += doubled if doubled < 10 else doubled - 9
            else: checksum += digit
        return str((10 - (checksum % 10)) % 10)

    @staticmethod
    def gen_sequential(start_imei, count):
        res = []
        try:
            clean = start_imei[:14]
            start_int = int(clean)
            for i in range(count):
                base = str(start_int + i)
                res.append(base + Utils.luhn(base))
        except: pass
        return res
        
    @staticmethod
    def gen_batch_jump(start_imei, total_count, batch_size, jump_step):
        res = []
        try:
            clean = start_imei[:14]
            start_int = int(clean)
            total_count = int(total_count)
            batch_size = max(1, int(batch_size))
            jump_step = int(jump_step)

            for i in range(total_count):
                batch_index = i // batch_size
                offset_in_batch = i % batch_size
                base_int = start_int + (batch_index * jump_step) + offset_in_batch
                base = str(base_int)
                res.append(base + Utils.luhn(base))
        except: pass
        return res
        

    @staticmethod
    def fetch_latest(model, csc):
        candidate_urls = []
        if csc in ["CHC", "CHM", "CTC"]:
            candidate_urls.append(f"https://cn-fota-cloud-dn.ospserver.net/firmware/{csc}/{model}/version.xml")
            candidate_urls.append(f"http://cn-fota-cloud-dn.ospserver.net/firmware/{csc}/{model}/version.xml")
        candidate_urls.append(f"https://fota-cloud-dn.ospserver.net/firmware/{csc}/{model}/version.xml")
        
        for url in candidate_urls:
            try:
                to = 4 if "cn-fota" in url else 10
                r = requests.get(url, headers={"User-Agent": Config.USER_AGENT}, timeout=to, verify=False)
                if r.status_code == 200:
                    root = ET.fromstring(r.content)
                    latest = root.find(".//latest")
                    if latest is not None: 
                        return latest.text.strip()
            except: continue
        return None
        
    @staticmethod
    def get_smart_date_codes(offset_months=0):
        # Synced with Valhalla Standard
        YEAR_MAP = {
            2023: 'W', 2024: 'X', 2025: 'Y', 2026: 'Z', 
            2027: 'A', 2028: 'B', 2029: 'C'
        }
        now = datetime.now()
        total_months = now.month + offset_months
        y_offset = (total_months - 1) // 12
        target_year = now.year + y_offset
        target_month = ((total_months - 1) % 12) + 1
        
        y_char = YEAR_MAP.get(target_year, '?')
        MONTH_MAP = "0ABCDEFGHIJKL" 
        m_char = MONTH_MAP[target_month] if target_month <= 12 else '?'
        return y_char, m_char

    @staticmethod
    def load_tacs_from_csv(model_filter):
        tacs = []
        if not os.path.exists("tacs.csv"): return []
        try:
            with open("tacs.csv", "r", encoding="utf-8", errors="ignore") as f:
                reader = csv.DictReader(f)
                m_filter = model_filter.replace("SM-", "").upper()
                for row in reader:
                    t_name = str(row.get("Telstra Model Name", "")).upper()
                    o_name = str(row.get("Optus Model Name", "")).upper()
                    if m_filter in t_name or m_filter in o_name:
                        val = str(row.get("TAC", "")).strip()
                        if val.isdigit(): tacs.append(val)
        except: pass
        return list(set(tacs))
        
    @staticmethod
    def get_known_versions(model):
        bare = model.replace("SM-", "").strip().upper()
        candidates = set()
        files = glob.glob(os.path.join(Config.DIR_JSON, f"*{bare}*.json")) + \
                glob.glob(os.path.join(Config.DIR_DECRYPTED, f"*{bare}*.json"))
        for f in files:
            try:
                with open(f, 'r') as fd:
                    d = json.load(fd)
                    l = []
                    if isinstance(d, list): l = d
                    elif "firmwares" in d: l = d["firmwares"]
                    elif "latest_firmwares" in d: l = d["latest_firmwares"]
                    elif model in d: l = d[model]
                    
                    for i in l:
                        v = ""
                        if isinstance(i, str): v = i
                        elif isinstance(i, dict):
                            v = i.get("triplet", "")
                            if not v or "/" not in v:
                                raw_ver = i.get("version", "")
                                if "/" in raw_ver: v = raw_ver
                            if not v or "/" not in v:
                                pda = i.get("pda", "") or i.get("ap", "")
                                csc = i.get("csc", "")
                                phone = i.get("phone", "") or i.get("cp", "")
                                if pda and csc and phone:
                                    v = f"{pda}/{csc}/{phone}"
                        if v and "/" in v and len(v) > 10: 
                             candidates.add(v)
            except: continue
        return sorted(list(candidates), reverse=True)


# ==============================================================================
# 3. UI SYSTEM
# ==============================================================================
class Dashboard:
    @staticmethod
    def get_logo_text():
        # Valhalla ASCII Logo
        return Text("""
   ᛉ ᛟ ᚦ ᛋ
   V A L H
   A L L A""", style=f"bold {C_PRIM}")
   
    @staticmethod
    def header():
        # [FIX] Use console.clear() instead of os.system/reset codes
        # This prevents the 'glitch' where text gets overwritten or cursor vanishes
        console.clear()
        
        # Matches main.py layout
        left = Dashboard.get_logo_text()
        
        right = Table.grid(padding=(0, 1))
        right.add_column(justify="left")
        right.add_row(Text("VALHALLA HUB", style=f"bold {C_TEXT}"))
        right.add_row(Text("INTELLIGENCE MODULE", style=f"{C_SEC}"))
        right.add_row(Text(f"TIME  {time.strftime('%Y-%m-%d %H:%M:%S')}", style=C_DIM))

        top = Table.grid(expand=True)
        top.add_column(ratio=2)
        top.add_column(ratio=4)
        top.add_row(Align.left(left), Align.left(right))
        
        console.print(Panel(top, border_style=C_DIM, box=box.ROUNDED, padding=(0, 1)))

        h_hits, h_valid = Database.get_stats()
        
        status_grid = Table.grid(expand=True, padding=(0, 1))
        status_grid.add_column(justify="center", ratio=1)
        status_grid.add_column(justify="center", ratio=1)
        
        def badge(label, val, color):
            return f"[bold {C_TEXT}]{label}[/]\n[bold {color}]{val}[/]"

        status_grid.add_row(
            badge("DB RECORDS ᛞ", h_hits, C_OK),
            badge("VALID IMEIS ᛉ", h_valid, C_ACC)
        )
        console.print(Panel(status_grid, border_style=C_DIM, box=box.ROUNDED, padding=(0, 0)))
        console.print()


    @staticmethod
    def show_ban_alert(reason="Unknown"):
        print("\033c", end="") 
        os.system('cls' if os.name == 'nt' else 'clear')
        
        panel = Panel(
            Align.center(
                f"[bold {C_ERR}]⚠ NETWORK TRAFFIC BLOCKED ⚠[/]\n"
                f"[dim]Reason: {reason}[/]\n\n"
                f"[{C_ACC}]System has paused operations to protect your IP.[/]\n"
                f"1. Toggle VPN / Airplane Mode.\n"
                f"2. Wait 5 seconds.\n"
                f"3. Press [bold white]ENTER[/] to resume.\n"
            ),
            title=f"[bold {C_ERR}]CRITICAL HALT[/]",
            border_style=C_ERR,
            box=box.HEAVY
        )
        console.print(panel)


# ==============================================================================
# 4. SCANNER ENGINE
# ==============================================================================


class Scanner:
    def __init__(self, model, cscs, version, imeis, threads, finder_name):
        # Force State Reset
        Config.STOP_FLAG = False
        Config.PAUSE_EVENT.set()
        
        self.model = model
        priority_subset = [c for c in Config.PRIORITY_CSCS if c in cscs]
        remainder = [c for c in cscs if c not in priority_subset]
        self.cscs = priority_subset + remainder
        self.version = version if version else "Unknown"
        self.queue = queue.Queue()
        for i in imeis: self.queue.put(i)
        self.threads = threads
        self.finder = finder_name
        self.total = len(imeis)
        
        if imeis:
            first, last = imeis[0], imeis[-1]
            self.imei_start = first[0] if isinstance(first, tuple) else first
            self.imei_end = last[0] if isinstance(last, tuple) else last
        else:
            self.imei_start, self.imei_end = "N/A", "N/A"
            self.current_imei = "Initializing..." 
        
        self.stats = {"scanned": 0, "hits": 0, "valid": 0, "errors": 0, "bad_csc": 0}
        self.logs = deque(maxlen=18) 
        self.start_time = time.time()
        self.ban_reason = ""
        self.session_hits = [] 
        self.csc_leaderboard = {}
        
        # [FIX] Layout Ratios: 
        # Logs get ratio 2 (66%), Leaderboard gets ratio 1 (33%) -> More space for regions
        self.layout = Layout()
        self.layout.split_column(
            Layout(name="top", size=8),      
            Layout(name="stats", size=5),    
            Layout(name="menu", size=3),     
            Layout(name="progress", size=3), 
            Layout(name="tables", size=20)   
        )
        self.layout["tables"].split_row(
            Layout(name="logs", ratio=3), 
            Layout(name="leaderboard", ratio=2)
        )
        
        # Delays
        if any(x in model for x in ["U", "U1", "W"]):
            self.min_delay, self.max_delay = 0.2, 0.8
        else:
            self.min_delay, self.max_delay = 0.1, 0.3

    def input_listener(self):
        def get_key():
            fd = sys.stdin.fileno()
            old_settings = termios.tcgetattr(fd)
            try:
                tty.setcbreak(fd)
                if select.select([sys.stdin], [], [], 0.1)[0]:
                    return sys.stdin.read(1)
            finally:
                termios.tcsetattr(fd, termios.TCSADRAIN, old_settings)
            return None

        while not Config.STOP_FLAG:
            k = get_key()
            if k == ' ': 
                if Config.PAUSE_EVENT.is_set():
                    Config.PAUSE_EVENT.clear()
                    self.log(f"[bold {C_PRIM}]PAUSED (Press SPACE to Resume)[/]")
                else:
                    Config.PAUSE_EVENT.set()
                    self.log(f"[bold {C_OK}]RESUMED[/]")
            elif k in ['s', 'S', 'q', 'Q', 'b', 'B']: Config.STOP_FLAG = True
            elif k in ['m', 'M']: Config.PAUSE_EVENT.clear()
            time.sleep(0.1)

    def log(self, msg):
        ts = datetime.now().strftime("%H:%M:%S")
        self.logs.append(f"[{C_DIM}]{ts}[/] {msg}")
        
    def format_build(self, full_pda):
        """
        Show build in the victory table as:
          AP/CSC/CP > AP/CSC/CP
        Using the last 5 chars of each segment (e.g. 8BZB3).
        Handles DM suffix like '8CZB3.DM' by removing '.DM' before trimming.
        If only 1 segment exists, it will be repeated to 3 parts.
        """
        def _clean(seg: str) -> str:
            seg = (seg or "").strip()
            if not seg:
                return "-----"
            # If DM suffix exists, remove it for display (TYPE already shows DM)
            # Works for '8CZB3.DM' or '.../8CZB3.DM/...'
            seg = seg.replace(".DM", "").replace(".dm", "")
            return seg
    
        def _last5(seg: str) -> str:
            seg = _clean(seg)
            if seg == "-----":
                return seg
            return seg[-5:] if len(seg) >= 5 else seg
    
        try:
            base_parts = str(self.version).split("/") if self.version else []
            found_parts = str(full_pda).split("/") if full_pda else []
    
            def _norm3(parts):
                parts = [p for p in parts if p is not None and str(p).strip() != ""]
                if not parts:
                    parts = ["-----"]
                if len(parts) == 1:
                    parts = [parts[0], parts[0], parts[0]]
                elif len(parts) == 2:
                    parts = [parts[0], parts[1], parts[1]]
                else:
                    parts = parts[:3]
                return parts
    
            base_parts = _norm3(base_parts)
            found_parts = _norm3(found_parts)
    
            base_disp = "/".join(_last5(p) for p in base_parts)
            found_disp = "/".join(_last5(p) for p in found_parts)
    
            return f"{base_disp} > {found_disp}"
        except Exception:
            return str(full_pda)
    def worker(self):
        while not Config.STOP_FLAG:
            Config.PAUSE_EVENT.wait()
    
            try:
                item = self.queue.get(timeout=1)
            except queue.Empty:
                break
    
            # Item can be (imei, specific_csc) or just imei
            if isinstance(item, tuple):
                imei, specific_csc = item
                task_cscs = [specific_csc]
            else:
                imei = item
                task_cscs = sorted(
                    self.cscs,
                    key=lambda x: self.csc_leaderboard.get(x, {}).get("total", 0),
                    reverse=True
                )
    
            self.current_imei = str(imei)
    
            did_requeue = False
            should_skip_rest = False
    
            # If auth fails once for this IMEI, it will fail for all CSCs => skip remaining CSCs
            auth_failed_for_imei = False
            auth_logged_for_imei = False
    
            for csc in task_cscs:
                if Config.STOP_FLAG or did_requeue or should_skip_rest or auth_failed_for_imei:
                    break
    
                Config.PAUSE_EVENT.wait()
                time.sleep(random.uniform(self.min_delay, self.max_delay))
    
                # Init leaderboard entry if missing
                if csc not in self.csc_leaderboard:
                    self.csc_leaderboard[csc] = {"valid": 0, "found": 0, "total": 0}
    
                resp = ""
                attempts = []
                if csc in ["CHC", "CHM", "CTC"]:
                    attempts.append(("460", "China"))
                    attempts.append(("310", "Global"))
                else:
                    attempts.append(("310", "Global"))
    
                for mcc, _mode in attempts:
                    if Config.STOP_FLAG or did_requeue or should_skip_rest or auth_failed_for_imei:
                        break
    
                    try:
                        client = Client({
                            "Model": self.model,
                            "Registered": True,
                            "Mcc": mcc,
                            "Mnc": "01",
                            "FotaClientVersion": "4.4.14"
                        })
                        client.DeviceId = f"IMEI:{imei}"
                        client.CustomerCode = csc
                        client.CurrentMessageId = 1
                        client.generate_password()
    
                        try:
                            resp = str(client.check_update(self.version))
                        except Exception as client_err:
                            err_l = str(client_err).lower()
    
                            # AUTH FAIL -> skip remaining CSCs for this IMEI (log once)
                            if ("auth_failed" in err_l) or ("unauthorized" in err_l) or ("401" in err_l):
                                self.stats["errors"] += 1
                                auth_failed_for_imei = True
                                if not auth_logged_for_imei:
                                    auth_logged_for_imei = True
                                    self.log(f"[{C_ERR}]AUTH FAILED[/] {imei} | {csc}  → skipping remaining CSCs")
                                break
    
                            # Treat short 403/auth as fatal for this IMEI too
                            if ("403" in err_l) or ("auth" in err_l):
                                self.stats["errors"] += 1
                                auth_failed_for_imei = True
                                if not auth_logged_for_imei:
                                    auth_logged_for_imei = True
                                    self.log(f"[{C_ERR}]AUTH FAILED[/] {imei} | {csc}  → skipping remaining CSCs")
                                break
    
                            raise
    
                        resp_l = resp.lower()
    
                        # AUTH FAIL in response string -> skip remaining CSCs for this IMEI (log once)
                        if ("auth_failed" in resp_l) or ("unauthorized" in resp_l) or ("401" in resp_l):
                            self.stats["errors"] += 1
                            auth_failed_for_imei = True
                            if not auth_logged_for_imei:
                                auth_logged_for_imei = True
                                self.log(f"[{C_ERR}]AUTH FAILED[/] {imei} | {csc}  → skipping remaining CSCs")
                            break
    
                        # Existing ban/access denied handling
                        if ("403" in resp) or ("Auth" in resp) or ("Access Denied" in resp):
                            # If it's short auth/403, don't requeue (just fatal for this IMEI)
                            if len(resp) < 200:
                                self.stats["errors"] += 1
                                auth_failed_for_imei = True
                                if not auth_logged_for_imei:
                                    auth_logged_for_imei = True
                                    self.log(f"[{C_ERR}]AUTH FAILED[/] {imei} | {csc}  → skipping remaining CSCs")
                                break
    
                            # Big/HTML/ban page => pause + requeue the IMEI
                            Config.BAN_DETECTED = True
                            self.ban_reason = "HTTP 403 / Access Denied"
                            Config.PAUSE_EVENT.clear()
                            self.queue.put(item)
                            did_requeue = True
                            break
    
                        # FOUND
                        if any(x in resp for x in ["fota", ".zip", ".DM", "dms.ospserver"]):
                            desc = parse_descripter(resp, self.version) or {}
                            pda = desc.get("updateFwV", "Unknown")
                            url = desc.get("objectURI", "")
    
                            if (not url) and ("http" in resp):
                                url = next((p.strip() for p in resp.split(",") if p.strip().startswith("http")), "")
    
                            if (pda == "Unknown" or not pda) and url:
                                pda = url.split("/")[-1].split("?")[0]
    
                            if pda == "Unknown" and (".DM" in resp or ".DM" in url):
                                pda = "DM_UPDATE_FOUND"
    
                            type_s = "DM" if (".DM" in url.upper() or ".DM" in pda.upper()) else "FUMO"
    
                            self.stats["hits"] += 1
                            self.stats["valid"] += 1
    
                            # Leaderboard (FOUND)
                            self.csc_leaderboard[csc]["found"] += 1
                            self.csc_leaderboard[csc]["total"] += 1
    
                            type_color = C_ERR if type_s == "DM" else C_OK
                            self.log(f"[bold {type_color}]{type_s:<5}[/] {imei} | {csc}")
    
                            self.session_hits.append({
                                "imei": imei,
                                "csc": csc,
                                "pda": self.format_build(pda),
                                "type": type_s
                            })
    
                            Database.save_hit({
                                "finder": self.finder,
                                "model": self.model,
                                "imei": imei,
                                "csc": csc,
                                "base": self.version,
                                "pda": pda,
                                "type": type_s,
                                "url": url,
                                "raw": resp
                            })
    
                            should_skip_rest = True
                            break
    
                        # VALID
                        if "no_upd" in resp:
                            self.stats["valid"] += 1
                            Database.save_valid_imei(imei, self.model)
    
                            # Leaderboard (VALID)
                            self.csc_leaderboard[csc]["valid"] += 1
                            self.csc_leaderboard[csc]["total"] += 1
    
                            self.log(f"[{C_ACC}]VALID[/] {imei} | {csc}")
                            should_skip_rest = True
                            break
    
                        # BAD CSC
                        if "bad_csc" in resp:
                            self.stats["bad_csc"] += 1
                            self.log(f"[{C_DIM}]BAD CSC[/] {imei} | {csc}")
                            # keep trying other CSCs unless auth_failed_for_imei happens
                            continue
    
                        # Unknown response
                        self.stats["errors"] += 1
                        time.sleep(0.2)
    
                    except Exception as e:
                        err_l = str(e).lower()
    
                        # AUTH FAIL -> skip remaining CSCs for this IMEI (log once)
                        if ("auth_failed" in err_l) or ("unauthorized" in err_l) or ("401" in err_l):
                            self.stats["errors"] += 1
                            auth_failed_for_imei = True
                            if not auth_logged_for_imei:
                                auth_logged_for_imei = True
                                self.log(f"[{C_ERR}]AUTH FAILED[/] {imei} | {csc}  → skipping remaining CSCs")
                            break
    
                        if ("invalid url" in err_l) or (" none" in err_l):
                            self.stats["errors"] += 1
    
                        elif any(x in err_l for x in ["connection", "reset", "10054", "aborted"]):
                            # Network Error: Pause and Wait, but DO NOT restart IMEI
                            Config.BAN_DETECTED = True
                            self.ban_reason = "Connection Reset"
                            Config.PAUSE_EVENT.clear()
                            Config.PAUSE_EVENT.wait()
                            self.stats["errors"] += 1
    
                        else:
                            self.stats["errors"] += 1
                            time.sleep(0.2)
    
                # end attempts loop
    
            # end CSC loop
    
            if not did_requeue:
                self.stats["scanned"] += 1
    
            self.queue.task_done()
    def run(self):
        # start input listener (keyboard controls)
        input_thread = threading.Thread(target=self.input_listener, daemon=True)
        input_thread.start()
    
        # start workers
        pool = []
        for _ in range(self.threads):
            t = threading.Thread(target=self.worker)
            t.daemon = True
            t.start()
            pool.append(t)
    
        try:
            with Live(self.generate_live_layout(), refresh_per_second=4, screen=True, transient=True) as live:
                while any(t.is_alive() for t in pool) and not Config.STOP_FLAG:
                    if Config.BAN_DETECTED:
                        live.stop()
                        Dashboard.show_ban_alert(self.ban_reason)
                        input()
                        Config.BAN_DETECTED = False
                        self.ban_reason = ""
                        Config.PAUSE_EVENT.set()
                        live.start()
    
                    live.update(self.generate_live_layout())
                    time.sleep(0.25)
    
        finally:
            # IMPORTANT: stop the input listener so it doesn't break the Hub menu
            Config.STOP_FLAG = True
            Config.PAUSE_EVENT.set()
    
            # wait a moment for threads to exit cleanly
            for t in pool:
                try:
                    t.join(timeout=0.5)
                except Exception:
                    pass
            try:
                input_thread.join(timeout=0.5)
            except Exception:
                pass
    
            # restore terminal state
            console.show_cursor(True)
            console.clear()
    
        self.print_final_report()
        console.print(f"[bold {C_SEC}]Press Enter to return to Hub...[/]")
        input()
    def get_clean_header(self):
        """Compact, theme-driven header for the live scanner UI."""
        banner_txt = (GLOBAL_BANNER.strip("\n") if GLOBAL_BANNER else "")
        if not banner_txt:
            banner_txt = """\
   ᛉ ᛟ ᚦ ᛋ
   V A L H
   A L L A"""

        # [FIX] Logo Alignment & Color
        # - justify="center" keeps the ASCII centered in its column
        # - vertical="middle" ensures it floats in the middle of the panel
        logo = Align.center(Text(banner_txt, style=f"bold {C_PRIM}", justify="center"), vertical="middle")

        # Info Grid
        ver = self.version.split("/")[0] if "/" in self.version else self.version
        cscs = ", ".join(self.cscs[:3]) + (f" +{len(self.cscs)-3}" if len(self.cscs) > 3 else "")
        elapsed = max(0, int(time.time() - self.start_time))
        elapsed_str = time.strftime("%H:%M:%S", time.gmtime(elapsed))
        total = self.total if self.total > 0 else 1
        pct = int((self.stats.get("scanned", 0) / total) * 100)

        # [FIX] Spacing between Label and Value
        info = Table.grid(expand=True, padding=(0, 2))
        info.add_column(justify="right", style=C_DIM, no_wrap=True)
        info.add_column(justify="left", style=f"bold {C_TEXT}")
        
        info.add_row("DEVICE", self.model)
        info.add_row("CSCS", cscs)
        info.add_row("CURRENT", self.current_imei) 
        info.add_row("BASE", ver)
        info.add_row("THREADS", str(self.threads))
        info.add_row("FINDER", str(self.finder))
        info.add_row("TIME", elapsed_str + f" | {pct}%")

        # [FIX] Main Layout
        # - padding=(0, 3) adds space between Logo Column and Info Column
        header = Table.grid(expand=True, padding=(0, 3))
        
        # - width=32 accommodates wider banners (like Valkyrie/Crest) without squeezing
        header.add_column(width=32, justify="center", vertical="middle") 
        header.add_column(justify="left", vertical="middle")
        
        # Align.left on info ensures it doesn't drift if the terminal is huge
        header.add_row(logo, Align.left(info, vertical="middle"))

        return Panel(header, style=C_DIM, border_style=C_DIM, box=box.ROUNDED, padding=(0, 1))

    def get_stats_grid(self):
        g = Table.grid(expand=True, padding=(0,1))
        for _ in range(4): g.add_column(ratio=1)
        
        # [FIX] Added explicit newline \n to separate Value from Label
        def p(val, lbl, col):
            return Panel(Align.center(f"[bold {col}]{val}[/]\n[dim]{lbl}[/]"), border_style=col, box=box.ROUNDED)

        g.add_row(
            p(self.stats['hits'], "HITS", C_OK),
            p(self.stats['valid'], "VALID", C_ACC),
            p(self.stats['bad_csc'], "BAD CSC", C_DIM),
            p(self.stats['errors'], "ERRORS", C_ERR)
        )
        return g

    def generate_live_layout(self):
        self.layout["top"].update(self.get_clean_header())
        self.layout["stats"].update(self.get_stats_grid())

        status_text = "PAUSED" if not Config.PAUSE_EVENT.is_set() else "RUNNING"
        status_color = C_ERR if not Config.PAUSE_EVENT.is_set() else C_OK
        
        ctrl_text = f"[bold {status_color}]▶ {status_text}[/]    [dim][SPACE] Pause   [S] Stop   [B] Back   [M] Menu[/]"
        self.layout["menu"].update(Panel(ctrl_text, border_style=C_DIM, style="on #000000"))

        completed = self.stats["scanned"]
        total = self.total if self.total > 0 else 1
        
        # [VALHALLA THEME] Progress Bar
        prog_bar = Progress(
            SpinnerColumn(style=f"bold {C_ACC}"),
            TextColumn(f"[{C_PRIM}]Scanning..."),
            BarColumn(bar_width=None, complete_style=f"bold {C_PRIM}", finished_style=f"bold {C_OK}"),
            TextColumn(f"[{C_ACC}]{{task.percentage:>3.0f}}%[/]"),
            TextColumn(f"[{C_DIM}]({{task.completed}}/{total})[/]"),
            console=console,
            expand=True,
        )
        task = prog_bar.add_task("", total=total, completed=min(completed, total))
        self.layout["progress"].update(Panel(prog_bar, border_style=C_DIM))

        # --- LOGS WITH STATIC RANGE HEADER ---
        def _fit_line(s, max_chars=78):
            s = str(s).replace('\n', ' ').replace('\r', ' ')
            #    s = ' '.join(s.split())
            if len(s) <= max_chars:
                return s
            return s[:max_chars-1] + '…'

        # 1. Generate Rolling Logs
        log_text = "\n".join(_fit_line(x) for x in list(self.logs))
        
        # 2. Generate Static Range Info
        range_info = (
            f"[bold {C_PRIM}]TARGET RANGE:[/]\n"
            f"[bold white]{self.imei_start}[/] [dim]→[/] [bold white]{self.imei_end}[/]\n"
            f"[dim]──────────────────────────────────────[/]"
        )

        # 3. Combine
        full_feed_content = f"{range_info}\n{log_text}"
        self.layout["logs"].update(Panel(full_feed_content, title="[bold white]Live Intelligence Feed[/]", border_style=C_DIM))

        # --- SPLIT LEADERBOARD (VALID / FOUND) ---
        lb_table = Table(
            box=box.SIMPLE_HEAD,
            expand=True,
            border_style=C_DIM,
            padding=(0, 1),
            show_edge=False
        )
        lb_table.add_column("Rank", style=C_DIM, width=4, no_wrap=True)
        lb_table.add_column("Region", style="bold white", width=6, no_wrap=True)
        # Split Header
        lb_table.add_column("V / F", justify="right", width=10, no_wrap=True)
        
        # Sort by TOTAL activity (ensure worker is populating 'total')
        # If 'total' key missing in existing state, default to 0 to prevent crash
        sorted_lb = sorted(self.csc_leaderboard.items(), key=lambda x: x[1].get('total', 0) if isinstance(x[1], dict) else 0, reverse=True)
        runes = ["ᛋ", "ᛟ", "ᚦ", "ᚨ", "ᚱ", "ᚲ", "ᚷ", "ᚹ", "ᚺ", "ᚾ", "ᛁ", "ᛃ"]
        
        for i, (csc, stats) in enumerate(sorted_lb[:12]):
            rank = runes[i] if i < len(runes) else str(i+1)
            
            # Handle both old (int) and new (dict) state structures gracefully
            if isinstance(stats, dict):
                v_count = stats.get('valid', 0)
                f_count = stats.get('found', 0)
            else:
                v_count = stats # Fallback if worker hasn't updated yet
                f_count = 0

            # Format: [Blue]Valid[/] / [Green]Found[/]
            display_str = f"[{C_ACC}]{v_count}[/] / [{C_OK}]{f_count}[/]"
            
            lb_table.add_row(rank, csc, display_str)
            
        self.layout["leaderboard"].update(Panel(lb_table, title="[bold white]TOP REGIONS[/]", border_style=C_DIM))
        return self.layout


    def print_final_report(self):
        console.print(self.get_clean_header()); console.print(self.get_stats_grid())
        elapsed = time.time() - self.start_time; duration_str = time.strftime("%H:%M:%S", time.gmtime(elapsed))
        metrics_table = Table(box=box.SIMPLE, expand=True, show_header=True, border_style=C_PRIM)
        metrics_table.add_column("START IMEI", style="bold white", justify="center"); metrics_table.add_column("END IMEI", style="bold white", justify="center")
        metrics_table.add_column("DURATION", style=C_PRIM, justify="center"); metrics_table.add_column("TOTAL", style=C_OK, justify="center")
        metrics_table.add_row(str(self.imei_start), str(self.imei_end), duration_str, str(self.total))
        console.print(Panel(metrics_table, title=f"[bold {C_PRIM}]ᛋ MISSION REPORT: SECTOR SCANNED[/]", border_style=C_PRIM))
        if self.session_hits:
            vic_table = Table(box=box.SIMPLE_HEAD, expand=True, border_style=C_DIM)
            vic_table.add_column("TARGET IMEI", style="bold white", justify="center"); vic_table.add_column("REGION", style=C_PRIM, justify="center"); vic_table.add_column("BUILD FOUND", style=C_OK); vic_table.add_column("TYPE", style=C_DIM, justify="right")
            for hit in self.session_hits: vic_table.add_row(hit['imei'], hit['csc'], hit['pda'], hit['type'])
            console.print(Panel(vic_table, title="[bold white]VICTORY TABLE[/]", border_style=C_OK))
        else:
            console.print(Panel(Align.center(f"[dim italic]ᚦ No firmware payloads found in this sector.[/]"), border_style=C_DIM))

class IntelligenceController:
    def is_wifi_tablet(self, model_raw):
        m = model_raw.replace("SM-", "").strip().upper()
        # Filter Tab S (X), Tab A (T), Tab P (P) where suffix is '0' (WiFi)
        if (m.startswith("X") or m.startswith("T") or m.startswith("P")) and m.endswith("0"):
            return True
        return False

    def __init__(self):
        Database.init()
        
    def main_menu(self):
        while True:
            Dashboard.header()
            action = inquirer.select(
                message="Select Module:",
                choices=[
                    Choice("scan",    "Begin Reconnaissance"),
                    Choice("history", "Database Records"),
                    Choice("back",    "Back to Hub")
                ],
                pointer="›"
            ).execute()

            if action == "back": sys.exit(0)
            elif action == "scan": self.setup_scan()
            elif action == "history": self.show_history()
            
    def setup_scan(self):
        # [THEME FIX] Use Global Choice if available
        ChoiceClass = globals().get('Choice', Choice)

        step = 1; model = ""; selected_cscs = []; version = ""; imeis = []

        while True:
            Dashboard.header()
            
            # --- STEP 1: MODEL ---
            if step == 1:
                raw_model = inquirer.text(message="Target Model (e.g. F966U1) [Type 'b' to Exit]:").execute().strip().upper()
                if raw_model in ["B", "BACK", "EXIT"]: return
                model = raw_model if raw_model.startswith("SM-") else f"SM-{raw_model}"
                
                if hasattr(self, 'is_wifi_tablet') and self.is_wifi_tablet(model):
                    console.print(f"[{C_ERR}]⚠ WiFi-Only Tablets (e.g. {model}) DO NOT have IMEIs.[/]")
                    console.print(f"[{C_DIM}]Use [bold gold1]Mimir (Decrypter)[/] + [bold gold1]Odin (FUS)[/] instead.[/]")
                    time.sleep(3); continue
                step = 2

            # --- STEP 2: REGION ---
            elif step == 2:
                keys = list(Config.CSC_MAP.keys())
                defaults = []
                if "U1" in model: defaults = ["USA (U1 - Unlocked)"]
                elif "U" in model: defaults = ["USA (U - Carrier)"]
                elif "B" in model: defaults = ["OXM (Europe/Global)"]
                elif "N" in model: defaults = ["KOREA (N Model)"]
                elif "0" in model: defaults = ["CHINA (0 Model)"]
                elif "W" in model: defaults = ["CANADA (W Model)"]
                
                for d in defaults: 
                    if d in keys: keys.insert(0, keys.pop(keys.index(d)))

                main_choices = [ChoiceClass(Config.CSC_MAP[k], k) for k in keys]
                main_choices.append(ChoiceClass("MAN", "Manual Selection (Smart)"))
                main_choices.append(ChoiceClass("back", "Back"))

                sel = inquirer.select("Target Region:", choices=main_choices).execute()
                
                if sel == "back": step = 1; continue
                if sel == "MAN":
                    db_hits = Database.get_smart_csc_priority(model)
                    hw_defaults = []
                    suffix = model.split('-')[-1].upper()
                    if suffix.endswith("B"): hw_defaults = Config._OXM + Config._OXE
                    elif suffix.endswith("E"): hw_defaults = Config._OJM + Config._OLM + Config._IND
                    elif suffix.endswith("U") or suffix.endswith("U1"): hw_defaults = Config.CSC_MAP["USA (U - Carrier)"] + Config.CSC_MAP["USA (U1 - Unlocked)"]
                    elif suffix.endswith("W"): hw_defaults = Config.CSC_MAP["CANADA (W Model)"]
                    elif suffix.endswith("N"): hw_defaults = Config.CSC_MAP["KOREA (N Model)"]
                    elif suffix.endswith("0"): hw_defaults = Config.CSC_MAP["CHINA (0 Model)"]

                    man_choices = []
                    if db_hits:
                        man_choices.append(Separator("--- History Hits (Database) ---"))
                        for c in db_hits: man_choices.append(ChoiceClass(c, f"{c} (Known)"))
                    if hw_defaults:
                        man_choices.append(Separator("--- Suggested for Device ---"))
                        unique_defaults = sorted(list(set([d for d in hw_defaults if d not in db_hits])))
                        for c in unique_defaults: man_choices.append(ChoiceClass(c, c))
                            
                    man_choices.append(Separator("--- Custom ---"))
                    man_choices.append(ChoiceClass("TYPE", "Type Manually..."))
                    man_choices.append(ChoiceClass("back", "Go Back"))
                    
                    sel_man = inquirer.checkbox(message=f"Select CSCs for {model}:", choices=man_choices, instruction="(Space to select, Enter to confirm)").execute()
                    
                    if "back" in sel_man or not sel_man: continue
                    final_cscs = []
                    if "TYPE" in sel_man:
                        raw = inquirer.text("Type CSCs (comma split):").execute()
                        final_cscs.extend([x.strip().upper() for x in raw.split(',') if x.strip()])
                    for item in sel_man:
                        if item not in ["TYPE", "back"]: final_cscs.append(item)
                    if not final_cscs: continue
                    selected_cscs = list(set(final_cscs))
                else: selected_cscs = sel
                step = 3

            # --- STEP 3: BASE FIRMWARE ---
            elif step == 3:
                Dashboard.header()
                v_mode = inquirer.select("Base Firmware:", choices=[
                    ChoiceClass("AUTO",    "Auto-Detect (Cascade)"),
                    ChoiceClass("DECRYPT", "Mimir (Decrypt & History)"),
                    ChoiceClass("SMART",   "Smart Auto-Generate"),
                    ChoiceClass("HIST",    "Load from History"),
                    ChoiceClass("MAN",     "Manual Triplet"),
                    ChoiceClass("back",    "Go Back")
                ]).execute()
                
                if v_mode == "back": step = 2; continue
                
                # Decrypter Integration
                elif v_mode == "DECRYPT":
                    try:
                        import decrypter10
                        if hasattr(decrypter10.TelegramService, "load_config"): decrypter10.TelegramService.load_config()
                        if hasattr(decrypter10.TelegramService, "load_device_map"): decrypter10.TelegramService.load_device_map()
                        
                        t_csc = selected_cscs[0] if selected_cscs else "EUX"
                        result = decrypter10.run_decrypter(model, t_csc, selection_mode=True)
                        
                        if result:
                            batch = result if isinstance(result, list) else [result]
                            top = batch[0]
                            found_ver = None
                            if isinstance(top, dict): found_ver = top.get("version")
                            elif isinstance(top, str): found_ver = top
                            
                            if found_ver:
                                console.print(f"[bold {C_OK}]>> SELECTED: {found_ver}[/]")
                                version = found_ver
                                time.sleep(1); step = 4; continue
                        input("\nSelection Cancelled. Press Enter..."); continue
                    except Exception as e: console.print(f"[{C_ERR}]Error: {e}[/]"); input("Enter..."); continue

                # [FIX] History: Pin Latest Stable
                elif v_mode == "HIST":
                    known = Utils.get_known_versions(model)
                    # LIVE stable from Samsung FUS (version.xml via Utils.fetch_latest)
                    live_stable = None
                    try:
                        t_csc = selected_cscs[0] if selected_cscs else "EUX"
                        live_stable = Utils.fetch_latest(model, t_csc)
                    except Exception:
                        live_stable = None

                    if known:
                        # newest -> oldest using date scoring when available
                        try:
                            sorted_known = sorted(known, key=lambda x: Utils.get_date_score(x), reverse=True)
                        except Exception:
                            sorted_known = sorted(known, reverse=True)

                        final_list = []
                        if live_stable:
                            final_list.append(live_stable)
                        for v in sorted_known:
                            if v != live_stable:
                                final_list.append(v)

                        final_list = final_list[:15]

                        choices_ui = []
                        for v in final_list:
                            label = f"{v} (LIVE)" if (live_stable and v == live_stable) else v
                            choices_ui.append(ChoiceClass(v, label))
                        choices_ui.append(ChoiceClass("back", "Back"))

                        sel_vers = inquirer.checkbox(message="Select Version(s):", choices=choices_ui).execute()
                        if "back" in sel_vers or not sel_vers: continue
                        version = sel_vers[0]
                        step = 4
                    else:
                        # no history: still allow live stable if available
                        if live_stable:
                            version = live_stable
                            step = 4
                        else:
                            console.print(f"[{C_ERR}]No history.[/]"); time.sleep(1); continue


                elif v_mode == "AUTO":
                    with console.status(f"[bold {C_PRIM}]Fetching latest..."): 
                        version = Utils.fetch_latest(model, selected_cscs[0])
                    if not version: version = inquirer.text("Enter Manual Triplet:").execute().strip()
                    step = 4
                elif v_mode == "MAN":
                    version = inquirer.text("Enter Triplet:").execute().strip()
                    step = 4
                elif v_mode == "SMART":
                    y_curr, m_curr = Utils.get_smart_date_codes(0)
                    y_next, m_next = Utils.get_smart_date_codes(1)
                    bare = model.replace("SM-", "")
                    def build(p, c): return f"{bare}{p}/{bare}{c}/{bare}{p}"
                    templates = []
                    if any(x in model for x in ["U", "U1", "W"]):
                        is_u1 = "U1" in model
                        o_u = [ChoiceClass(build(f"UEU0{y_curr}{m_curr}1", f"OYM0{y_curr}{m_curr}1"), f"Unlocked - {y_curr}{m_curr}"), ChoiceClass(build(f"UEU0{y_next}{m_next}1", f"OYM0{y_next}{m_next}1"), f"Unlocked - {y_next}{m_next}")]
                        o_c = [ChoiceClass(build(f"SQU0{y_curr}{m_curr}1", f"OYN0{y_curr}{m_curr}1"), f"Carrier - {y_curr}{m_curr}"), ChoiceClass(build(f"SQU0{y_next}{m_next}1", f"OYN0{y_next}{m_next}1"), f"Carrier - {y_next}{m_next}")]
                        templates = (o_u + o_c) if is_u1 else (o_c + o_u)
                    elif "B" in model or "E" in model:
                        templates.append(ChoiceClass(build(f"XXU0{y_curr}{m_curr}1", f"OXM0{y_curr}{m_curr}1"), f"Global - {y_curr}{m_curr}"))
                    else: templates.append(ChoiceClass(build(f"XXU0{y_curr}{m_curr}1", f"OXM0{y_curr}{m_curr}1"), f"Generic - {y_curr}{m_curr}"))
                    version = inquirer.select("Template:", choices=templates).execute()
                    step = 4
                    
                        # --- STEP 4: SCAN MODE ---
            elif step == 4:
                recent_tacs = Database.get_recent_tacs(model)
                imei_choices = []
                if recent_tacs: 
                    imei_choices.append(ChoiceClass("REC_TAC", f"Recent TACs ({len(recent_tacs)} found)"))
                
                imei_choices.extend([
                    ChoiceClass("MANUAL",  "Manual Start (Input TAC/IMEI)"),
                    ChoiceClass("RESUME",  "Resume Last Valid Hit"),
                    ChoiceClass("CSV",     "Load from CSV"),
                    ChoiceClass("REVERIFY","Re-Verify Database Hits"),
                    ChoiceClass("back",    "Go Back")
                ])
                
                source_mode = inquirer.select(message="Scan Source:", choices=imei_choices).execute()
                
                if source_mode == "back": step = 3; continue
                
                # A. DETERMINE START IMEI
                start_imei = None
                
                if source_mode == "REC_TAC":
                    target_tac = inquirer.select("Select TAC:", choices=recent_tacs + [ChoiceClass("back", "Back")]).execute()
                    if target_tac == "back": continue
                    # Default to TAC + 0000...
                    def_start = target_tac + "0000000" if len(target_tac) == 8 else target_tac
                    start_imei = inquirer.text(message="Start IMEI:", default=def_start).execute().strip()

                elif source_mode == "MANUAL":
                    raw = inquirer.text("Enter Start TAC/IMEI:").execute().strip()
                    start_imei = raw + "0000000" if len(raw) == 8 else raw

                elif source_mode == "RESUME":
                    start_imei = Database.get_last_valid_imei(model)
                    if not start_imei:
                        console.print(f"[{C_ERR}]No history found for {model}.[/]")
                        time.sleep(1); continue

                elif source_mode == "CSV":
                    # CSV is unique; it handles its own loop
                    tacs = Utils.load_tacs_from_csv(model)
                    if not tacs: 
                        console.print(f"[{C_ERR}]No TACs found in CSV.[/]")
                        time.sleep(1); continue
                    
                    # For CSV, we stick to sequential per TAC for simplicity, 
                    # or you could implement complex logic. Here we keep it simple.
                    count = int(inquirer.text(message="Count per TAC:", default="100").execute())
                    imeis = []
                    for tac in tacs: imeis.extend(Utils.gen_sequential(tac + "000000", count))
                
                elif source_mode == "REVERIFY":
                    # DB Rescan doesn't generate new IMEIs
                    conn = sqlite3.connect(os.path.join(Config.DIR_DB, Config.DB_FILE))
                    c = conn.cursor()
                    c.execute("SELECT imei, csc FROM firmware_hits WHERE device_model = ?", (model,))
                    imeis = [(r[0], r[1]) for r in c.fetchall()]
                    conn.close()
                    start_imei = None # Skip generation

                # B. APPLY DISTRIBUTION (Sequential vs Batch)
                if start_imei:
                    dist_type = inquirer.select("Distribution Logic:", choices=[
                        ChoiceClass("SEQ", "Sequential (Standard)"),
                        ChoiceClass("BATCH", "Batch Jump (Segmented)")
                    ]).execute()

                    if dist_type == "SEQ":
                        count = int(inquirer.text("Total Count:", default="500").execute())
                        imeis = Utils.gen_sequential(start_imei, count)
                    else:
                        total = int(inquirer.text("Total IMEIs to Scan:", default="1000").execute())
                        batch = int(inquirer.text("Batch Size (Sequential segment):", default="250").execute())
                        jump  = int(inquirer.text("Jump Step (Skip per batch):", default="10000").execute())
                        imeis = Utils.gen_batch_jump(start_imei, total, batch, jump)

                if not imeis: 
                    console.print(f"[{C_ERR}]No IMEIs generated.[/]"); time.sleep(1); continue
                
                # ... (Rest of Step 4: CSC Priority, Thread count, Finder name, Scanner init) ...
                # [Copy your existing logic for Threads/Finder here]
                top_cscs = Database.get_smart_csc_priority(model)
                if top_cscs:
                    priority_set = [c for c in top_cscs if c in selected_cscs]
                    remainder_set = [c for c in selected_cscs if c not in priority_set]
                    if priority_set: selected_cscs = priority_set + remainder_set

                threads = int(inquirer.text(message="Threads:", default="16").execute())
                finder = inquirer.text(message="Finder:", default="assholes").execute().strip()
                
                Dashboard.header()
                scanner = Scanner(model, selected_cscs, version, imeis, threads, finder)
                scanner.run()
                return 
                
    def show_history(self):
        # [FIX] Reduced page size to 10 to fit on mobile screens with keyboard open
        page_size = 10
        current_page = 0
        
        try:
            conn = sqlite3.connect(os.path.join(Config.DIR_DB, Config.DB_FILE))
            c = conn.cursor()
            c.execute("SELECT device_model, csc, request_base_version, found_pda, timestamp FROM firmware_hits ORDER BY timestamp DESC")
            rows = c.fetchall()
            conn.close()
        except Exception as e:
            console.print(f"[{C_ERR}]Database Error: {e}[/]")
            time.sleep(2); return

        if not rows:
            Dashboard.header()
            console.print(Panel(Align.center(f"[dim italic]ᚦ No intelligence records found in database.[/]"), border_style=C_DIM, padding=(1, 2)))
            input("\nPress Enter..."); return

        total_pages = (len(rows) + page_size - 1) // page_size

        while True:
            Dashboard.header()
            
            start_idx = current_page * page_size
            end_idx = start_idx + page_size
            page_rows = rows[start_idx:end_idx]
            
            table = Table(box=box.SIMPLE_HEAD, expand=True, border_style=C_DIM, padding=(0, 2))
            table.add_column("DEVICE", style="bold white", width=12)
            table.add_column("REGION", style=C_ACC, justify="center", width=8)
            table.add_column("TRANSITION", style=C_TEXT)
            
            for r in page_rows: 
                model = r[0].replace("SM-", "")
                csc = r[1]
                
                src_raw = r[2] or "Unknown"
                src = src_raw.split('/')[0] if "/" in src_raw else src_raw
                if len(src) > 13: src = src[-13:]
                
                tgt_raw = r[3] or "Unknown"
                tgt = tgt_raw.split('/')[0] if "/" in tgt_raw else tgt_raw
                
                tgt_style = C_OK
                if ".DM" in tgt.upper(): tgt_style = C_ERR
                
                transition = f"[dim]{src}[/]  [{C_PRIM}]ᛃ[/]  [{tgt_style}]{tgt}[/]"
                table.add_row(model, csc, transition)

            # [FIX] Compact footer to save vertical space
            console.print(Panel(table, title=f"[bold {C_PRIM}]PAGE {current_page+1}/{total_pages} ({len(rows)} RECS)[/]", border_style=C_PRIM))
            
            nav_choices = []
            if current_page < total_pages - 1:
                nav_choices.append(Choice("next", "Next Page"))
            if current_page > 0:
                nav_choices.append(Choice("prev", "Previous Page"))
            nav_choices.append(Choice("back", "Back to Menu"))
            
            op = inquirer.select(
                message="Navigation:", 
                choices=nav_choices,
                pointer="›"
            ).execute()
            
            if op == "next": current_page += 1
            elif op == "prev": current_page -= 1
            elif op == "back": break


if __name__ == "__main__":
    try:
        sys.stdout.write("\033[?1049h"); sys.stdout.flush()
        IntelligenceController().main_menu()
    except KeyboardInterrupt: sys.exit(0)
    except Exception as e:
        sys.stdout.write("\033[?1049l"); sys.stdout.flush()
        console.print_exception()
    finally:
        sys.stdout.write("\033[?1049l"); sys.stdout.flush()
