from __future__ import annotations
import sys


class DesCrypt:    
    # Constants
    MAX_CRYPT_BITS_SIZE = 64

    # DES tables
    FP = [
        40, 8, 48, 16, 56, 24, 64, 32, 39, 7, 47, 15, 55, 23, 63, 31, 38, 6, 46, 14, 54, 22, 62, 30, 37, 5, 45, 13,
        53, 21, 61, 29, 36, 4, 44, 12, 52, 20, 60, 28, 35, 3, 43, 11, 51, 19, 59, 27, 34, 2, 42, 10, 50, 18, 58, 26,
        33, 1, 41, 9, 49, 17, 57, 25
    ]

    IP = [
        58, 50, 42, 34, 26, 18, 10, 2, 60, 52, 44, 36, 28, 20, 12, 4, 62, 54, 46, 38, 30, 22, 14, 6, 64, 56, 48, 40,
        32, 24, 16, 8, 57, 49, 41, 33, 25, 17, 9, 1, 59, 51, 43, 35, 27, 19, 11, 3, 61, 53, 45, 37, 29, 21, 13, 5,
        63, 55, 47, 39, 31, 23, 15, 7
    ]
    
    P = [
        16, 7, 20, 21, 29, 12, 28, 17, 1, 15, 23, 26, 5, 18, 31, 10, 2, 8, 24, 14, 32, 27, 3, 9, 19, 13, 30, 6, 22,
        11, 4, 25
    ]

    PC1_C = [
        57, 49, 41, 33, 25, 17, 9, 1, 58, 50, 42, 34, 26, 18, 10, 2, 59, 51, 43, 35, 27, 19, 11, 3, 60, 52, 44, 36
    ]

    PC1_D = [
        63, 55, 47, 39, 31, 23, 15, 7, 62, 54, 46, 38, 30, 22, 14, 6, 61, 53, 45, 37, 29, 21, 13, 5, 28, 20, 12, 4
    ]

    PC2_C = [14, 17, 11, 24, 1, 5, 3, 28, 15, 6, 21, 10, 23, 19, 12, 4, 26, 8, 16, 7, 27, 20, 13, 2]

    PC2_D = [41, 52, 31, 37, 47, 55, 30, 40, 51, 45, 33, 48, 44, 49, 39, 56, 34, 53, 46, 42, 50, 36, 29, 32]
    
    S = [
        [
            14, 4, 13, 1, 2, 15, 11, 8, 3, 10, 6, 12, 5, 9, 0, 7, 0, 15, 7, 4, 14, 2, 13, 1, 10, 6, 12, 11, 9, 5, 3,
            8, 4, 1, 14, 8, 13, 6, 2, 11, 15, 12, 9, 7, 3, 10, 5, 0, 15, 12, 8, 2, 4, 9, 1, 7, 5, 11, 3, 14, 10, 0,
            6, 13
        ],
        [
            15, 1, 8, 14, 6, 11, 3, 4, 9, 7, 2, 13, 12, 0, 5, 10, 3, 13, 4, 7, 15, 2, 8, 14, 12, 0, 1, 10, 6, 9, 11,
            5, 0, 14, 7, 11, 10, 4, 13, 1, 5, 8, 12, 6, 9, 3, 2, 15, 13, 8, 10, 1, 3, 15, 4, 2, 11, 6, 7, 12, 0, 5,
            14, 9
        ],
        [
            10, 0, 9, 14, 6, 3, 15, 5, 1, 13, 12, 7, 11, 4, 2, 8, 13, 7, 0, 9, 3, 4, 6, 10, 2, 8, 5, 14, 12, 11, 15,
            1, 13, 6, 4, 9, 8, 15, 3, 0, 11, 1, 2, 12, 5, 10, 14, 7, 1, 10, 13, 0, 6, 9, 8, 7, 4, 15, 14, 3, 11, 5,
            2, 12
        ],
        [
            7, 13, 14, 3, 0, 6, 9, 10, 1, 2, 8, 5, 11, 12, 4, 15, 13, 8, 11, 5, 6, 15, 0, 3, 4, 7, 2, 12, 1, 10, 14,
            9, 10, 6, 9, 0, 12, 11, 7, 13, 15, 1, 3, 14, 5, 2, 8, 4, 3, 15, 0, 6, 10, 1, 13, 8, 9, 4, 5, 11, 12, 7,
            2, 14
        ],
        [
            2, 12, 4, 1, 7, 10, 11, 6, 8, 5, 3, 15, 13, 0, 14, 9, 14, 11, 2, 12, 4, 7, 13, 1, 5, 0, 15, 10, 3, 9, 8,
            6, 4, 2, 1, 11, 10, 13, 7, 8, 15, 9, 12, 5, 6, 3, 0, 14, 11, 8, 12, 7, 1, 14, 2, 13, 6, 15, 0, 9, 10, 4,
            5, 3
        ],
        [
            12, 1, 10, 15, 9, 2, 6, 8, 0, 13, 3, 4, 14, 7, 5, 11, 10, 15, 4, 2, 7, 12, 9, 5, 6, 1, 13, 14, 0, 11, 3,
            8, 9, 14, 15, 5, 2, 8, 12, 3, 7, 0, 4, 10, 1, 13, 11, 6, 4, 3, 2, 12, 9, 5, 15, 10, 11, 14, 1, 7, 6, 0,
            8, 13
        ],
        [
            4, 11, 2, 14, 15, 0, 8, 13, 3, 12, 9, 7, 5, 10, 6, 1, 13, 0, 11, 7, 4, 9, 1, 10, 14, 3, 5, 12, 2, 15, 8,
            6, 1, 4, 11, 13, 12, 3, 7, 14, 10, 15, 6, 8, 0, 5, 9, 2, 6, 11, 13, 8, 1, 4, 10, 7, 9, 5, 0, 15, 14, 2,
            3, 12
        ],
        [
            13, 2, 8, 4, 6, 15, 11, 1, 10, 9, 3, 14, 5, 0, 12, 7, 1, 15, 13, 8, 10, 3, 7, 4, 12, 5, 6, 11, 0, 14, 9,
            2, 7, 11, 4, 1, 9, 12, 14, 2, 0, 6, 10, 13, 15, 3, 5, 8, 2, 1, 14, 7, 4, 10, 8, 13, 15, 12, 9, 0, 3, 5,
            6, 11
        ]
    ]

    E2 = [
        32, 1, 2, 3, 4, 5, 4, 5, 6, 7, 8, 9, 8, 9, 10, 11, 12, 13, 12, 13, 14, 15, 16, 17, 16, 17, 18, 19, 20, 21,
        20, 21, 22, 23, 24, 25, 24, 25, 26, 27, 28, 29, 28, 29, 30, 31, 32, 1
    ]

    SHIFTS = [1, 1, 2, 2, 2, 2, 2, 2, 1, 2, 2, 2, 2, 2, 2, 1]
    
    def __init__(self):
        self._c = [0] * 28
        self._d = [0] * 28
        self._ks = [[0] * 48 for _ in range(16)]
        self._e = [0] * 48
        self._pre_s = [0] * 48
        self._crypt_crypt_byte = [0] * 16

    def _init_password(self, b_arr, b_arr2):
        if b_arr is None or b_arr2 is None:
            return None
        
        i = 0
        i2 = 0
        while i < len(b_arr) and b_arr[i] != 0 and i2 < self.MAX_CRYPT_BITS_SIZE:
            for i3 in range(6, -1, -1):
                b_arr2[i2] = (b_arr[i] >> i3) & 1
                i2 += 1
            i += 1
            b_arr2[i2] = 0
            i2 += 1
            
        while i2 < self.MAX_CRYPT_BITS_SIZE + 2:
            b_arr2[i2] = 0
            i2 += 1
            
        return b_arr2

    def _zero_password(self, b_arr):
        for i in range(self.MAX_CRYPT_BITS_SIZE + 2):
            b_arr[i] = 0
        return b_arr

    def _set_key(self, b_arr):
        for i in range(28):
            self._c[i] = b_arr[self.PC1_C[i] - 1]
            self._d[i] = b_arr[self.PC1_D[i] - 1]
            
        for i2 in range(16):
            for _ in range(self.SHIFTS[i2]):
                b = self._c[0]
                for i4 in range(27):
                    self._c[i4] = self._c[i4 + 1]
                self._c[27] = b
                
                b2 = self._d[0]
                for i6 in range(27):
                    self._d[i6] = self._d[i6 + 1]
                self._d[27] = b2

            for i8 in range(24):
                self._ks[i2][i8] = self._c[self.PC2_C[i8] - 1]
                self._ks[i2][i8 + 24] = self._d[self.PC2_D[i8] - 28 - 1]
                
        for i9 in range(48):
            self._e[i9] = self.E2[i9]

    def _e_expandsion(self, b_arr):
        if b_arr is None:
            return

        i = 0
        i2 = 0
        while i < 2:
            i3 = i2 + 1
            b = b_arr[i2]
            self._crypt_crypt_byte[i] = b
            b2 = b - 59 if b > 90 else (b - 53 if b > 57 else b - 46)
            for i4 in range(6):
                if ((b2 >> i4) & 1) != 0:
                    i5 = (i * 6) + i4
                    b3 = self._e[i5]
                    i6 = i5 + 24
                    self._e[i5] = self._e[i6]
                    self._e[i6] = b3
            i += 1
            i2 = i3

    def _des_encrypt(self, b_arr):
        b_arr2 = [0] * 32
        b_arr3 = [0] * 32
        b_arr4 = [0] * 32
        b_arr5 = [0] * 32
        
        i = 0
        while i < 32:
            b_arr2[i] = b_arr[self.IP[i] - 1]
            i += 1
        
        while i < 64:
            b_arr3[i - 32] = b_arr[self.IP[i] - 1]
            i += 1
            
        for i2 in range(16):
            for i3 in range(32):
                b_arr4[i3] = b_arr3[i3]

            for i4 in range(48):
                self._pre_s[i4] = b_arr3[self._e[i4] - 1] ^ self._ks[i2][i4]

            for i5 in range(8):
                b = i5 * 6
                b2 = self.S[i5][
                    (self._pre_s[b] << 5) + (self._pre_s[b + 1] << 3) + (self._pre_s[b + 2] << 2) + 
                    (self._pre_s[b + 3] << 1) + self._pre_s[b + 4] + (self._pre_s[b + 5] << 4)
                ]
                b3 = i5 * 4
                b_arr5[b3] = (b2 >> 3) & 1
                b_arr5[b3 + 1] = (b2 >> 2) & 1
                b_arr5[b3 + 2] = (b2 >> 1) & 1
                b_arr5[b3 + 3] = b2 & 1

            for i6 in range(32):
                b_arr3[i6] = b_arr2[i6] ^ b_arr5[self.P[i6] - 1]

            for i7 in range(32):
                b_arr2[i7] = b_arr4[i7]

        for i8 in range(32):
            b4 = b_arr2[i8]
            b_arr2[i8] = b_arr3[i8]
            b_arr3[i8] = b4

        for i9 in range(64):
            if self.FP[i9] < 33:
                b_arr[i9] = b_arr2[self.FP[i9] - 1]
            else:
                b_arr[i9] = b_arr3[self.FP[i9] - 33]
                
        return b_arr

    def _encrypt(self, b_arr):
        for _ in range(25):
            b_arr = self._des_encrypt(b_arr)

        i2 = 0
        while i2 < 11:
            b = 0
            for i3 in range(6):
                b = (b << 1) | b_arr[(i2 * 6) + i3]
            
            b2 = b + 46
            if b2 > 57:
                b2 += 7
            if b2 > 90:
                b2 += 6
                
            self._crypt_crypt_byte[i2 + 2] = b2
            i2 += 1
            
        self._crypt_crypt_byte[i2 + 2] = 0
        if self._crypt_crypt_byte[1] == 0:
            self._crypt_crypt_byte[1] = self._crypt_crypt_byte[0]

    def generate(self, s, b_arr):
        """
        Generates a DES-based hash for the given string and salt.

        Args:
            s (str): The input string (password).
            b_arr (bytes): The salt.

        Returns:
            str: The generated hash as a string.
        """
        init_pwd = self._init_password(s.encode('utf-8'), [0] * (self.MAX_CRYPT_BITS_SIZE + 2))
        if init_pwd:
            self._set_key(init_pwd)
            zero_pwd = self._zero_password(init_pwd)
            self._e_expandsion(b_arr)
            self._encrypt(zero_pwd)
        
        result_bytes = bytes(self._crypt_crypt_byte)
        try:
            null_index = result_bytes.index(0)
            return result_bytes[:null_index].decode('utf-8')
        except (ValueError, UnicodeDecodeError):
            return result_bytes.decode('utf-8', errors='ignore')
