#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""valhalla_themes.py

Single source of truth for Valhalla *pastel* themes, banner art, and menu styles.

Goals:
- All modules (main / intelligence / logistics / decrypter) can depend on the same theme variables.
- No Rich/Inquirer default colors leaking (e.g., green finished progress bars).
- Backward-compatible aliases (C_GOLD/C_BLUE/etc.) for older modules.

This module intentionally has **no** imports from the other project files.
"""

from __future__ import annotations

import json
import os
from dataclasses import dataclass
from typing import Dict, Any, Optional, Tuple

try:
    from rich import box
    from rich.theme import Theme
except Exception:  # pragma: no cover
    box = None  # type: ignore
    Theme = None # type: ignore

try:
    from InquirerPy.utils import get_style
except Exception:  # pragma: no cover
    get_style = None  # type: ignore


# -----------------------------
# BANNERS (ASCII) — pastel-friendly
# -----------------------------

BANNERS: Dict[str, str] = {
    "TYR": r"""
╔══════════════╗
║   ᛉ ᛟ ᚦ ᛋ    ║
║   V A L H    ║
║   A L L A    ║
╚══════════════╝""",

    "ODIN": r"""
 ╒══════════════════════╕
 │  ᛟ GUNGNIR SYSTEM ᛟ  │
 ╘══════════════════════╛""",

    "THOR": r"""
       ▄▄▄▄████▄▄▄▄
       █ ᛗ ᛃ ᛟ ᛚ ᚾ ᛁ ᚱ █
       ▀▀▀▀████▀▀▀▀""",

    "LOKI": r"""
    X  VALHALLA  X
    \  PROTOCOL  /
     X    ᛚ     X""",

    "FREYA": r"""
    \   VALHALLA   /
   <═══( ᚡ ᚨ ᛚ )═══>
    /   SYSTEMS    \ """,

    # New: minimal sigil (good for narrow terminals)
    "SIGIL": r"""
   ᛉᛟᚦᛋ  VALHALLA""",

    # New: compass (pastel HUD)
    "HUGIN": r"""
   ╭────────────╮
   │ ᚺ HUGIN ᚺ   │
   ╰────────────╯""",

    # --- New "Valhalla styles" (wider + more detailed, still terminal-safe) ---
    "CREST": r"""
╔══════════════════════════╗
║  ᚡᚨᛚᚺᚨᛚᛚᚨ   C R E S T    ║
║  ┌───────┐   ┌───────┐   ║
║  │ ᛉ ᛟ ᚦ │   │ ᛋ ᛞ ᛗ │   ║
║  └───────┘   └───────┘   ║
╚══════════════════════════╝""",

    "RUNEFRAME": r"""
╒══════════════════════════╕
│ ᛜ ᛇ ᛉ   V A L H A L L A  │
│─────── R U N E S  ───────│
│    ᛞ ᛟ ᚦ ᛋ   ᛗ ᚱ ᛁ ᛗ     │
╘══════════════════════════╛""",

    "AURORA": r"""
    ⋆｡°✧  VALHALLA  ✧°｡⋆
   ╭──────────────────────╮
   │  A U R O R A  H U B  │
   ╰──────────────────────╯""",

    "FORGE": r"""
╔══════════════════════════╗
║   ███  V A L H A L L A   ║
║   █▄█    F O R G E       ║
║   ▀▀▀  ᛗᛃᛟᛚᚾᛁᚱ  G R I D  ║
╚══════════════════════════╝""",

    "VALKYRIE": r"""
╔═══╗  VALKYRIE  ╔═══╗
 ║ ᛈ ║  C R E S T ║ ᛈ ║
╚═══╝────────────╚═══╝
   ᚡᚨᛚᚺᚨᛚᛚᚨ  S Y S T E M S""",

    "SKALD": r"""
   ┌────────────────────┐
   │  S K A L D  L O G  │
   │ runes • stats • io │
   └────────────────────┘""",
}

BANNER_TITLES: Dict[str, str] = {
    "TYR": "VALHALLA HUB",
    "ODIN": "ALL-FATHER NET",
    "THOR": "MJOLNIR GRID",
    "LOKI": "CHAOS ENGINE",
    "FREYA": "VALKYRIE NET",
    "SIGIL": "VALHALLA",
    "HUGIN": "RAVEN WATCH",

    # new
    "CREST": "VALHALLA CREST",
    "RUNEFRAME": "RUNEFRAME CONSOLE",
    "AURORA": "AURORA HUB",
    "FORGE": "FORGE CONSOLE",
    "VALKYRIE": "VALKYRIE CREST",
    "SKALD": "SKALD LOG",
}


# -----------------------------
# Pastel Themes
# -----------------------------

def _b(x: Any, default: Any) -> Any:
    return x if x is not None else default


THEMES: Dict[str, Dict[str, Any]] = {
    # Original Valhalla (pastel gold)
    "VALHALLA": {
        "PRIM": "#E6D5AC",
        "SEC": "#CFD8DC",
        "ACC": "#90A4AE",
        "DIM": "#546E7A",
        "OK": "#A5D6A7",
        "ERR": "#EF9A9A",
        "TEXT": "#ECEFF1",
        "BORDER": "#8A8A8A",
        "BOX": getattr(box, "DOUBLE", None),
        "ICONS": {"PTR": "ᛉ", "ON": "ᛜ", "OFF": "᛫"},
    },
    "FROST": {
        "PRIM": "#90CAF9",
        "SEC": "#E1F5FE",
        "ACC": "#81D4FA",
        "DIM": "#455A64",
        "OK": "#80CBC4",
        "ERR": "#E57373",
        "TEXT": "#FAFAFA",
        "BORDER": "#8A8A8A",
        "BOX": getattr(box, "ROUNDED", None),
        "ICONS": {"PTR": "ᛋ", "ON": "ᛟ", "OFF": "∘"},
    },
    "BLOOD": {
        "PRIM": "#F48FB1",
        "SEC": "#FCE4EC",
        "ACC": "#F06292",
        "DIM": "#880E4F",
        "OK": "#AED581",
        "ERR": "#FF8A80",
        "TEXT": "#FFF3E0",
        "BORDER": "#8A8A8A",
        "BOX": getattr(box, "HEAVY", None),
        "ICONS": {"PTR": "ᚦ", "ON": "ᛣ", "OFF": "⋅"},
    },
    "VENOM": {
        "PRIM": "#A5D6A7",
        "SEC": "#E8F5E9",
        "ACC": "#81C784",
        "DIM": "#1B5E20",
        "OK": "#69F0AE",
        "ERR": "#EF5350",
        "TEXT": "#F1F8E9",
        "BORDER": "#8A8A8A",
        "BOX": getattr(box, "SQUARE", None),
        "ICONS": {"PTR": "ᚲ", "ON": "ᛝ", "OFF": "·"},
    },
    "VOID": {
        "PRIM": "#CE93D8",
        "SEC": "#F3E5F5",
        "ACC": "#BA68C8",
        "DIM": "#4A148C",
        "OK": "#80DEEA",
        "ERR": "#F48FB1",
        "TEXT": "#F8BBD0",
        "BORDER": "#8A8A8A",
        "BOX": getattr(box, "HORIZONTALS", None),
        "ICONS": {"PTR": "ᛞ", "ON": "ᛈ", "OFF": "⋅"},
    },
    # New pastel sets
    "LAVENDER": {
        "PRIM": "#D7C7FF",
        "SEC": "#F1EDFF",
        "ACC": "#9FB7FF",
        "DIM": "#6B6B7C",
        "OK": "#B8E6C9",
        "ERR": "#FFB3C7",
        "TEXT": "#F7F7FA",
        "BORDER": "#8A8A8A",
        "BOX": getattr(box, "ROUNDED", None),
        "ICONS": {"PTR": "ᛇ", "ON": "ᛜ", "OFF": "·"},
    },
    "MINT": {
        "PRIM": "#BFE9E0",
        "SEC": "#EFFFFB",
        "ACC": "#9AD6C6",
        "DIM": "#3D6B63",
        "OK": "#B8E6C9",
        "ERR": "#FFB3B3",
        "TEXT": "#F6FFFD",
        "BORDER": "#8A8A8A",
        "BOX": getattr(box, "ROUNDED", None),
        "ICONS": {"PTR": "ᛉ", "ON": "ᚷ", "OFF": "·"},
    },
    "SUNSET": {
        "PRIM": "#FFD2A6",
        "SEC": "#FFF1E6",
        "ACC": "#FFB6C1",
        "DIM": "#6E4A3A",
        "OK": "#C7EFCF",
        "ERR": "#FFB0A3",
        "TEXT": "#FFF8F2",
        "BORDER": "#8A8A8A",
        "BOX": getattr(box, "ROUNDED", None),
        "ICONS": {"PTR": "ᛋ", "ON": "ᛗ", "OFF": "·"},
    },

    # --- Six more distinct (still pastel) palettes ---
    # Ice + steel with aurora accents
    "AURORA": {
        "PRIM": "#B8E3FF",  # icy blue
        "SEC": "#F2FBFF",   # near-white cyan
        "ACC": "#B9F6CA",   # aurora mint
        "DIM": "#4D6070",
        "OK": "#C8E6C9",
        "ERR": "#FFB3BA",
        "TEXT": "#F7FBFF",
        "BORDER": "#8A8A8A",
        "BOX": getattr(box, "ROUNDED", None),
        "ICONS": {"PTR": "ᛝ", "ON": "ᛜ", "OFF": "·"},
    },
    # Ember + ash (warm pastel)
    "EMBER": {
        "PRIM": "#FFD0B5",  # ember peach
        "SEC": "#FFF4EE",
        "ACC": "#FFB3C7",  # rose accent
        "DIM": "#6B5450",
        "OK": "#BEE7D1",
        "ERR": "#FF9AA2",
        "TEXT": "#FFF9F6",
        "BORDER": "#8A8A8A",
        "BOX": getattr(box, "ROUNDED", None),
        "ICONS": {"PTR": "ᚦ", "ON": "ᛞ", "OFF": "·"},
    },
    # Desert rune (sand + sky)
    "SAND": {
        "PRIM": "#EAD7B1",  # sand gold
        "SEC": "#FFF8EA",
        "ACC": "#A7D8FF",  # soft sky
        "DIM": "#6A6156",
        "OK": "#CFE9C9",
        "ERR": "#FFB6B6",
        "TEXT": "#FFFDF7",
        "BORDER": "#8A8A8A",
        "BOX": getattr(box, "ROUNDED", None),
        "ICONS": {"PTR": "ᛉ", "ON": "ᚷ", "OFF": "·"},
    },
    # Steel + lilac (cool, high contrast but pastel)
    "STEEL": {
        "PRIM": "#C9D4E3",
        "SEC": "#F5F8FC",
        "ACC": "#D9C7FF",
        "DIM": "#4C5663",
        "OK": "#B8E6C9",
        "ERR": "#FFB3C7",
        "TEXT": "#FAFBFD",
        "BORDER": "#8A8A8A",
        "BOX": getattr(box, "DOUBLE", None),
        "ICONS": {"PTR": "ᛋ", "ON": "ᛟ", "OFF": "·"},
    },
    # Orchid night (purple + teal)
    "ORCHID": {
        "PRIM": "#E3C0FF",
        "SEC": "#FBF3FF",
        "ACC": "#9AD6C6",
        "DIM": "#5E4B6A",
        "OK": "#C7EFCF",
        "ERR": "#FFB0A3",
        "TEXT": "#FFF8FF",
        "BORDER": "#8A8A8A",
        "BOX": getattr(box, "ROUNDED", None),
        "ICONS": {"PTR": "ᛇ", "ON": "ᛜ", "OFF": "·"},
    },
    # Seafoam (green-blue) + sunlit accent
    "SEAFOAM": {
        "PRIM": "#BFE9E0",
        "SEC": "#F2FFFB",
        "ACC": "#FFD2A6",
        "DIM": "#3F5F5A",
        "OK": "#B8E6C9",
        "ERR": "#FFB3B3",
        "TEXT": "#F8FFFD",
        "BORDER": "#8A8A8A",
        "BOX": getattr(box, "ROUNDED", None),
        "ICONS": {"PTR": "ᚲ", "ON": "ᛝ", "OFF": "·"},
    },
}


@dataclass
class ThemeState:
    name: str
    banner: str
    banner_title: str
    box_style: Any
    icons: Dict[str, str]

    # canonical names (new)
    C_PRIM: str
    C_SEC: str
    C_ACC: str
    C_DIM: str
    C_OK: str
    C_ERR: str
    C_TEXT: str
    C_BORDER: str

    # legacy aliases
    C_GOLD: str
    C_STEEL: str
    C_BLUE: str
    C_ASH: str

    MENU_STYLE: Any

    # ------------------------------------------------------------------
    # Backwards compatibility helpers
    # Older modules expected a .colors() tuple in this exact order.
    # ------------------------------------------------------------------
    def colors(self):
        return (
            self.C_PRIM,
            self.C_SEC,
            self.C_ACC,
            self.C_ERR,
            self.C_OK,
            self.C_DIM,
            self.C_BORDER,
            self.C_TEXT,
        )

    def colors_dict(self) -> Dict[str, str]:
        return {
            "C_PRIM": self.C_PRIM,
            "C_SEC": self.C_SEC,
            "C_ACC": self.C_ACC,
            "C_ERR": self.C_ERR,
            "C_OK": self.C_OK,
            "C_DIM": self.C_DIM,
            "C_BORDER": self.C_BORDER,
            "C_TEXT": self.C_TEXT,
        }
    
    def get_rich_theme(self) -> Theme:
        """Returns a Rich Theme object mapped to this palette."""
        if Theme is None:
            return None # type: ignore
            
        return Theme({
            "bar.complete": self.C_PRIM,
            "bar.finished": self.C_OK,
            "bar.pulse": self.C_ACC,
            "progress.percentage": self.C_PRIM,
            "progress.description": self.C_TEXT,
            "progress.remaining": self.C_DIM,
            "progress.data.speed": self.C_ACC,
            "spinner": self.C_ACC,
            "danger": self.C_ERR,
            "success": self.C_OK,
        })


def _read_config(path: str) -> Tuple[str, str]:
    theme = "VALHALLA"
    banner = "TYR"
    try:
        if os.path.exists(path):
            with open(path, "r", encoding="utf-8") as f:
                data = json.load(f)
            theme = str(data.get("theme", theme)).upper()
            banner = str(data.get("banner", banner)).upper()
    except Exception:
        pass
    if theme not in THEMES:
        theme = "VALHALLA"
    if banner not in BANNERS:
        banner = "TYR"
    return theme, banner


def build_menu_style(C_PRIM: str, C_SEC: str, C_ACC: str, C_DIM: str, C_ERR: str, C_TEXT: str, hide_qmark: bool = True):
    """Create a stable InquirerPy style that avoids the 'ugly ?' question mark."""
    if get_style is None:
        return None
    return get_style(
        {
            "questionmark": "hidden" if hide_qmark else f"fg:{C_ACC}",
            "question": f"fg:{C_TEXT}",
            "answer": f"fg:{C_PRIM} bold",
            "input": f"fg:{C_TEXT}",
            "pointer": f"fg:{C_ACC} bold",
            "highlighted": f"fg:{C_ACC} bold",
            "selected": f"fg:{C_PRIM}",
            "separator": f"fg:{C_DIM}",
            "instruction": f"fg:{C_DIM}",
            "disabled": f"fg:{C_DIM}",
            "validator": f"fg:{C_ERR}",
            "skipped": f"fg:{C_DIM}",
            "cursor": "hidden",
        },
        style_override=True,
    )


def get_runtime_theme(config_path: Optional[str] = None) -> ThemeState:
    """Load config.json theme+banner and return a fully-populated ThemeState."""
    if config_path is None:
        base = os.path.dirname(os.path.abspath(__file__))
        config_path = os.path.join(base, "config.json")

    theme_name, banner_name = _read_config(config_path)
    t = THEMES.get(theme_name, THEMES["VALHALLA"])
    banner_txt = BANNERS.get(banner_name, BANNERS["TYR"]).strip("\n")
    banner_title = BANNER_TITLES.get(banner_name, "VALHALLA")

    C_PRIM = t["PRIM"]
    C_SEC = t["SEC"]
    C_ACC = t["ACC"]
    C_DIM = t["DIM"]
    C_OK = t["OK"]
    C_ERR = t["ERR"]
    C_TEXT = t["TEXT"]
    C_BORDER = _b(t.get("BORDER"), "#8A8A8A")

    box_style = t.get("BOX") or getattr(box, "ROUNDED", None)
    icons = t.get("ICONS", {"PTR": "›", "ON": "▣", "OFF": "☐"})

    # legacy aliases (to keep older code working)
    C_GOLD = C_PRIM
    C_STEEL = C_SEC
    C_BLUE = C_ACC
    C_ASH = C_SEC

    menu_style = build_menu_style(C_PRIM, C_SEC, C_ACC, C_DIM, C_ERR, C_TEXT, hide_qmark=True)

    return ThemeState(
        name=theme_name,
        banner=banner_txt,
        banner_title=banner_title,
        box_style=box_style,
        icons=icons,
        C_PRIM=C_PRIM,
        C_SEC=C_SEC,
        C_ACC=C_ACC,
        C_DIM=C_DIM,
        C_OK=C_OK,
        C_ERR=C_ERR,
        C_TEXT=C_TEXT,
        C_BORDER=C_BORDER,
        C_GOLD=C_GOLD,
        C_STEEL=C_STEEL,
        C_BLUE=C_BLUE,
        C_ASH=C_ASH,
        MENU_STYLE=menu_style,
    )
