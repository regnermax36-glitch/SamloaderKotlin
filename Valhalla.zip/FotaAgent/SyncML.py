from __future__ import annotations
from typing import Dict, Optional


SWITCH_PAGE = b'\x00'
END = b'\x01'
STR_I = b'\x03'

CP_SYNCML = 0
CP_METINF = 1

TOKENS_SYNCML = {
    'SyncML': b'\x6d',
    'SyncHdr': b'\x6c',
    'SyncBody': b'\x6b',
    'VerDTD': b'\x71',
    'VerProto': b'\x72',
    'SessionID': b'\x65',
    'MsgID': b'\x5b',
    'Target': b'\x6e',
    'Source': b'\x67',
    'LocURI': b'\x57',
    'LocName': b'\x56',
    'Cred': b'\x4e',
    'Meta': b'\x5a',
    'Data': b'\x4f',
    'Alert': b'\x46',
    'CmdID': b'\x4b',
    'Item': b'\x54',
    'Status': b'\x69',
    'Results': b'\x62',
    'Cmd': b'\x4a',
    'CmdRef': b'\x4c',
    'MsgRef': b'\x5c',
    'TargetRef': b'\x6f',
    'SourceRef': b'\x68',
    'Final': b'\x12',
    'Replace': b'\x60',
}

TOKENS_METINF = {
    'Format': b'\x47',
    'Type': b'\x53',
    'MaxMsgSize': b'\x4c',
    'MaxObjSize': b'\x55',
    'Size': b'\x52',
}

class SyncML:
    def __init__(self):
        self.next_cmd_id = 1
        self.wbxml = bytearray()
        self._write_header()
        self._start_element(TOKENS_SYNCML['SyncML'])
        self._start_header("1.2", "DM/1.2")
        self.body_started = False
        self._finalized = False
        
    def _write_header(self) -> None:
        public_id = b'-//SYNCML//DTD SyncML 1.2//EN'
        self.wbxml.extend(b'\x02\x00\x00j')
        self.wbxml.append(len(public_id))
        self.wbxml.extend(public_id)

    def _switch_page(self, page: int) -> None:
        self.wbxml.extend(SWITCH_PAGE)
        self.wbxml.append(page)

    def _start_element(self, token: bytes) -> None:
        self.wbxml.extend(token)

    def _end_element(self) -> None:
        self.wbxml.extend(END)

    def _add_leaf(self, token: bytes, text: Optional[str] = None) -> None:
        self.wbxml.extend(token)
        if text is not None:
            text_bytes = text.encode('utf-8')
            self.wbxml.extend(STR_I)
            self.wbxml.extend(text_bytes)
            self.wbxml.append(0)
        self.wbxml.extend(END)

    def _start_header(self, ver_dtd: str, ver_proto: str) -> None:
        self._start_element(TOKENS_SYNCML['SyncHdr'])
        self._add_leaf(TOKENS_SYNCML['VerDTD'], ver_dtd)
        self._add_leaf(TOKENS_SYNCML['VerProto'], ver_proto)

    def add_header(
        self,
        session_id: str,
        msg_id: int,
        target_uri: str,
        source_uri: str,
        cred_data: str,
        max_msg_size: int = 5120,
        max_obj_size: int = 1048576
    ) -> None:
        self._add_leaf(TOKENS_SYNCML['SessionID'], session_id)
        self._add_leaf(TOKENS_SYNCML['MsgID'], str(msg_id))

        self._start_element(TOKENS_SYNCML['Target'])
        self._add_leaf(TOKENS_SYNCML['LocURI'], target_uri)
        self._end_element()

        self._start_element(TOKENS_SYNCML['Source'])
        self._add_leaf(TOKENS_SYNCML['LocURI'], source_uri)
        self._add_leaf(TOKENS_SYNCML['LocName'], source_uri)
        self._end_element()

        if cred_data:
            self._start_element(TOKENS_SYNCML['Cred'])
            self._start_element(TOKENS_SYNCML['Meta'])
            self._switch_page(CP_METINF)
            self._add_leaf(TOKENS_METINF['Format'], "b64")
            self._add_leaf(TOKENS_METINF['Type'], "syncml:auth-md5")
            self._switch_page(CP_SYNCML)
            self._end_element()
            self._add_leaf(TOKENS_SYNCML['Data'], cred_data)
            self._end_element()

        self._start_element(TOKENS_SYNCML['Meta'])
        self._switch_page(CP_METINF)
        self._add_leaf(TOKENS_METINF['MaxMsgSize'], str(max_msg_size))
        self._add_leaf(TOKENS_METINF['MaxObjSize'], str(max_obj_size))
        self._switch_page(CP_SYNCML)
        self._end_element()
        
        self._end_element()
        self._start_element(TOKENS_SYNCML['SyncBody'])
        self.body_started = True

    def add_alert(
        self,
        data: str,
        item_uri: Optional[str] = None,
        item_data: Optional[str] = None,
        item_type: Optional[str] = None,
        item_format: str = "chr"
    ) -> None:
        if not self.body_started:
            raise RuntimeError("SyncBody not started. Call add_header first.")
        
        self._start_element(TOKENS_SYNCML['Alert'])
        self._add_leaf(TOKENS_SYNCML['CmdID'], str(self.next_cmd_id))
        self._add_leaf(TOKENS_SYNCML['Data'], data)
        
        if item_uri:
            self._start_element(TOKENS_SYNCML['Item'])
            self._start_element(TOKENS_SYNCML['Source'])
            self._add_leaf(TOKENS_SYNCML['LocURI'], item_uri)
            self._end_element()
            
            if item_type:
                self._start_element(TOKENS_SYNCML['Meta'])
                self._switch_page(CP_METINF)
                self._add_leaf(TOKENS_METINF['Format'], item_format)
                self._add_leaf(TOKENS_METINF['Type'], item_type)
                self._switch_page(CP_SYNCML)
                self._end_element()
            
            if item_data is not None:
                self._add_leaf(TOKENS_SYNCML['Data'], item_data)
            
            self._end_element()
        
        self._end_element()
        self.next_cmd_id += 1

    def add_replace(self, items: Dict[str, str]) -> None:
        if not self.body_started:
            raise RuntimeError("SyncBody not started. Call add_header first.")
        
        self._start_element(TOKENS_SYNCML['Replace'])
        self._add_leaf(TOKENS_SYNCML['CmdID'], str(self.next_cmd_id))
        
        for uri, data in items.items():
            self._start_element(TOKENS_SYNCML['Item'])
            self._start_element(TOKENS_SYNCML['Source'])
            self._add_leaf(TOKENS_SYNCML['LocURI'], uri)
            self._end_element()
            self._add_leaf(TOKENS_SYNCML['Data'], data)
            self._end_element()
        
        self._end_element()
        self.next_cmd_id += 1

    def add_status(
        self,
        data: str,
        msg_ref: Optional[int] = None,
        cmd_ref: Optional[int] = None,
        cmd: Optional[str] = None,
        target_ref: Optional[str] = None,
        source_ref: Optional[str] = None
    ) -> None:
        if not self.body_started:
            raise RuntimeError("SyncBody not started. Call add_header first.")
        
        self._start_element(TOKENS_SYNCML['Status'])
        self._add_leaf(TOKENS_SYNCML['CmdID'], str(self.next_cmd_id))
        self._add_leaf(TOKENS_SYNCML['Data'], data)
        
        if msg_ref is not None:
            self._add_leaf(TOKENS_SYNCML['MsgRef'], str(msg_ref))
        if cmd_ref is not None:
            self._add_leaf(TOKENS_SYNCML['CmdRef'], str(cmd_ref))
        if cmd:
            self._add_leaf(TOKENS_SYNCML['Cmd'], cmd)
        if target_ref:
            self._add_leaf(TOKENS_SYNCML['TargetRef'], target_ref)
        if source_ref:
            self._add_leaf(TOKENS_SYNCML['SourceRef'], source_ref)
        
        self._end_element()
        self.next_cmd_id += 1

    def add_results(
        self,
        loc_uri: str,
        data: str,
        msg_ref: Optional[int] = None,
        cmd_ref: Optional[int] = None,
        data_type: str = "text/plain",
        data_format: str = "chr"
    ) -> None:
        if not self.body_started:
            raise RuntimeError("SyncBody not started. Call add_header first.")
        
        self._start_element(TOKENS_SYNCML['Results'])
        self._add_leaf(TOKENS_SYNCML['CmdID'], str(self.next_cmd_id))
        
        self._start_element(TOKENS_SYNCML['Item'])
        self._start_element(TOKENS_SYNCML['Source'])
        self._add_leaf(TOKENS_SYNCML['LocURI'], loc_uri)
        self._end_element()
        
        self._start_element(TOKENS_SYNCML['Meta'])
        self._switch_page(CP_METINF)
        self._add_leaf(TOKENS_METINF['Format'], data_format)
        self._add_leaf(TOKENS_METINF['Type'], data_type)
        self._add_leaf(TOKENS_METINF['Size'], str(len(data)))
        self._switch_page(CP_SYNCML)
        self._end_element()
        
        self._add_leaf(TOKENS_SYNCML['Data'], data)
        self._end_element()
        
        if msg_ref is not None:
            self._add_leaf(TOKENS_SYNCML['MsgRef'], str(msg_ref))
        if cmd_ref is not None:
            self._add_leaf(TOKENS_SYNCML['CmdRef'], str(cmd_ref))
        
        self._end_element()
        self.next_cmd_id += 1

    def finalize(self) -> None:
        """Append <Final/> and close SyncBody exactly once."""
        if not self.body_started:
            raise RuntimeError("SyncBody not started. Call add_header first.")
        if self._finalized:
            return
        self._add_leaf(TOKENS_SYNCML['Final'])
        self._end_element()  # end SyncBody
        self._finalized = True
        self.body_started = False

    def get(self) -> bytes:
        """Return the WBXML document bytes (finalized)."""
        self.finalize()
        return bytes(self.wbxml)