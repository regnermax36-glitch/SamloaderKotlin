#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
VALHALLA HUB — v350 (ROYAL UPDATE)
- [VISUAL] ODIN Banner: Now a heavy, regal block (matches Tyr/Thor).
- [MENU] Renamed: Themes -> BIFROST, Exit -> RAGNAROK.
- [SYSTEM] Full Pantheon Integration (Hugin, Sleipnir, Mimir).
"""

from __future__ import annotations

import os
import re
os.environ.setdefault("PROMPT_TOOLKIT_NO_CPR", "1")
import sys
import time
import json
import types
import traceback
import sqlite3
import importlib.util
from dataclasses import dataclass
from typing import Any, Optional, Sequence, Tuple, List, Dict

# -----------------------------
# 0) BASE PATH
# -----------------------------
APP_DIR = os.path.dirname(os.path.abspath(__file__))
try:
    os.chdir(APP_DIR)
except Exception:
    pass

if APP_DIR not in sys.path:
    sys.path.insert(0, APP_DIR)

# -----------------------------
# 1) DEPENDENCIES
# -----------------------------
try:
    from rich.console import Console
    from rich.panel import Panel
    from rich.table import Table
    from rich.text import Text
    from rich.align import Align
    from rich import box
except Exception:
    print("Missing dependency: rich\nInstall: pip install rich")
    raise

try:
    from InquirerPy import inquirer as orig_inquirer
    from InquirerPy.base.control import Choice as OrigChoice
    from InquirerPy.utils import get_style
    from InquirerPy.separator import Separator
except Exception:
    print("Missing dependency: InquirerPy\nInstall: pip install InquirerPy")
    raise

console = Console()

# -----------------------------
# 2) THEME ENGINE & ART
# -----------------------------
# Centralized, shareable themes + banners.
from valhalla_themes import BANNERS, BANNER_TITLES, THEMES

# --- GLOBAL STATE ---
CURRENT_THEME = "VALHALLA"
CURRENT_BANNER = "TYR"

C_GOLD = C_STEEL = C_BLUE = C_DIM = C_OK = C_ERR = C_TEXT = ""
CURRENT_BOX = box.ROUNDED
ICON_PTR = "›"
ICON_ON = "[x]"
ICON_OFF = "[ ]"
STYLE = None 

def apply_theme(theme_name: str, banner_name: str):
    global C_GOLD, C_STEEL, C_BLUE, C_DIM, C_OK, C_ERR, C_TEXT, STYLE, CURRENT_THEME, CURRENT_BANNER
    global ICON_PTR, ICON_ON, ICON_OFF, CURRENT_BOX
    
    t = THEMES.get(theme_name, THEMES["VALHALLA"])
    CURRENT_THEME = theme_name
    CURRENT_BANNER = banner_name
    
    C_GOLD = t["PRIM"]
    C_STEEL = t["SEC"]
    C_BLUE = t["ACC"]
    C_DIM = t["DIM"]
    C_OK = t["OK"]
    C_ERR = t["ERR"]
    C_TEXT = t["TEXT"]
    
    CURRENT_BOX = t.get("BOX", box.ROUNDED)
    icons = t.get("ICONS", {"PTR": "›", "ON": "▣", "OFF": "☐"})
    ICON_PTR = icons["PTR"]
    ICON_ON = icons["ON"]
    ICON_OFF = icons["OFF"]

    STYLE = get_style({
        "questionmark": "hidden",
        "question": f"{C_STEEL} bold",
        "pointer": f"{C_GOLD} bold",
        "highlight": f"{C_STEEL} bold",
        "answer": C_STEEL,
        "input": C_STEEL,
        "validator": C_ERR,
        "skipped": C_DIM,
        "cursor": "hidden",
    }, style_override=True)

apply_theme("VALHALLA", "TYR")

# -----------------------------
# 3) CONFIG IO
# -----------------------------
CONFIG_FILE = os.path.join(APP_DIR, "config.json")

def load_hub_config():
    try:
        if os.path.exists(CONFIG_FILE):
            with open(CONFIG_FILE, "r", encoding="utf-8") as f:
                data = json.load(f)
                t = data.get("theme", "VALHALLA")
                b = data.get("banner", "TYR")
                if b not in BANNERS: b = "TYR"
                apply_theme(t, b)
                return data
    except: pass
    return {}

def save_hub_config_key(key, value):
    data = load_hub_config() or {}
    data[key] = value
    try:
        with open(CONFIG_FILE, "w", encoding="utf-8") as f:
            json.dump(data, f, indent=4)
    except Exception as e:
        hub_error("CONFIG SAVE FAILED", str(e))

load_hub_config()

# -----------------------------
# 4) UTILS
# -----------------------------
def _clear(): print("\033[H\033[2J\033[3J", end="")
def restore_terminal():
    """Best-effort restore of terminal input/cursor state after Rich/curses/mouse tracking."""
    try:
        sys.stdout.write("\x1b[?1000l")  # mouse tracking off
        sys.stdout.write("\x1b[?1002l")
        sys.stdout.write("\x1b[?1003l")
        sys.stdout.write("\x1b[?1006l")
        sys.stdout.write("\x1b[?1015l")
        sys.stdout.write("\x1b[?25h")    # show cursor
        sys.stdout.write("\x1b[0m")      # reset attrs
        sys.stdout.write("\x1b[?1049l")  # exit alt screen
        sys.stdout.flush()
    except Exception:
        pass

    # Termux/SSH: this is the real lifesaver if tty mode got messed
    try:
        os.system("stty sane 2>/dev/null")
    except Exception:
        pass
def _now_str(): return time.strftime("%Y-%m-%d %H:%M:%S")

_EMOJI_RE = re.compile(r'[\U00010000-\U0010ffff]')
_SEP_RE = re.compile(r'^[\-\—\_=\s]{3,}$')

def normalize_label(raw: str) -> str:
    s = _EMOJI_RE.sub("", str(raw))
    s = s.replace("\t", " ").replace("\r", " ").replace("\n", " ")
    s = s.replace("■", "")
    s = re.sub(r"\s{2,}", " ", s)
    return s.strip()

def is_empty_or_separator(label: str) -> bool:
    return not label or bool(_SEP_RE.match(label))

def service_status():
    cfg = load_hub_config()
    tg = cfg.get("telegram", {})
    tg_ok = bool(tg.get("enabled") and tg.get("bot_token") and tg.get("chat_id"))
    dr = cfg.get("drive", {})
    cred_ok = os.path.exists(os.path.join(APP_DIR, str(dr.get("token_file", "token.pickle"))))
    
    db_hits = 0
    db_path = os.path.join(APP_DIR, "database", "fumo_history.db")
    if os.path.exists(db_path):
        try:
            conn = sqlite3.connect(db_path)
            c = conn.cursor(); c.execute("SELECT COUNT(*) FROM firmware_hits"); db_hits = c.fetchone()[0]; conn.close()
        except: pass

    return {"tg": ("ONLINE", tg_ok), "drive": ("LINKED", cred_ok), "db_hits": db_hits}

# -----------------------------
# 5) MODULE RESOLUTION
# -----------------------------
@dataclass(frozen=True)
class ModuleSpec:
    key: str; hint_glob: str; default_filename: str

MODULES = [
    ModuleSpec("intelligence", "intelligence*.py", "intelligence_v102.py"),
    ModuleSpec("decrypter",    "decrypter*.py",    "decrypter10.py"),
    ModuleSpec("logistics",    "logistics*.py",    "logistics_v150.py"),
    ModuleSpec("fus",          "valhalla_fus.py",  "valhalla_fus.py"),
]

def resolve_module_file(spec: ModuleSpec) -> str:
    default_path = os.path.join(APP_DIR, spec.default_filename)
    if os.path.exists(default_path): return default_path
    import glob
    matches = glob.glob(os.path.join(APP_DIR, spec.hint_glob))
    if matches: return sorted(matches)[-1]
    return default_path

def import_from_path(module_name: str, file_path: str) -> types.ModuleType:
    if not os.path.exists(file_path): raise FileNotFoundError(file_path)
    spec = importlib.util.spec_from_file_location(module_name, file_path)
    mod = importlib.util.module_from_spec(spec)
    sys.modules[module_name] = mod
    spec.loader.exec_module(mod)
    return mod

# -----------------------------
# 6) INTERCEPTOR & ICON MAP
# -----------------------------
MODULE_ICON = {"intelligence": "ᛋ", "decrypter": "ᚦ", "logistics": "ᛟ", "fus": "ᛞ"}
KEYWORD_ICON = [
    (("hugin", "intel"), "ᚺ"),       # Hugin (H)
    (("sleipnir", "logistic"), "ᛋ"), # Sleipnir (S)
    (("mimir", "decrypt"), "ᛗ"),     # Mimir (M)
    (("bifrost", "theme"), "ᛒ"),     # Bifrost (B)
    (("ragnarok", "exit"), "ᛦ"),     # Ragnarok (Yr/Death)
    (("smart", "auto"), "ᛊ"),
    (("timeline", "history"), "ᛦ"),
    (("pair", "link"), "ᚷ"),
    (("base", "manual"), "ᛒ"),
    (("scan", "operations", "run"), "ᚱ"),
    (("queue", "night", "shift"), "ᛃ"),
    (("config", "setting", "policy"), "ᛏ"),
    (("download", "archive"), "ᚹ"),
    (("hub", "main"), "ᛟ"),
    (("batch", "db", "database"), "ᛞ"),
]
DEFAULT_ICON = "ᛉ"

def pick_icon(value: Any, label: str) -> str:
    v = str(value).strip().lower()
    low = label.lower()
    for keys, ico in KEYWORD_ICON:
        if any(k in low for k in keys): return ico
    return DEFAULT_ICON

def extract_rune_prefix(raw: str) -> Tuple[Optional[str], str]:
    s = str(raw or "").strip()
    if not s: return None, s
    if 0x16A0 <= ord(s[0]) <= 0x16FF: return s[0], s[1:].strip()
    return None, s

class ValhallaChoice(OrigChoice):
    def __init__(self, value: Any, name: Optional[str] = None, enabled: bool = False, icon: Optional[str] = None):
        raw = name if name is not None else str(value)
        existing_rune, cleaned_text = extract_rune_prefix(raw)
        final_text = normalize_label(cleaned_text).upper()
        if icon: final_icon = icon
        elif existing_rune: final_icon = existing_rune 
        else: final_icon = pick_icon(value, final_text)
        super().__init__(value, f"{final_icon}  {final_text}", enabled)

class InquirerInterceptor:
    def _normalize_choices(self, raw_choices: Sequence[Any]) -> List[Any]:
        out = []
        for c in raw_choices:
            if isinstance(c, OrigChoice):
                if not is_empty_or_separator(c.name): out.append(ValhallaChoice(c.value, c.name, c.enabled))
            elif isinstance(c, dict):
                if not is_empty_or_separator(c.get("name")): out.append(ValhallaChoice(c.get("value"), c.get("name")))
            elif isinstance(c, str):
                if not is_empty_or_separator(c): out.append(ValhallaChoice(c, c))
            elif isinstance(c, Separator): out.append(c)
        return out

    def select(self, *args, **kwargs):
        kwargs.update({"style": STYLE, "qmark": "", "cycle": True, "pointer": ICON_PTR})
        if "message" in kwargs: kwargs["message"] = f" {normalize_label(kwargs['message']).upper()}"
        kwargs["choices"] = self._normalize_choices(kwargs.get("choices", []))
        return orig_inquirer.select(*args, **kwargs)

    def checkbox(self, *args, **kwargs):
        kwargs.update({
            "style": STYLE, "qmark": "", "cycle": True, "pointer": ICON_PTR,
            "enabled_symbol": ICON_ON, "disabled_symbol": ICON_OFF
        })
        if "message" in kwargs: kwargs["message"] = f" {normalize_label(kwargs['message']).upper()}"
        kwargs["choices"] = self._normalize_choices(kwargs.get("choices", []))
        return orig_inquirer.checkbox(*args, **kwargs)

    def text(self, *args, **kwargs):
        kwargs.update({"style": STYLE, "qmark": ""})
        if "message" in kwargs: kwargs["message"] = f" {normalize_label(kwargs['message'])}"
        return orig_inquirer.text(*args, **kwargs)
    def confirm(self, *args, **kwargs):
        kwargs.update({"style": STYLE, "qmark": ""})
        return orig_inquirer.confirm(*args, **kwargs)

inquirer = InquirerInterceptor()
# -----------------------------
# 7) HEADER
# -----------------------------
class HubHeader:
    english_title = "VALHALLA HUB"; runic_title = "ᚲᛟᛗᛗᚨᚾᛞ ᚲᛖᚾᛏᛖᚱ"; sub_info = ""
    @staticmethod
    def render():
        restore_terminal()
        _clear()
        
        emblem_txt = BANNERS.get(CURRENT_BANNER, BANNERS["TYR"])
        left = Text(emblem_txt.strip("\n"), style=f"bold {C_GOLD}", justify="center")
        
        disp_title = HubHeader.english_title
        if disp_title == "VALHALLA HUB":
            disp_title = BANNER_TITLES.get(CURRENT_BANNER, "VALHALLA HUB")

        # Right side info
        right = Table.grid(padding=(0, 1)); right.add_column(justify="left")
        right.add_row(Text(disp_title, style=f"bold {C_TEXT}"))
        
        # [FIX] Changed style from C_OK (Green) to C_GOLD/C_PRIM (Theme Color)
        mode_text = Text(HubHeader.runic_title, style=f"bold {C_GOLD}")
        if HubHeader.sub_info: mode_text.append(f"  {HubHeader.sub_info}", style=C_DIM)
        right.add_row(mode_text)
        right.add_row(Text(f"TIME ᛬ { _now_str() }", style=C_DIM))
        
        # Main Layout Grid
        # [FIX] Padding=(0, 3) prevents squeezing
        top = Table.grid(expand=True, padding=(0, 3))
        
        # [FIX] width=34 + vertical="middle" for perfect centering
        top.add_column(justify="center", width=34, vertical="middle")
        top.add_column(justify="left", ratio=1, vertical="middle")
        
        top.add_row(Align.center(left, vertical="middle"), Align.left(right, vertical="middle"))
        
        console.print(Panel(top, border_style=C_DIM, box=CURRENT_BOX, padding=(0, 0)))
        
        # Stats Bar
        s = service_status()
        st = Table.grid(expand=True, padding=(0, 0))
        def stat_text(icon, label, value, color, is_active):
            return Text.assemble((f"{icon} {label} ", C_STEEL), (f"᛬ ", f"bold {C_GOLD}"), (str(value), f"bold {color if is_active else C_DIM}"))
            
        tg_ok = s["tg"][1]; dr_ok = s["drive"][1]; db_count = s["db_hits"]
        st.add_column(justify="center", ratio=1); st.add_column(justify="center", ratio=1); st.add_column(justify="center", ratio=1)
        st.add_row(
            stat_text("ᛇ", "TELEGRAM", "ON" if tg_ok else "OFF", C_OK, tg_ok),
            stat_text("ᛃ", "DRIVE", "ON" if dr_ok else "OFF", C_OK, dr_ok),
            stat_text("ᛞ", "DB", f"{db_count}", C_BLUE, db_count > 0)
        )
        console.print(Panel(st, border_style=C_DIM, box=CURRENT_BOX, padding=(0, 0))); console.print()

def hub_error(title: str, body: str):
    console.print(Panel(Align.left(Text(body, style=C_TEXT)), title=f"[bold {C_ERR}]{title}[/]", border_style=C_ERR, box=box.HEAVY))

# -----------------------------
# 8) ASSIMILATION
# -----------------------------
class ReturnToHub(BaseException): pass
def _fake_exit(code: int = 0): raise ReturnToHub()
def _run_with_exit_trap(fn):
    original_exit = sys.exit; sys.exit = _fake_exit
    try: fn()
    except ReturnToHub: pass
    except Exception as e: raise e
    finally:
        sys.exit = original_exit
        restore_terminal()

def assimilate(module_obj: types.ModuleType):
    IDENTITY_MAP = {
        "INTELLIGENCE": ("HUGIN",    "ᚺᚢᚷᛁᚾ",       "v103"), 
        "LOGISTICS":    ("SLEIPNIR", "ᛋᛚᛖᛁᛈᚾᛁᚱ",    "v150"), 
        "DECRYPTER":    ("MIMIR",    "ᛗᛁᛗᛁᚱ",       "v33"),
        "FUS":          ("ODIN",     "ᛟᛞᛁᚾ",       "v2.0"),  
    }
    
    try:
        fname = os.path.basename(module_obj.__file__).lower()
        key = "UNKNOWN"
        if "intelligence" in fname: key = "INTELLIGENCE"
        elif "logistics" in fname:  key = "LOGISTICS"
        elif "decrypter" in fname:  key = "DECRYPTER"
        elif "fus" in fname:        key = "FUS"
        
        if key in IDENTITY_MAP:
            name_en, name_rune, ver = IDENTITY_MAP[key]
            HubHeader.english_title = name_en
            HubHeader.runic_title = name_rune
            HubHeader.sub_info = ver
        else:
            HubHeader.english_title = "MODULE"
            HubHeader.runic_title = "ᛗᛟᛞᚢᛚᛖ"
            HubHeader.sub_info = "UNKNOWN"
            
    except: pass

    module_obj.inquirer = inquirer
    module_obj.Choice = ValhallaChoice
    
    if hasattr(module_obj, "Dashboard"):
        class ProxyDashboard(module_obj.Dashboard):
            @staticmethod
            def header(*args, **kwargs): HubHeader.render()
        module_obj.Dashboard = ProxyDashboard

    # INJECT COLORS & THEME
    color_map = {
        "C_PRIM": C_GOLD, "C_ACC": C_BLUE, "C_SEC": C_STEEL,
        "C_OK": C_OK, "C_ERR": C_ERR, "C_DIM": C_DIM, "C_TEXT": C_TEXT,
        "MENU_STYLE": STYLE,
        "C_GOLD": C_GOLD, "C_STEEL": C_STEEL, "C_BLUE": C_BLUE, "C_ASH": C_STEEL
    }
    for k, v in color_map.items():
        if hasattr(module_obj, k): setattr(module_obj, k, v)
    
    # INJECT BANNER (The Fix for "Still not picking logo")
    if hasattr(module_obj, "GLOBAL_BANNER"):
        # We strip the border lines from the main banner to make it fit the scanner header better
        raw_banner = BANNERS.get(CURRENT_BANNER, BANNERS["TYR"])
        module_obj.GLOBAL_BANNER = raw_banner
    
    if not hasattr(module_obj, "ReturnToHub"): module_obj.ReturnToHub = ReturnToHub

# -----------------------------
# 9) LAUNCHERS
# -----------------------------

def run_fus():
    mod = import_from_path("valhalla_fus", resolve_module_file(MODULES[3]))
    assimilate(mod)
    if hasattr(mod, "FusController"): _run_with_exit_trap(lambda: mod.FusController().main_menu())

def run_logistics():
    mod = import_from_path("valhalla_logistics", resolve_module_file(MODULES[2]))
    assimilate(mod)
    if hasattr(mod, "LogisticsController"): _run_with_exit_trap(lambda: mod.LogisticsController().main_menu())

def run_intelligence():
    mod = import_from_path("valhalla_intelligence", resolve_module_file(MODULES[0]))
    assimilate(mod)
    if hasattr(mod, "IntelligenceController"): _run_with_exit_trap(lambda: mod.IntelligenceController().main_menu())
    
def run_decrypter():
    mod = import_from_path("valhalla_decrypter", resolve_module_file(MODULES[1]))
    assimilate(mod)
    
    # Ensure config is loaded
    if hasattr(mod.TelegramService, "load_config"):
        mod.TelegramService.load_config()

    while True:
        HubHeader.render()
        restore_terminal()
        
        # Get Current States
        tg_state = "ON" if getattr(mod.TelegramService, "ENABLED", False) else "OFF"
        
        # MAIN MIMIR MENU
        op = inquirer.select("MIMIR CORE:", choices=[
            {"value": "single",  "name": "Single Key Decrypt"},
            {"value": "batch",   "name": "Batch Process (Database)"},
            {"value": "tg_menu", "name": "Telegram Settings"},
            {"value": "back",    "name": "Back"}
        ]).execute()
        
        if op == "back": return
        
        # --- TELEGRAM SUBMENU ---
        elif op == "tg_menu":
            while True:
                HubHeader.render()
                
                curr_tg = "ON" if getattr(mod.TelegramService, "ENABLED", False) else "OFF"
                curr_lim = getattr(mod.TelegramService, "REPORT_LIMIT", 1)
                
                sub = inquirer.select(f"TELEGRAM CONFIG [Limit: {curr_lim}]:", choices=[
                    {"value": "toggle", "name": f"Toggle Service [{curr_tg}]"},
                    {"value": "limit",  "name": f"Set Build Limit [{curr_lim}]"},
                    {"value": "back",   "name": "Back"}
                ]).execute()
                
                if sub == "back": 
                    break
                
                elif sub == "toggle":
                    mod.TelegramService.ENABLED = not mod.TelegramService.ENABLED
                    
                elif sub == "limit":
                    raw = inquirer.text(message="Max builds to send (1-10):", default=str(curr_lim)).execute()
                    if raw.isdigit():
                        val = int(raw)
                        if val < 1: val = 1
                        if val > 10: val = 10
                        mod.TelegramService.REPORT_LIMIT = val
        
        elif op == "batch": 
            _run_with_exit_trap(lambda: mod.run_batch_ui())
            
        elif op == "single":
            while True:
                m = inquirer.text(message="Model [b to back]:").execute().strip()
                if m.lower() in ['b', 'back', '']: break
                c = inquirer.text(message="CSC [b to back]:").execute().strip()
                if c.lower() in ['b', 'back', '']: continue
                _run_with_exit_trap(lambda: mod.run_decrypter(m, c))
                console.input("[dim]Press Enter to continue...[/]")
                break

# -----------------------------
# 10) THEME MENU
# -----------------------------
def theme_settings():
    while True:
        HubHeader.english_title = "THEME CONFIG"
        HubHeader.runic_title = "ᛏᚺᛖᛗᛖ ᛋᛖᛏᛏᛁᚾᚷᛋ"
        HubHeader.render()
        
        op = inquirer.select("VISUAL SETTINGS:", choices=[
            {"value": "color",  "name": f"Color Theme [{CURRENT_THEME}]"},
            {"value": "banner", "name": f"Banner Style [{CURRENT_BANNER}]"},
            {"value": "back",   "name": "Back"}
        ]).execute()
        
        if op == "back": return
        elif op == "color":
            choices = []
            for t in THEMES.keys():
                mark = "●" if t == CURRENT_THEME else "○"
                choices.append({"value": t, "name": f"{mark} {t}"})
            sel = inquirer.select("Select Theme:", choices=choices).execute()
            apply_theme(sel, CURRENT_BANNER)
            save_hub_config_key("theme", sel)
        elif op == "banner":
            choices = []
            for b in BANNERS.keys():
                mark = "●" if b == CURRENT_BANNER else "○"
                choices.append({"value": b, "name": f"{mark} {b}"})
            sel = inquirer.select("Select Banner:", choices=choices).execute()
            apply_theme(CURRENT_THEME, sel)
            save_hub_config_key("banner", sel)

# -----------------------------
# 11) MAIN LOOP
# -----------------------------
def main():
    while True:
        HubHeader.english_title = "VALHALLA HUB"
        HubHeader.runic_title = "ᚲᛟᛗᛗᚨᚾᛞ ᚲᛖᚾᛏᛖᚱ"
        HubHeader.sub_info = ""
        HubHeader.render()
        
        choice = inquirer.select(message="HUB ACCESS", choices=[
            {"value": "intelligence", "name": "HUGIN (Intelligence)"},
            {"value": "logistics",    "name": "SLEIPNIR (Logistics)"},
            {"value": "decrypter",    "name": "MIMIR (Decrypter)"},
            {"value": "fus",          "name": "ODIN (FUS Downloader)"},
            {"value": "theme",        "name": "BIFROST (Visuals)"},
            {"value": "quit",         "name": "RAGNAROK (Exit)"},
        ]).execute()

        try:
            if choice == "quit": _clear(); console.print(f"\n[{C_ERR}]SESSION TERMINATED.[/]"); return
            elif choice == "theme": theme_settings()
            elif choice == "intelligence": run_intelligence()
            elif choice == "logistics": run_logistics()
            elif choice == "decrypter": run_decrypter()
            elif choice == "fus": run_fus()
        except ReturnToHub: _clear(); continue
        except KeyboardInterrupt: return
        except Exception as e:
            hub_error("CRITICAL ERROR", f"{e}\n\n{traceback.format_exc()}")
            input(f"\n[{C_DIM}]Enter...[/]")

if __name__ == "__main__":
    main()