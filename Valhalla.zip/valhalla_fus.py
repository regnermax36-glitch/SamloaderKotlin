#!/usr/bin/env python3
# -*- coding: utf-8 -*-

"""
VALHALLA FUS (ODIN PROTOCOL)
Direct Samsung Server Downloader with AES Decryption
Features: Multi-CSC Scanning, Aria2 Support, Smart Naming, Dynamic Theming
"""

import os
import sys
import time
import hashlib
import requests
import threading
import concurrent.futures
import xml.etree.ElementTree as ET
import subprocess
import shutil
from Cryptodome.Cipher import AES
from Cryptodome.Util.Padding import pad, unpad
import base64
import re

# --- VALHALLA IMPORTS ---
try:
    from rich.console import Console
    from rich.panel import Panel
    from rich.table import Table
    from rich.text import Text
    from rich.align import Align
    from rich.progress import (
        Progress, SpinnerColumn, BarColumn, TextColumn, 
        TransferSpeedColumn, TimeRemainingColumn
    )
    from rich import box
    from InquirerPy import inquirer
    from InquirerPy.base.control import Choice
    from InquirerPy.separator import Separator
    from InquirerPy.utils import get_style
except ImportError:
    pass

console = Console()

# --- DEFAULT THEME (Overwritten by Main.py) ---
C_PRIM    = "#dab900" 
C_SEC     = "#a8a8a8"
C_ACC     = "#6c9cd4"
C_ERR     = "#d46c6c"
C_OK      = "#87d787"
C_DIM     = "#585858"
C_TEXT    = "#eeeeee"

MENU_STYLE = get_style({
    "questionmark": "hidden",
    "question": "#eeeeee",
    "pointer": "#dab900 bold",
    "highlight": "#dab900 bold",
    "answer": "#dab900",
    "input": "#dab900",
    "validator": "#d46c6c",
}, style_override=False)

# --- FUS CONFIG ---
MULTI_CSC_GROUPS = {
    'OXM': ['EUX', 'BTU', 'DBT', 'XEU', 'ITV', 'PHN', 'XEF', 'XEO', 'SEE', 'NEE', 'ATO', 'AUT', 'BGL', 'EUR', 'LUX', 'ORX', 'ROM', 'SEK', 'SIO', 'SLK', 'VNZ', 'XEH', 'XEZ', 'ACR', 'AFG', 'AFR', 'ARO', 'CAC', 'CAM', 'CAU', 'CHO', 'COO', 'DKR', 'ECT', 'EGY', 'EON', 'ILO', 'INS', 'KSA', 'LYS', 'MID', 'MM1', 'MWD', 'MYM', 'NPL', 'PAK', 'PKD', 'PLS', 'SER', 'SKZ', 'THR', 'TPA', 'TUN', 'TUR', 'XFA', 'XFE', 'XFV', 'XSA', 'XSG'],
    'OLM': ['XME', 'XSP', 'XTC', 'XXV', 'SIN', 'STH', 'SMA', 'GLB', 'THL', 'MM1', 'MYM', 'NPL'],
    'OXE': ['SER', 'CAU', 'SKZ', 'SEK'],
    'OWA': ['CDR', 'CHL', 'COM', 'CPA', 'CRC', 'CTI', 'DOO', 'DOR', 'ECO', 'GTO', 'MXO', 'NII', 'PAC', 'PAN', 'PNT', 'PRT', 'SCR', 'TFA', 'TGO', 'TPA', 'TTT', 'UPO', 'UYU', 'ZTO'],
    'OYN': ['XAA', 'USC', 'VZW', 'ATT', 'TMB', 'SPR', 'CCT', 'CHA', 'BST', 'XAS'],
}

class Dashboard:
    """
    Placeholder Dashboard class.
    Main.py will overwrite this class with its own header logic via assimilation.
    """
    @staticmethod
    def header():
        print("\033c", end="")
        console.print(Panel(
            Align.center(f"[bold {C_PRIM}]VALHALLA FUS[/] [dim]v2.0[/]\n[dim]Samsung Firmware Downloader[/]"),
            border_style=C_DIM, box=box.ROUNDED
        ))

class FusEngine:
    NONCE_KEY = "vicopx7dqu06emacgpnpy8j8zwhduwlh"
    AUTH_KEY = "9u7qab84rpc16gvk"
    
    @staticmethod
    def _xml_text(root, path):
        n = root.find(path)
        return (n.text or "").strip() if n is not None and n.text else None
        
    @staticmethod
    def decryptnonce(encrypted_nonce):
        cipher = AES.new(key=FusEngine.NONCE_KEY.encode(), mode=AES.MODE_CBC, iv=FusEngine.NONCE_KEY.encode()[:16])
        decrypted_nonce = unpad(cipher.decrypt(base64.b64decode(encrypted_nonce)), AES.block_size)
        sigkey = "".join(map(lambda i: FusEngine.NONCE_KEY[decrypted_nonce[i] % 16], range(16))) + FusEngine.AUTH_KEY
        cipher = AES.new(key=sigkey.encode(), mode=AES.MODE_CBC, iv=sigkey.encode()[:16])
        signature = cipher.encrypt(pad(decrypted_nonce, AES.block_size))
        return decrypted_nonce.decode(), base64.b64encode(signature).decode()

    @staticmethod
    def logiccheck(input_str, checkvalue):
        return "".join([input_str[ord(x) & 0xF] for x in checkvalue])

    @staticmethod
    def get_auth_headers(nonce_override=None):
        session_id = ""
        if not nonce_override:
            try:
                session = requests.post("https://neofussvr.sslcs.cdngc.net/NF_DownloadGenerateNonce.do", 
                                       headers={"Authorization": 'FUS nonce="", signature="", nc="", type="", realm="", newauth="1"', 
                                                "User-Agent": "Kies2.0_FUS", "Accept": "application/xml"}, timeout=10)
                encrypted_nonce = session.headers["NONCE"]
                cookie = session.headers.get("Set-Cookie", "")
                if "JSESSIONID_SVR=" in cookie:
                    session_id = cookie.split("JSESSIONID_SVR=")[1].split(";")[0]
            except Exception as e:
                return None, None, None
        else:
            encrypted_nonce = nonce_override
            
        decrypted_nonce, signature = FusEngine.decryptnonce(encrypted_nonce)
        
        headers = {
            "User-Agent": "Kies2.0_FUS",
            "Authorization": f'FUS nonce="{str(encrypted_nonce)}", signature="{signature}", nc="", type="", realm="", newauth="1"',
            "Cookie": f"JSESSIONID_SVR={session_id}",
            "Accept": "application/xml",
            "Content-Type": "application/xml"
        }
        return headers, encrypted_nonce, session_id

    @staticmethod
    def get_firmware_info(model, region):
        try:
            url = f"https://fota-cloud-dn.ospserver.net/firmware/{region}/{model}/version.xml"
            r = requests.get(url, headers={"User-Agent": "Kies2.0_FUS"}, timeout=10)
            if r.status_code != 200: return []
            
            tree = ET.fromstring(r.text)
            fw_list = []
            latest = tree.find(".//latest")
            if latest is not None and latest.text:
                fw_list.append({'version': latest.text.strip(), 'size': 0, 'type': 'LATEST', 'region': region})
            for upg in tree.findall(".//upgrade/value"):
                fw_list.append({
                    'version': upg.text.strip(),
                    'size': int(upg.get('fwsize', 0)),
                    'type': 'ROLLBACK',
                    'region': region
                })
            return fw_list
        except: return []

    @staticmethod
    def check_binary_exists(model, region, manual_version):
        headers, enc, sess = FusEngine.get_auth_headers()
        if not headers: return False
        
        xml = f"""<FUSMsg><FUSHdr><ProtoVer>1.0</ProtoVer></FUSHdr><FUSBody><Put>
        <ACCESS_MODE><Data>5</Data></ACCESS_MODE>
        <BINARY_NATURE><Data>1</Data></BINARY_NATURE>
        <CLIENT_PRODUCT><Data>Smart Switch</Data></CLIENT_PRODUCT>
        <CLIENT_VERSION><Data>5.0.0.0</Data></CLIENT_VERSION>
        <DEVICE_FW_VERSION><Data>{manual_version}</Data></DEVICE_FW_VERSION>
        <DEVICE_LOCAL_CODE><Data>{region}</Data></DEVICE_LOCAL_CODE>
        <DEVICE_AID_CODE><Data>OSW</Data></DEVICE_AID_CODE>
        <DEVICE_CC_CODE><Data>DE</Data></DEVICE_CC_CODE>
        <DEVICE_MODEL_NAME><Data>{model}</Data></DEVICE_MODEL_NAME>
        <LOGIC_CHECK><Data>................</Data></LOGIC_CHECK>
        <DEVICE_INITIALIZE><Data>2</Data></DEVICE_INITIALIZE>
        </Put></FUSBody></FUSMsg>"""
        try:
            r = requests.post("https://neofussvr.sslcs.cdngc.net/NF_DownloadBinaryInform.do", data=xml, headers=headers, timeout=5)
            return "<Status>200</Status>" in r.text
        except: return False

class FusController:
    def main_menu(self):
        while True:
            # Main.py will overwrite this Header call with the themed one
            Dashboard.header()
            choice = inquirer.select(
                message="ODIN PROTOCOL:",
                choices=[
                    Choice("scan", "ᛋ  Scan & Download"),
                    Choice("manual", "ᛒ  Manual Input (Force)"),
                    Choice("back", "ᛇ  Return to Hub")
                ],
                style=MENU_STYLE
            ).execute()
            
            if choice == "back": break
            elif choice == "scan": self.scan_ui()
            elif choice == "manual": self.manual_ui()
            
    def scan_ui(self):
        Dashboard.header()
        model = inquirer.text(message="Model [b to back]:", style=MENU_STYLE).execute().strip().upper()
        if model in ["B", "BACK", ""]: return
        if not model.startswith("SM-"): model = f"SM-{model}"
        
        region = inquirer.text(message="Region/Group [b to back]:", style=MENU_STYLE).execute().strip().upper()
        if region in ["B", "BACK", ""]: return
        
        target_regions = [region]
        if region in MULTI_CSC_GROUPS:
            target_regions = MULTI_CSC_GROUPS[region]
            console.print(f"[bold {C_ACC}]>> Multi-CSC Detected ({region}): Scanning {len(target_regions)} regions...[/]")
        
        found_fw = {}
        
        # [FIX] Fixed bar_width to 30 to prevent wrapping on mobile
        with Progress(
            SpinnerColumn(style=f"bold {C_ACC}"),
            TextColumn(f"[bold {C_PRIM}]{{task.description}}"),
            BarColumn(bar_width=30, complete_style=f"bold {C_PRIM}", finished_style=f"bold {C_OK}"),
            console=console
        ) as p:
            task = p.add_task("Scanning...", total=len(target_regions))
            with concurrent.futures.ThreadPoolExecutor(max_workers=16) as exe:
                futs = {exe.submit(FusEngine.get_firmware_info, model, r): r for r in target_regions}
                for f in concurrent.futures.as_completed(futs):
                    reg = futs[f]
                    p.advance(task)
                    res = f.result()
                    if res:
                        for fw in res:
                            v = fw['version']
                            if v not in found_fw:
                                found_fw[v] = fw
                                found_fw[v]['regions'] = [reg]
                            else:
                                if reg not in found_fw[v]['regions']:
                                    found_fw[v]['regions'].append(reg)
                                    
        if not found_fw:
            console.print(f"[{C_ERR}]No firmware found.[/]"); time.sleep(1); return
            
        choices = []
        for v, data in found_fw.items():
            r_list = data['regions']
            r_str = f"{r_list[0]}"
            if len(r_list) > 1: r_str += f" (+{len(r_list)-1})"
            choices.append(Choice(value=data, name=f"{v} | {r_str}"))
            
        choices.append(Choice("back", "Back"))
        sel = inquirer.select(message="Select Firmware:", choices=choices, style=MENU_STYLE).execute()
        if sel == "back": return
        dl_region = sel['regions'][0]
        self.download_sequence(model, dl_region, sel['version'])

    def manual_ui(self):
        Dashboard.header()
        model = inquirer.text(message="Model [b to back]:", style=MENU_STYLE).execute().strip().upper()
        if model in ["B", "BACK", ""]: return
        if not model.startswith("SM-"): model = f"SM-{model}"
        
        ver = inquirer.text(message="Version String [b to back]:", style=MENU_STYLE).execute().strip().upper()
        if ver in ["B", "BACK", ""]: return
        
        reg = inquirer.text(message="Region [b to back]:", style=MENU_STYLE).execute().strip().upper()
        if reg in ["B", "BACK", ""]: return
        
        console.print(f"[{C_DIM}]Verifying existence on server...[/]")
        if FusEngine.check_binary_exists(model, reg, ver):
            console.print(f"[{C_OK}]Binary Found![/]")
            self.download_sequence(model, reg, ver)
        else:
            console.print(f"[{C_ERR}]Server rejected this configuration.[/]")
            time.sleep(2)

    def download_sequence(self, model, region, version_str):
        headers, enc, sess = FusEngine.get_auth_headers()
        xml = f"""<FUSMsg><FUSHdr><ProtoVer>1.0</ProtoVer></FUSHdr><FUSBody><Put>
        <ACCESS_MODE><Data>5</Data></ACCESS_MODE>
        <BINARY_NATURE><Data>1</Data></BINARY_NATURE>
        <CLIENT_PRODUCT><Data>Smart Switch</Data></CLIENT_PRODUCT>
        <CLIENT_VERSION><Data>5.0.0.0</Data></CLIENT_VERSION>
        <DEVICE_FW_VERSION><Data>{version_str}</Data></DEVICE_FW_VERSION>
        <DEVICE_LOCAL_CODE><Data>{region}</Data></DEVICE_LOCAL_CODE>
        <DEVICE_AID_CODE><Data>OSW</Data></DEVICE_AID_CODE>
        <DEVICE_CC_CODE><Data>DE</Data></DEVICE_CC_CODE>
        <DEVICE_MODEL_NAME><Data>{model}</Data></DEVICE_MODEL_NAME>
        <LOGIC_CHECK><Data>................</Data></LOGIC_CHECK>
        <DEVICE_INITIALIZE><Data>2</Data></DEVICE_INITIALIZE>
        </Put></FUSBody></FUSMsg>"""
        
        info_headers = headers.copy()
        try:
            r = requests.post(
                "https://neofussvr.sslcs.cdngc.net/NF_DownloadBinaryInform.do",
                data=xml,
                headers=info_headers,
                timeout=15
            )

            # Parse XML safely
            tree = ET.fromstring(r.text)

            status = FusEngine._xml_text(tree, ".//Status")
            if status != "200":
                raise Exception(f"Status != 200 ({status})")

            filename = (
                FusEngine._xml_text(tree, ".//BINARY_NAME/Data")
                or FusEngine._xml_text(tree, ".//BINARY_NAME")
            )
            path = (
                FusEngine._xml_text(tree, ".//MODEL_PATH/Data")
                or FusEngine._xml_text(tree, ".//MODEL_PATH")
                or FusEngine._xml_text(tree, ".//BINARY_PATH/Data")
                or FusEngine._xml_text(tree, ".//BINARY_PATH")
                or FusEngine._xml_text(tree, ".//FILE_PATH/Data")
                or FusEngine._xml_text(tree, ".//FILE_PATH")
            )
            logic_val = (
                FusEngine._xml_text(tree, ".//LOGIC_VALUE_FACTORY/Data")
                or FusEngine._xml_text(tree, ".//LOGIC_VALUE_FACTORY")
            )
            srv_ver = (
                FusEngine._xml_text(tree, ".//LATEST_FW_VERSION/Data")
                or FusEngine._xml_text(tree, ".//LATEST_FW_VERSION")
            )

            enc_nonce_resp = r.headers.get("NONCE")

            # HARD GUARDS (prevents your None.split crash)
            if not filename:
                raise Exception("Missing BINARY_NAME in response")
            if not path:
                raise Exception("Missing MODEL_PATH/BINARY_PATH in response")
            if not logic_val:
                raise Exception("Missing LOGIC_VALUE_FACTORY in response")
            if not srv_ver:
                raise Exception("Missing LATEST_FW_VERSION in response")
            if not enc_nonce_resp:
                raise Exception("Missing NONCE header in response")

        except Exception as e:
            console.print(f"[{C_ERR}]Failed to fetch info: {e}[/]")
        
            # Show short server snippet for debugging
            try:
                console.print(f"[{C_DIM}]Server reply (head): {r.text[:350]}[/]")
            except:
                pass
        
            console.print(f"[{C_DIM}]Press Enter to continue...[/]")
            try:
                input()
            except:
                pass
            return
        try:
            pda_part = srv_ver.split('/')[0]
            short_ver = pda_part[-5:] 
        except: short_ver = "UNKNOWN"
        nice_name = f"{model}_{region}_ODIN_{short_ver}.zip"
        
        console.print(f"\n[bold {C_ACC}]TARGET ACQUIRED[/]")
        console.print(f"File: {nice_name}")
        console.print(f"Real: {filename}")
        
        if not inquirer.confirm("Start Download?", default=True, style=MENU_STYLE).execute(): return
        
        dec_nonce, sig = FusEngine.decryptnonce(enc_nonce_resp)
        logic_check = FusEngine.logiccheck(filename.split('.')[0][-16:], dec_nonce)
        init_xml = f"<FUSMsg><FUSHdr><ProtoVer>1.0</ProtoVer></FUSHdr><FUSBody><Put><BINARY_FILE_NAME><Data>{filename}</Data></BINARY_FILE_NAME><LOGIC_CHECK><Data>{logic_check}</Data></LOGIC_CHECK></Put></FUSBody></FUSMsg>"
        init_headers = {"User-Agent": "Kies2.0_FUS", "Authorization": f'FUS nonce="{enc_nonce_resp}", signature="{sig}", nc="", type="", realm="", newauth="1"', "Cookie": f"JSESSIONID_SVR={sess}", "Content-Type": "application/xml"}
        r_init = requests.post("https://neofussvr.sslcs.cdngc.net/NF_DownloadBinaryInitForMass.do", data=init_xml, headers=init_headers)
        final_nonce = r_init.headers["NONCE"]
        f_dec_nonce, f_sig = FusEngine.decryptnonce(final_nonce)
        dl_headers = {"User-Agent": "Kies2.0_FUS", "Authorization": f'FUS nonce="{final_nonce}", signature="{f_sig}", nc="", type="", realm="", newauth="1"', "Cookie": f"JSESSIONID_SVR={sess}"}
        dl_url = f"http://cloud-neofussvr.samsungmobile.com/NF_DownloadBinaryForMass.do?file={path}{filename}"
        
        save_dir = "Downloads/ODIN"
        os.makedirs(save_dir, exist_ok=True)
        final_path = os.path.join(save_dir, nice_name)
        key = hashlib.md5(FusEngine.logiccheck(srv_ver, logic_val).encode()).digest()
        cipher = AES.new(key, AES.MODE_ECB)
        
        console.print(f"[bold {C_PRIM}]ᚹ INITIATING DOWNLINK PROTOCOL...[/]")
        has_aria2 = shutil.which("aria2c") is not None
        
        if has_aria2:
            temp_enc_path = final_path + ".enc"
            console.print(f"[{C_ACC}]Turbo Mode (Aria2) Active. Downloading Encrypted Stream...[/]")
            
            cmd = [
                "aria2c", "-x16", "-s16", "-j16", "-k1M",
                "--file-allocation=none", "--summary-interval=1",
                "--console-log-level=warn",
                f"--header=User-Agent: Kies2.0_FUS",
                f"--header=Authorization: {dl_headers['Authorization']}",
                f"--header=Cookie: {dl_headers['Cookie']}",
                "-d", save_dir,
                "-o", os.path.basename(temp_enc_path),
                dl_url
            ]
            
            try:
                # [VALHALLA THEME] Aria2 Progress Bar
                with Progress(
                    TextColumn(f"  [dim]└─[/] [{C_DIM}][[/]"), 
                    BarColumn(bar_width=40, complete_style=f"bold {C_PRIM}", finished_style=f"bold {C_OK}"),
                    TextColumn(f"[{C_DIM}]][/]"),
                    TextColumn(f"[bold {C_PRIM}]{{task.percentage:>3.0f}}%[/]"),
                    TextColumn(f"[{C_DIM}]•[/]"),
                    # Note: No 'style' arg to prevent crash on older rich versions
                    TextColumn(f"[{C_DIM}]{{task.fields[speed]}}[/]"), 
                    console=console
                ) as p:
                    task = p.add_task("dl", total=100, speed="Init..")
                    process = subprocess.Popen(cmd, stdout=subprocess.PIPE, stderr=subprocess.STDOUT, text=True, bufsize=1, universal_newlines=True)
                    
                    for line in process.stdout:
                        if "DL:" in line:
                            try:
                                pct_match = re.search(r"\((\d+)%\)", line)
                                if pct_match: p.update(task, completed=int(pct_match.group(1)))
                                spd_match = re.search(r"DL:(\S+)", line)
                                if spd_match: p.update(task, speed=spd_match.group(1))
                            except: pass
                    
                    process.wait()
                    if process.returncode != 0: raise Exception(f"Aria2c code {process.returncode}")

                # [VALHALLA THEME] Decrypt Progress Bar
                console.print(f"[{C_PRIM}]Decrypting Payload...[/]")
                file_size = os.path.getsize(temp_enc_path)
                with open(temp_enc_path, 'rb') as inf, open(final_path, 'wb') as outf, Progress(
                    TextColumn(f"  [dim]└─[/] [{C_DIM}][[/]"), 
                    BarColumn(bar_width=40, complete_style=f"bold {C_PRIM}", finished_style=f"bold {C_OK}"),
                    TextColumn(f"[{C_DIM}]][/]"),
                    TextColumn(f"[bold {C_PRIM}]{{task.percentage:>3.0f}}%[/]"),
                    console=console
                ) as p:
                    task = p.add_task("dec", total=file_size)
                    while True:
                        chunk = inf.read(65536)
                        if not chunk: break
                        outf.write(cipher.decrypt(chunk))
                        p.update(task, advance=len(chunk))
                os.remove(temp_enc_path)
                console.print(f"\n[{C_OK}]Download Complete: {final_path}[/]")
                
            except Exception as e:
                console.print(f"[{C_ERR}]Aria2 Failed: {e}. Falling back to Stream...[/]")
                has_aria2 = False
        
        if not has_aria2:
            try:
                with requests.get(dl_url, headers=dl_headers, stream=True) as req:
                    total = int(req.headers.get('content-length', 0))
                    # [VALHALLA THEME] Standard Progress Bar
                    with open(final_path, 'wb') as f, Progress(
                        TextColumn(f"  [dim]└─[/] [{C_DIM}][[/]"), 
                        BarColumn(bar_width=40, complete_style=f"bold {C_PRIM}", finished_style=f"bold {C_OK}"),
                        TextColumn(f"[{C_DIM}]][/]"),
                        TextColumn(f"[bold {C_PRIM}]{{task.percentage:>3.0f}}%[/]"),
                        TextColumn(f"[{C_DIM}]•[/]"),
                        TransferSpeedColumn(), # No style arg to stay safe
                        TimeRemainingColumn(),
                        console=console
                    ) as p:
                        t = p.add_task("dl", total=total)
                        for chunk in req.iter_content(chunk_size=65536):
                            if chunk:
                                decrypted = cipher.decrypt(chunk)
                                f.write(decrypted)
                                p.update(t, advance=len(chunk))
                console.print(f"\n[{C_OK}]Download Complete: {final_path}[/]")
            except Exception as e:
                console.print(f"[{C_ERR}]Download Failed: {e}[/]")
                if os.path.exists(final_path): os.remove(final_path)
        time.sleep(2)
