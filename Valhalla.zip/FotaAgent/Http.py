"""
HTTP helpers for Samsung OSP/FOTA endpoints.

Improvements:
- Centralized request behavior (timeouts, TLS verify handling, consistent errors)
- Legacy SSL adapter retained for older endpoints
- No silent hangs: every request has a timeout
"""

from __future__ import annotations

import ssl
import logging
import xml.etree.ElementTree as ET

import requests
import urllib3

from FotaAgent.OAuthUtils import generate_oauth_header

log = logging.getLogger(__name__)

# Many OSP endpoints use legacy TLS/SSL setups.
urllib3.disable_warnings(urllib3.exceptions.InsecureRequestWarning)


class LegacySSLAdapter(requests.adapters.HTTPAdapter):
    """Requests adapter that enables OP_LEGACY_SERVER_CONNECT."""

    def init_poolmanager(self, *args, **kwargs):
        context = ssl.create_default_context()
        context.check_hostname = False
        context.options |= ssl.OP_LEGACY_SERVER_CONNECT
        kwargs["ssl_context"] = context
        return super().init_poolmanager(*args, **kwargs)


session = requests.Session()
session.mount("https://", LegacySSLAdapter())

# Central defaults (tune if you want)
DEFAULT_TIMEOUT = (5, 10)  # (connect_timeout, read_timeout)
VERIFY_TLS = False  # OSP endpoints can fail with strict verification


def _request(method: str, url: str, raise_for_status: bool = False, **kwargs) -> requests.Response:
    """
    Perform a request with consistent defaults.
    NOTE: For OSP/SSO flows, non-2xx responses are meaningful (SSO_8003, FUD_3062, etc),
    so we DO NOT raise_for_status by default.
    """
    kwargs.setdefault("timeout", DEFAULT_TIMEOUT)
    kwargs.setdefault("verify", VERIFY_TLS)

    try:
        resp = session.request(method=method, url=url, **kwargs)
        if raise_for_status:
            resp.raise_for_status()
        return resp
    except requests.exceptions.RequestException as e:
        msg = f"{method.upper()} {url} failed: {e}"
        raise RuntimeError(msg) from e

def register_device(client):
    """Register a device with OSP."""
    url = "https://www.ospserver.net/device/fumo/device/"
    consumer_key = "dz7680f4t7"
    consumer_secret = "4BE4F2C346C6F8831A480E14FD4DE276"
    method = "POST"

    request_xml = (
        "<?xml version='1.0' encoding='UTF-8' standalone='yes' ?>"
        f"<FumoDeviceVO>"
        f"<deviceTypeCode>PHONE DEVICE</deviceTypeCode>"
        f"<deviceModelID>{client.Model}</deviceModelID>"
        f"<deviceName>{client.Model}</deviceName>"
        f"<deviceUniqueID>{client.DeviceId}</deviceUniqueID>"
        f"<devicePhysicalAddressText>{client.DeviceId}</devicePhysicalAddressText>"
        f"<customerCode>{client.CustomerCode}</customerCode>"
        f"<uniqueNumber></uniqueNumber>"
        f"<deviceSerialNumber>{client.SerialNumber}</deviceSerialNumber>"
        f"<firmwareVersion>{client.FirmwareVersion}</firmwareVersion>"
        f"<mobileCountryCode>{client.Mcc}</mobileCountryCode>"
        f"<mobileNetworkCode>{client.Mnc}</mobileNetworkCode>"
        f"<mobileCountryCodeByTelephony>{client.Mcc}</mobileCountryCodeByTelephony>"
        f"<mobileNetworkCodeByTelephony>{client.Mnc}</mobileNetworkCodeByTelephony>"
        f"<phoneNumberText></phoneNumberText>"
        f"<initialBootingDate></initialBootingDate>"
        f"<terms>Y</terms>"
        f"<termsVersion></termsVersion>"
        f"<fotaClientVer>{client.FotaClientVersion}</fotaClientVer>"
        f"</FumoDeviceVO>"
    )

    auth_header = generate_oauth_header(
        consumer_key, consumer_secret, method, url, request_xml
    )

    headers = {
        "User-Agent": "SAMSUNG-Android",
        "Authorization": auth_header,
        "Accept-Encoding": "identity",
        "Accept": "*/*",
        "Connection": "close",
        "x-osp-version": "v1",
        "Content-Type": "application/xml",
    }

    try:
        resp = _request("POST", url, data=request_xml, headers=headers, raise_for_status=False)
        return resp.status_code, resp.text, auth_header
    except Exception as e:
        # Keep signature stable for callers.
        log.warning("register_device failed: %s", e)
        return 0, str(e), auth_header


# Inside FotaAgent/Http.py
# FotaAgent/Http.py

def send_wbxml(url: str, wbxml: bytes, device_model: str) -> bytes:
    """Send WBXML payload and print readable debug info to terminal."""
    headers = {
        "User-Agent": f"Samsung {device_model} SyncML_DM Client",
        "Accept": "application/vnd.syncml.dm+wbxml",
        "Content-Type": "application/vnd.syncml.dm+wbxml",
    }

    # Standard request using the legacy session
    resp = _request("POST", url, data=wbxml, headers=headers, raise_for_status=True)
    
   
    
    
    return resp.content



def parse_descripter(url: str, sourceFwV: str):
    """Parse OMA DD descriptor and extract fields used by the bot."""
    try:
        resp = _request("GET", url, raise_for_status=True)
        xml_data = resp.text

        root = ET.fromstring(xml_data)
        ns = "{http://www.openmobilealliance.org/xmlns/dd}"

        objectURI = root.findtext(f".//{ns}objectURI") or ""
        installParam = root.findtext(f".//{ns}installParam") or ""
        desc_txt = root.findtext(f".//{ns}description")

        # installParam is a semi-colon delimited key=value list.
        param_dict = {}
        for item in installParam.split(";"):
            if "=" in item:
                k, v = item.split("=", 1)
                param_dict[k] = v
                

        return {
            "sourceFwV": sourceFwV,
            "updateFwV": param_dict.get("updateFwV"),
            "securityPatchVersion": param_dict.get("securityPatchVersion"),
            "updateOneUiVersion": param_dict.get("updateOneUiVersion"),
            "android_ver": param_dict.get("updateFwOsV"),
			"objectURI": objectURI if objectURI else None,
            "changelog": desc_txt,
        }
    except Exception as e:
        log.debug("Error parsing descriptor: %s", e)
        return None