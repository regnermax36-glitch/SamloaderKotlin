"""
OAuth helper utilities used for OSP registration.

Improvements:
- Stable header ordering
- Proper quoting of OAuth header values
- More predictable parameter normalization
"""

from __future__ import annotations

import base64
import time
import urllib
import secrets
import math
import hmac
import hashlib


def generate_random_token(length: int) -> str:
    """Generate an uppercase hex nonce with the requested character length."""
    byte_count = math.ceil(length / 2)
    random_bytes = secrets.token_bytes(byte_count)
    return random_bytes.hex().upper()[:length]


def make_timestamp() -> int:
    # Keep ms timestamp to match existing server expectations in this project.
    return int(time.time() * 1000)


def generate_oauth_header(
    app_id: str,
    app_secret: str,
    request_method: str,
    request_uri: str,
    request_body: str,
    timestamp: int | None = None,
) -> str:
    if timestamp is None:
        timestamp = make_timestamp()

    oauth: dict[str, str] = {
        "oauth_consumer_key": app_id,
        "oauth_nonce": generate_random_token(10),
        "oauth_signature_method": "HmacSHA1",
        "oauth_timestamp": str(timestamp),
        "oauth_version": "1.0",
    }

    oauth["oauth_signature"] = generate_signature(
        app_secret, request_method, request_uri, request_body, oauth
    )

    # Stable order + quoted values
    return ", ".join(f'{k}="{v}"' for k, v in sorted(oauth.items()))


def generate_signature(
    app_secret: str,
    request_method: str,
    request_uri: str,
    request_body: str,
    oauth: dict[str, str],
) -> str:
    parts = [
        request_method.upper(),
        normalize_url_with_oauth_spec(request_uri),
        normalize_parameters(oauth),
    ]

    if request_body:
        parts.append(request_body)

    signed = compute_signature(app_secret, "&".join(parts))
    return base64.b64encode(signed).decode("utf-8")


def compute_signature(app_secret: str, str2: str) -> bytes:
    return hmac.new(app_secret.encode("utf-8"), str2.encode("ascii"), hashlib.sha1).digest()


def normalize_url_with_oauth_spec(url: str) -> str:
    parsed = urllib.parse.urlparse(url)
    scheme = (parsed.scheme or "").lower()
    authority = parsed.hostname.lower() if parsed.hostname else ""
    port = parsed.port

    if (scheme == "http" and port == 80) or (scheme == "https" and port == 443):
        pass
    elif port:
        authority += f":{port}"

    path = parsed.path or "/"
    query = parsed.query
    path_and_query = path + ("?" + query if query else "")

    return url_encode_with_oauth_spec(f"{scheme}://{authority}{path_and_query}")


def normalize_parameters(params: dict[str, str]) -> str:
    buffer = []
    for key in sorted(params.keys()):
        value = params[key]
        clean_value = value.replace('"', "").replace("&quot;", "")
        buffer.append(f"{key}={clean_value}")
    return url_encode_with_oauth_spec("&".join(buffer))


def url_encode_with_oauth_spec(s: str) -> str:
    encoded = urllib.parse.quote(s, safe="")
    return encoded.replace("+", "%20").replace("*", "%2A").replace("%7E", "~").replace("%25", "%")