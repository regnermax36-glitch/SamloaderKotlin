#!/usr/bin/env python3
"""
MIMIR DECRYPTER (Valhalla Module)
- Features: Families Batch, Ecosystem Scanning, Strict Region Saving.
- Visuals: Dynamic Progress Bar, Clean Top-N Summary.
- Config: Adjustable Telegram Report Limit (Default: 1).
"""

import os
import json
import hashlib
import time
import random
import string
import sqlite3
import re
import csv
import sys
from collections import defaultdict
from datetime import datetime

import requests
from lxml import etree

try:
    from rich.console import Console
    from rich.panel import Panel
    from rich.table import Table
    from rich.text import Text

    from rich.align import Align
    from rich.box import SIMPLE_HEAD, ROUNDED, HEAVY
    from rich import box
    from rich.progress import Progress, SpinnerColumn, BarColumn, TextColumn, TimeElapsedColumn
    from InquirerPy import inquirer
    from InquirerPy.base.control import Choice
    from InquirerPy.separator import Separator
    from InquirerPy.utils import get_style
except ImportError:
    print("Missing dependencies. pip install rich InquirerPy lxml requests")
    sys.exit(1)

# ===============================
#     THEME & CONFIG
# ===============================

console = Console()

# --- Valhalla Theme (runtime from main.py / config) ---
from valhalla_themes import get_runtime_theme, build_menu_style, BANNERS
_TS = get_runtime_theme()
C_PRIM, C_SEC, C_ACC, C_ERR, C_OK, C_DIM, C_BORDER, C_TEXT = _TS.colors()
# Back-compat aliases
C_GOLD = C_PRIM
C_BLUE = C_ACC
C_RED  = C_ERR
C_GREEN= C_OK
# Some older UI bits referenced these names.
# "Steel" is used as a calm secondary text color in a few places.
C_STEEL = C_SEC
MENU_STYLE = build_menu_style(C_PRIM, C_SEC, C_ACC, C_DIM, C_ERR, C_TEXT, hide_qmark=True)
GLOBAL_BANNER = BANNERS.get(_TS.banner, BANNERS.get('TYR',''))

BASE_PATH = os.path.dirname(os.path.abspath(__file__))
DECRYPTED_DIR = os.path.join(BASE_PATH, "Decrypted")
DB_PATH = os.path.join(BASE_PATH, "database", "fumo_history.db")
CONFIG_FILE = os.path.join(BASE_PATH, "config.json")

def ensure_output_dir():
    if not os.path.exists(DECRYPTED_DIR):
        os.makedirs(DECRYPTED_DIR, exist_ok=True)
    return DECRYPTED_DIR

def normalize_model(model_raw):
    clean = model_raw.strip().upper()
    if clean.startswith("SM-"): return clean
    return f"SM-{clean}"

# ===============================
#     MULTI-CSC LOGIC
# ===============================
CSC_FAMILIES = {
    "OXM": ["EUX", "XXV", "INS", "THL", "SER", "DBT", "XEF", "ITV", "BTU", "XID", "PHN", "TUR", "SEK", "SKZ"],
    "OLM": ["XME", "XSP", "XTC", "GLB", "SMA", "SIN", "STH", "MM1", "LAO"],
    "OJM": ["KSA", "UAE", "TUR", "MID", "EGY", "AFR", "KEN", "TUN", "MRT"],
    "OYM": ["XAA", "DSA", "ACG", "LRA"],
    "OYN": ["TMB", "VZW", "ATT", "USC", "SPR", "BST", "XAS"],
    "OWO": ["TPA", "UPO", "COO", "ZTO", "BVO", "GTO", "ARO", "CHO"],
    "OXE": ["SER", "CAU", "SEK", "SKZ"]
}

def _get_csc_family_members(target_csc):
    target_csc = target_csc.upper()
    for fam, members in CSC_FAMILIES.items():
        if target_csc in members:
            siblings = [m for m in members if m != target_csc]
            return [target_csc] + siblings[:4]
    return [target_csc]

# ===============================
#     SMART DEVICE INTEL
# ===============================

class DeviceIntel:
    FAMILY_RANK = {
        "Galaxy Z Series (Gen 7)": 1, "Galaxy Z Series (Gen 6)": 2, "Galaxy Z Series (Gen 5)": 3,
        "Galaxy Z Series (Gen 4)": 4, "Galaxy Z Series (Gen 3)": 5, "Galaxy S26 Series": 10,
        "Galaxy S25 Series": 11, "Galaxy S24 Series": 12, "Galaxy S23 Series": 13,
        "Galaxy S22 Series": 14, "Galaxy S21 Series": 15, "Galaxy Tab S Series": 30,
        "Galaxy A Series": 50, "Galaxy M Series": 60, "Legacy/Other": 99
    }

    @staticmethod
    def identify(model_code, known_name=None):
        base = model_code.replace("SM-", "")
        if known_name and "Samsung" in known_name:
            known_name = known_name.replace("Samsung ", "").replace(" Galaxy", "Galaxy").strip()
            
        if base.startswith("F9"): 
            try: gen = int(base[2]) + 1
            except: gen = "?"
            if base.startswith("F96"): gen = 7
            return f"Galaxy Z Series (Gen {gen})", known_name or f"Galaxy Z Fold {gen}"
            
        if base.startswith("F7"):
            try: idx = int(base[2]); gen = idx + 2
            except: gen = "?"
            if base.startswith("F76"): gen = 7 
            return f"Galaxy Z Series (Gen {gen})", known_name or f"Galaxy Z Flip {gen}"

        if base.startswith("S94"): return "Galaxy S26 Series", known_name or "Galaxy S26"
        if base.startswith("S93"): return "Galaxy S25 Series", known_name or "Galaxy S25"
        if base.startswith("S92"): return "Galaxy S24 Series", known_name or "Galaxy S24"
        if base.startswith("S91"): return "Galaxy S23 Series", known_name or "Galaxy S23"
        if base.startswith("S90"): return "Galaxy S22 Series", known_name or "Galaxy S22"
        if base.startswith("G99"): return "Galaxy S21 Series", known_name or "Galaxy S21"
        if base.startswith("X"): return "Galaxy Tab S Series", known_name or f"Tab S {base}"
        if base.startswith("A"): return "Galaxy A Series", known_name or f"Galaxy A{base[1:3]}"
        if base.startswith("M"): return "Galaxy M Series", known_name or f"Galaxy M{base[1:3]}"
        
        return "Legacy/Other", known_name or f"Samsung {base}"

    @staticmethod
    def get_suffix(model_code):
        clean = model_code.replace("SM-", "")
        if len(clean) > 4: return clean[4:]
        return "Global"

# ===============================
#     UI & DASHBOARD
# ===============================

class UI:
    @staticmethod
    def header(title, subtitle=None):
        grid = Table.grid(expand=True)
        grid.add_column(justify="center", ratio=1)
        grid.add_row(Text(title.upper(), style=f"bold {C_GOLD}"))
        if subtitle: grid.add_row(Text(subtitle, style=C_STEEL))
        console.print(Panel(grid, style=f"{C_DIM}", box=HEAVY, padding=(0, 2)))

    @staticmethod
    def status(msg, color=C_STEEL):
        console.print(f"[{color}]➤ {msg}[/{color}]")

    @staticmethod
    def print_batch_summary(results):
        if not results: return
        table = Table(box=SIMPLE_HEAD, expand=True, show_edge=False)
        table.add_column("Model", style="bold white")
        table.add_column("Region", style=C_DIM)
        table.add_column("Firmware Version", style=C_GOLD)
        table.add_column("Date", style=C_BLUE, justify="right")

        # Sort and limit based on config, but batch report can show all if needed.
        sorted_results = sorted(results, key=lambda x: x['date'], reverse=True)
        for r in sorted_results:
            table.add_row(r['model'], r['csc'], r['version'], r['date'])
        
        console.print()
        console.print(Panel(table, title=f"[bold {C_GOLD}]BATCH REPORT[/]", border_style=C_DIM))

class Dashboard:
    @staticmethod
    def header():
        print("\033c", end=""); os.system('cls' if os.name == 'nt' else 'clear')
        logo = Text("""╔══════════════╗
║   ᛉ ᛟ ᚦ ᛋ    ║
║   V A L H    ║
║   A L L A    ║
╚══════════════╝""", style=f"bold {C_GOLD}")
        right = Table.grid(padding=(0, 1)); right.add_column(justify="left")
        right.add_row(Text("VALHALLA HUB", style="bold white"))
        right.add_row(Text("DECRYPTER MODULE", style=C_STEEL))
        right.add_row(Text(f"TIME  {datetime.now().strftime('%Y-%m-%d %H:%M:%S')}", style=C_DIM))
        top = Table.grid(expand=True); top.add_column(ratio=2); top.add_column(ratio=4)
        top.add_row(Align.left(logo), Align.left(right))
        console.print(Panel(top, border_style=C_DIM, box=box.ROUNDED, padding=(0, 1)))
        
        h_hits = 0
        try:
            conn = sqlite3.connect(DB_PATH); c = conn.cursor(); c.execute("SELECT COUNT(*) FROM firmware_hits")
            h_hits = c.fetchone()[0]; conn.close()
        except: pass
        tg_status = f"[bold {C_OK}]ONLINE ({TelegramService.REPORT_LIMIT})[/]" if TelegramService.ENABLED else f"[dim]OFFLINE[/]"
        stat_grid = Table.grid(expand=True); stat_grid.add_column(justify="center", ratio=1); stat_grid.add_column(justify="center", ratio=1)
        stat_grid.add_row(f"TELEGRAM: {tg_status}", f"DB RECORDS ᛞ: [bold {C_BLUE}]{h_hits}[/]")
        console.print(Panel(stat_grid, border_style=C_DIM, box=box.ROUNDED, padding=(0,0))); console.print()

# ===============================
#      TELEGRAM SERVICE
# ===============================

class TelegramService:
    ENABLED = False
    TOKEN = ""
    CHAT_ID = ""
    REPORT_LIMIT = 1 # Default Limit
    R = {"header": "ᚱ", "device": "ᛟ"}
    DEVICE_MAP = {} 

    @staticmethod
    def load_config():
        if os.path.exists(CONFIG_FILE):
            try:
                with open(CONFIG_FILE, "r") as f:
                    data = json.load(f)
                    tg = data.get("telegram", {})
                    TelegramService.TOKEN = tg.get("bot_token", "")
                    TelegramService.CHAT_ID = tg.get("chat_id", "")
                    if TelegramService.TOKEN and TelegramService.CHAT_ID: TelegramService.ENABLED = True
            except: pass

    @staticmethod
    def load_device_map():
        candidates = ["tacs.csv", "database/tacs.csv"]
        target_file = None
        for c in candidates:
            if os.path.exists(os.path.join(BASE_PATH, c)): target_file = os.path.join(BASE_PATH, c); break
        
        TelegramService.DEVICE_MAP = {
            "S928": "Galaxy S24 Ultra", "S926": "Galaxy S24+", "S921": "Galaxy S24",
            "S918": "Galaxy S23 Ultra", "S916": "Galaxy S23+", "S911": "Galaxy S23",
            "F946": "Galaxy Z Fold 5", "F731": "Galaxy Z Flip 5"
        }
        if target_file:
            try:
                with open(target_file, 'r', encoding='utf-8', errors='ignore') as f:
                    reader = csv.DictReader(f)
                    for row in reader:
                        t_model = row.get('Telstra Model Name', '')
                        o_name = row.get('Optus Model Name', '')
                        if t_model and o_name and 'SM-' in t_model:
                            match = re.search(r'SM-([A-Z0-9]+)', t_model)
                            if match: TelegramService.DEVICE_MAP[match.group(1)[:4]] = o_name.title().replace("Samsung ", "").strip().replace(" Galaxy", "Galaxy")
            except: pass

    @staticmethod
    def send_report(new_finds_map):
        if not TelegramService.ENABLED or not new_finds_map: return
        text = f"<b>{TelegramService.R['header']} NEW BUILDS DECRYPTED</b>\n"
        has_content = False
        limit = TelegramService.REPORT_LIMIT
        for key, versions in new_finds_map.items():
            if not versions: continue
            model_raw = key.split('(')[0].strip()
            nice_name = TelegramService.DEVICE_MAP.get(model_raw.replace("SM-","")[:4], model_raw)
            text += f"\n<b>{TelegramService.R['device']} {key} | {nice_name}</b>\n"
            for v in versions[:limit]: text += f"<code>{v}</code>\n"
            has_content = True
        if has_content and TelegramService.TOKEN and TelegramService.CHAT_ID:
            try: requests.post(f"https://api.telegram.org/bot{TelegramService.TOKEN}/sendMessage", data={"chat_id": TelegramService.CHAT_ID, "text": text, "parse_mode": "HTML"}, timeout=10)
            except: pass

TelegramService.load_config()
TelegramService.load_device_map()

# ===============================
#        FIRMWARE LOGIC
# ===============================

def request_xml(url):
    """Fetch server XML with retries and cleaner headers."""
    agents = [
        "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/122 Safari/537.36",
        "Mozilla/5.0 (Linux; Android 14; SAMSUNG) AppleWebKit/537.36 (KHTML, like Gecko) SamsungBrowser/24.0 Chrome/120 Safari/537.36",
    ]
    last_err = None
    for attempt in range(1, 4):
        try:
            r = requests.get(
                url,
                headers={"User-Agent": random.choice(agents), "Connection": "close"},
                timeout=12
            )
            if r.status_code == 200 and r.content:
                return r.content
            last_err = f"HTTP {r.status_code}"
        except Exception as e:
            last_err = str(e)
        try:
            time.sleep(0.5 * attempt)
        except Exception:
            pass
    try:
        console.print(f"[bold {C_ERR}]NETWORK ERROR[/]: {last_err}")
    except Exception:
        pass
    return None


def get_md5_list(model, cc):
    content = request_xml(f"https://fota-cloud-dn.ospserver.net/firmware/{cc}/{model}/version.test.xml")
    if not content:
        return []
    try:
        xml = etree.fromstring(content)
        return [x.strip() for x in xml.xpath("//value//text()") if x and x.strip()]
    except Exception:
        return []


def get_latest_version(model, cc):
    """Back-compat: return only latest string or None."""
    content = request_xml(f"https://fota-cloud-dn.ospserver.net/firmware/{cc}/{model}/version.xml")
    if not content:
        return None
    try:
        xml = etree.fromstring(content)
        latest = xml.xpath("//latest//text()")
        return latest[0] if latest else None
    except Exception:
        return None


def get_latest_info(model, cc):
    """Extended helper: return (latest, osver)."""
    content = request_xml(f"https://fota-cloud-dn.ospserver.net/firmware/{cc}/{model}/version.xml")
    if not content:
        return None, None
    try:
        xml = etree.fromstring(content)
        latest = xml.xpath("//latest//text()")
        if not latest:
            return None, None
        osv = xml.xpath("//latest/@o")
        return latest[0], (osv[0] if osv else None)
    except Exception:
        return None, None


def get_csc_fallbacks(primary_cc):
    primary_cc = primary_cc.upper()
    fallback = []

    # first try your local family map
    try:
        for _, members in CSC_FAMILIES.items():
            if primary_cc in members:
                for item in members:
                    if item not in fallback:
                        fallback.append(item)
    except Exception:
        pass

    # extra broad CSC blocks from DC3
    CSC_BLOCKS = {
        "OXM": ["ACR","AFG","AFR","BKD","BNG","BOG","CAC","CAU","CPW","DKR","ECT","EGY","EUX","EUY","FWD",
                "GLB","ILO","ILP","INS","KSA","LYS","MEO","MET","MID","MM1","MOB","MOT","MSR","MWD","NPB",
                "OPS","ANC","PAK","PKD","PLS","PRT","SER","SFR","SIM","SIN","SKZ","SLK","SOZ","STH","SWC","TEL",
                "THL","TOP","TUN","TUR","VAU","VIP","WWA","WWC","WWD","XFA","XFV","XME","XNZ","XSA","XSG",
                "XSP","XTC","XXV","XID","XFE","O2C","CHX","ZTR"],
        "ODM": ["BKD", "INS", "NPL", "SLK"],
        "OJM": ["ACR","AFG","AFR","DKR","ECT","EGY","FWD","ILO","ILP","KSA","LYS","MID","MWD","PAK","PKD","TUN","TUR","XFA","XFE","XFV","XSG"],
        "OLE": ["XID"],
        "OWO": ["BVO","BVT","CHE","CHL","CHO","CHT","CHX","GTO","NBS","ZTA","ZTM","ZTO","ZTR","ZVV"],
        "OXE": ["CAU","SEK","SKZ","SER"],
        "USA_U": ["ATT","VZW","TMB","CHA","CCT","DSA","DSG","GCF","XAA","USC"],
        "USA_U1": ["ATT","VZW","TMB","CHA","CCT","DSA","DSG","XAA","USC","XPO","FKR","XAG","XAR","WWD","TMK","AIO","LRA"],
    }

    for _, members in CSC_BLOCKS.items():
        if primary_cc in members:
            for item in members:
                if item not in fallback:
                    fallback.append(item)

    return [primary_cc] + [x for x in fallback if x != primary_cc] if fallback else [primary_cc]


def get_latest_with_fallback(model, primary_cc):
    for csc in get_csc_fallbacks(primary_cc):
        latest, osver = get_latest_info(model, csc)
        if latest:
            return latest, osver, csc
    return None, None, None


def classify_build(version, latest_version):
    pda = version.split("/")[0] if version else ""
    if latest_version and version == latest_version:
        return "stable-live"
    if len(pda) >= 4 and pda[-4] == "Z":
        return "beta"
    if len(pda) >= 3 and pda[-3] == "Z":
        return "beta"
    if "/" in version:
        cp = version.split("/")[-1]
        if cp and cp != pda:
            return "variant"
    return "stable"


def parse_date_from_version(version):
    try:
        pda = version.split("/")[0]
        y = ord(pda[-3]) - ord("A") + 2001
        m = ord(pda[-2]) - ord("A") + 1
        if 1 <= m <= 12:
            return y, m
    except Exception:
        pass
    return 0, 0
def get_next_char(ch):
    if not ch:
        return ch
    if ch == "9":
        return "A"
    if ch == "Z":
        return "Z"
    return chr(ord(ch) + 1)


def get_pre_char(ch):
    if not ch:
        return ch
    if ch == "A":
        return "A"
    if ch == "0":
        return "0"
    return chr(ord(ch) - 1)


def get_letters_range(start, end):
    if not start or not end:
        return ""
    if start.isdigit() and end.isdigit():
        return "".join(chr(c) for c in range(ord(start), ord(end) + 1))
    return "".join(chr(c) for c in range(ord(start), ord(end) + 1))

def derive_codes(model, cc, latest_version):
    cc = cc.upper()

    if latest_version:
        vp = latest_version.split("/")
        first_code = vp[0][:-6]
        second_code = vp[1][:-5]
        third_code = vp[2][:-6] if len(vp) > 2 else ""

        latest_year = vp[0][-3]
        start_year = chr(ord("A") + max(0, ord(latest_year) - ord("A") - 4))
        end_year = get_next_char(latest_year) if vp[0][-2] in "JKL" else latest_year
        start_bl = "0"
        end_bl = get_next_char(vp[0][-5])
        start_upd = "A"
        end_upd = get_next_char(vp[0][-4])
        return first_code, second_code, third_code, start_year, end_year, start_bl, end_bl, start_upd, end_upd

    model_code = model.replace("SM-", "")
    suffix = "U1" if model_code.endswith("U1") else model_code[-1]

    ap_tag, csc_tag, cp_tag = "XX", "OXM", "XX"

    if cc in ("CHC", "CHN"):
        ap_tag, csc_tag, cp_tag = "ZC", "CHC", ("" if cc == "CHN" else "ZC")
    elif cc == "TGY":
        ap_tag, csc_tag, cp_tag = "ZH", "OZS", "ZC"
    elif suffix == "U":
        ap_tag, csc_tag, cp_tag = "SQ", "OYN", "SQ"
    elif suffix == "U1":
        ap_tag, csc_tag, cp_tag = "UE", "OYM", "UE"
    elif suffix == "W":
        ap_tag, csc_tag, cp_tag = "VL", "OYV", "VL"
    elif suffix == "N":
        ap_tag, csc_tag, cp_tag = "NK", "OKR", "NK"
    elif suffix == "0":
        ap_tag = "ZH" if cc in ["TGY", "BRI"] else "ZC"
        csc_tag = cc
        cp_tag = ap_tag
    elif cc in ["EUX", "EUY"]:
        ap_tag, csc_tag, cp_tag = "XX", "OXM", "XX"
    elif cc in ["INS", "NPL", "SLK"]:
        ap_tag, csc_tag, cp_tag = "XX", "ODM", "XX"
    elif cc in ["CHX", "ZTR"]:
        ap_tag, csc_tag, cp_tag = "XX", "OWO", "XX"

    first_code = model_code + ap_tag
    second_code = model_code + csc_tag
    third_code = model_code + cp_tag if cp_tag else ""

    start_year = chr(max(ord("A"), datetime.now().year - 2001 + ord("A") - 3))
    end_year = get_next_char(get_next_char(start_year))
    start_bl = "0"
    end_bl = "9"
    start_upd = "A"
    end_upd = "Z"
    return first_code, second_code, third_code, start_year, end_year, start_bl, end_bl, start_upd, end_upd


def decrypt_firmware(model, cc, md5_list, latest_version, full_brute=True):
    md5_set = set(md5_list)
    if not md5_set:
        return {}

    first_code, second_code, third_code, start_year, end_year, start_bl, end_bl, start_upd, end_upd = derive_codes(model, cc, latest_version)

    years = get_letters_range(start_year, end_year)
    bls = get_letters_range(start_bl, end_bl)
    updates = get_letters_range(start_upd, end_upd)
    if "Z" not in updates:
        updates += "Z"

    cp_versions = []
    decrypted = {}
    seen_versions = set()

    total_steps = len("US") * len(bls) * len(updates) * len(years) * len("ABCDEFGHIJKL")

    def register(ver, md5, ych, mch):
        if md5 in md5_set and md5 not in decrypted and ver not in seen_versions:
            y = ord(ych) - ord("A") + 2001
            m = ord(mch) - ord("A") + 1
            decrypted[md5] = {
                "version": ver,
                "year": y,
                "month": m,
                "kind": classify_build(ver, latest_version),
            }
            seen_versions.add(ver)

    with Progress(
        SpinnerColumn(style=f"bold {C_ACC}"),
        TextColumn("[bold {task.fields[color]}]Decrypting..."),
        BarColumn(bar_width=40, complete_style=f"bold {C_PRIM}", finished_style=f"bold {C_OK}"),
        TextColumn("[{task.fields[color]}]{task.percentage:>3.0f}%"),
        console=console,
        transient=True
    ) as progress:
        task = progress.add_task("Decrypting", total=total_steps, color=C_PRIM)

        for flavor in "US":
            for bl in bls:
                for upd in updates:
                    for ych in years:
                        for mch in "ABCDEFGHIJKL":
                            progress.advance(task)

                            local_cp = cp_versions[-16:].copy()
                            if third_code:
                                for i in range(1, 4):
                                    seed = third_code + flavor + bl + upd + ych + mch + str(i)
                                    if seed not in local_cp:
                                        local_cp.append(seed)

                            for serial in "123456789ABCDEFGHIJKLMNOPQRSTUVWXYZ":
                                rnd = bl + upd + ych + mch + serial
                                beta_rnd = bl + "Z" + ych + mch + serial

                                tcode = "" if not third_code else third_code + flavor + rnd
                                btcode = "" if not third_code else third_code + flavor + beta_rnd

                                if third_code:
                                    for nearby in [serial, get_pre_char(serial), get_pre_char(get_pre_char(serial))]:
                                        cpv = third_code + flavor + bl + upd + ych + mch + nearby
                                        if cpv not in local_cp:
                                            local_cp.append(cpv)

                                normal_versions = [
                                    f"{first_code}{flavor}{rnd}/{second_code}{rnd}/{tcode}",
                                    f"{first_code}E{rnd}/{second_code}{rnd}/{tcode}",
                                    f"{first_code}{flavor}{beta_rnd}/{second_code}{beta_rnd}/{btcode}",
                                    f"{first_code}E{beta_rnd}/{second_code}{beta_rnd}/{btcode}",
                                ]

                                for ver in normal_versions:
                                    register(ver, hashlib.md5(ver.encode()).hexdigest(), ych, mch)

                                for cpv in local_cp:
                                    if cpv:
                                        ver2 = f"{first_code}{flavor}{rnd}/{second_code}{rnd}/{cpv}"
                                        ver2e = f"{first_code}E{rnd}/{second_code}{rnd}/{cpv}"
                                        ver4 = f"{first_code}{flavor}{beta_rnd}/{second_code}{beta_rnd}/{cpv}"
                                        ver4e = f"{first_code}E{beta_rnd}/{second_code}{beta_rnd}/{cpv}"
                                        register(ver2, hashlib.md5(ver2.encode()).hexdigest(), ych, mch)
                                        register(ver2e, hashlib.md5(ver2e.encode()).hexdigest(), ych, mch)
                                        register(ver4, hashlib.md5(ver4.encode()).hexdigest(), ych, mch)
                                        register(ver4e, hashlib.md5(ver4e.encode()).hexdigest(), ych, mch)

                                if tcode and tcode not in cp_versions and any(v.endswith("/" + tcode) for v in seen_versions):
                                    cp_versions.append(tcode)

                                if not full_brute and len(decrypted) == len(md5_set):
                                    return decrypted

    return decrypted
def load_existing_decrypted_map(model, cc):
    ensure_output_dir()
    path = os.path.join(DECRYPTED_DIR, f"{model}_{cc}_full.json")
    if not os.path.exists(path): return {}
    try:
        with open(path, "r", encoding="utf-8") as f: data = json.load(f)
    except: return {}
    out = {}
    for fw in data.get("firmwares", []):
        md5, ver = fw.get("md5"), fw.get("version")
        if not md5 or not ver: continue
        try: y, m = int(fw.get("date", "0-0").split("-")[0]), int(fw.get("date", "0-0").split("-")[1])
        except: y, m = 0, 0
        out[md5] = {"version": ver, "year": y, "month": m}
    return out

def save_outputs(model, cc, decrypted_map):
    items = sorted(decrypted_map.items(), key=lambda x: (x[1]["year"], x[1]["month"]), reverse=True)
    json_data = {"model": model, "region": cc, "generated_at": str(datetime.now()), "total_found": len(items), "firmwares": [{"version": info["version"], "md5": md5, "date": f"{info['year']}-{info['month']:02d}"} for md5, info in items]}
    with open(os.path.join(DECRYPTED_DIR, f"{model}_{cc}_full.json"), "w", encoding="utf-8") as f: json.dump(json_data, f, indent=4)

# ===============================
#      CORE LOGIC
# ===============================
def run_decrypter(model, cc, selection_mode=False, ecosystem_mode=None, suppress_tg=False, force=False):
    TelegramService.load_device_map()
    model = normalize_model(model)
    main_cc = cc.upper()

    import sys
    ChoiceClass = globals().get('Choice')
    if not ChoiceClass or ChoiceClass.__name__ != 'ValhallaChoice':
        if 'main' in sys.modules and hasattr(sys.modules['main'], 'ValhallaChoice'):
            ChoiceClass = sys.modules['main'].ValhallaChoice
        else:
            ChoiceClass = Choice

    InquirerClass = globals().get('inquirer')
    if 'main' in sys.modules and hasattr(sys.modules['main'], 'inquirer'):
        InquirerClass = sys.modules['main'].inquirer
    elif not InquirerClass:
        from InquirerPy import inquirer as InquirerClass

    StyleObj = globals().get('MENU_STYLE', MENU_STYLE)
    if 'main' in sys.modules and hasattr(sys.modules['main'], 'STYLE'):
        StyleObj = sys.modules['main'].STYLE

    if ecosystem_mode is None:
        console.print(f"\n[bold {C_GOLD}]:: SCAN CONFIGURATION ::[/]")
        ecosystem_mode = InquirerClass.confirm(
            message=f"Scan Full Ecosystem? (Check neighbors of {main_cc}?)",
            default=True,
            style=StyleObj
        ).execute()

    targets = [main_cc]
    if ecosystem_mode:
        targets = _get_csc_family_members(main_cc)

    header_txt = f"{main_cc} [Multi-CSC: {', '.join(targets[1:])}]" if len(targets) > 1 else main_cc
    if selection_mode:
        if 'UI' in globals():
            UI.header(f"DECRYPTING {model}", header_txt)
        else:
            console.print(f"[bold {C_GOLD}]>> Processing {model} ({header_txt})...[/]")
    else:
        console.print(f"[bold {C_GOLD}]>> Processing {model} ({header_txt})...[/]")

    session_new_finds = []

    for region in targets:
        console.print(f"   [bold {C_ACC}]>>[/] [{C_DIM}]Checking Region:[/] [bold white]{region}[/] [{C_DIM}]...[/]")

        md5s = get_md5_list(model, region)
        if not md5s:
            continue

        existing = load_existing_decrypted_map(model, region)

        if force:
            new_md5s = set(md5s)
        else:
            new_md5s = set(md5s) - set(existing.keys())

        if new_md5s:
            base, _, base_csc = get_latest_with_fallback(model, region)
            found = decrypt_firmware(model, region, new_md5s, base)

            if found:
                existing.update(found)
                save_outputs(model, region, existing)
                base_note = f" (base: {base_csc})" if base_csc and base_csc != region else ""
                console.print(f"      [bold {C_OK}]└─ Decrypted {len(found)} new builds in {region}{base_note}[/]")

                for v in found.values():
                    session_new_finds.append({
                        "csc": region,
                        "version": v['version'],
                        "year": v['year'],
                        "month": v['month']
                    })

    if session_new_finds:
        session_new_finds.sort(key=lambda x: (x['year'], x['month'], x['version']), reverse=True)
        limit = TelegramService.REPORT_LIMIT

        if selection_mode or len(session_new_finds) > 0:
            console.print(f"\n[bold {C_GOLD}]>>> DECRYPTION SUMMARY (Latest {limit} of {len(session_new_finds)})[/]")
            t = Table(box=box.ROUNDED, expand=True)
            t.add_column("Region", style="bold cyan")
            t.add_column("Firmware Version", style="bold white")
            t.add_column("Date", style=C_BLUE)
            for item in session_new_finds[:limit]:
                t.add_row(item['csc'], item['version'], f"{item['year']}-{item['month']:02d}")
            console.print(t)

            if not suppress_tg:
                notif_map = {}
                for item in session_new_finds:
                    k = f"{model} ({item['csc']})"
                    notif_map.setdefault(k, []).append(item['version'])
                TelegramService.send_report(notif_map)
    else:
        if selection_mode:
            console.print(f"[{C_OK}]✓ Up-to-Date (Checked {len(targets)} regions)[/]")

    if suppress_tg:
        return session_new_finds

    if selection_mode:
        aggregated_history = {}
        for region in targets:
            hist = load_existing_decrypted_map(model, region)
            for k, v in hist.items():
                ver = v['version']
                if ver not in aggregated_history:
                    v['display_csc'] = region
                    aggregated_history[ver] = v

        if not aggregated_history:
            console.print(f"\n[{C_DIM}]No history found for {model}.[/]")
            return None

        real_stable_ver = None
        try:
            raw_live = get_latest_version(model, main_cc)
            if raw_live:
                real_stable_ver = raw_live.split('/')[0].strip()
        except Exception:
            pass

        def build_sort_key(x):
            return (x.get('year', 0), x.get('month', 0), x.get('version', ''))

        all_sorted = sorted(aggregated_history.values(), key=build_sort_key, reverse=True)

        pinned_stable = []
        others = []
        for b in all_sorted:
            ver = b.get('version', '')
            if real_stable_ver and ver == real_stable_ver:
                pinned_stable.append(b)
            else:
                others.append(b)

        final_list = (pinned_stable + others)[:15]

        console.print(f"\n[{C_GOLD}]SELECT BASE FIRMWARE (LATEST 15):[/]")

        choices = []
        for b in final_list:
            ver = b.get('version', '')
            csc_label = b.get('display_csc', main_cc)
            dt = f"{b.get('year', 0)}-{b.get('month', 0):02d}"
            stable_tag = "  [LIVE]" if real_stable_ver and ver == real_stable_ver else ""
            name = f"{ver}  [{csc_label}]  {dt}{stable_tag}"

            choice_payload = {
                "version": ver,
                "csc": csc_label,
                "year": b.get("year", 0),
                "month": b.get("month", 0),
            }
            choices.append(ChoiceClass(value=choice_payload, name=name))

        choices.append(Separator())
        choices.append(ChoiceClass(value="back", name="Cancel / Go Back"))

        picked = InquirerClass.select(
            message="Choose base firmware:",
            choices=choices,
            style=StyleObj,
            instruction=""
        ).execute()

        return picked

    return session_new_finds
def get_grouped_entries():
    if not os.path.exists(DB_PATH): return {}
    conn = sqlite3.connect(DB_PATH); c = conn.cursor()
    c.execute("SELECT device_model, csc, found_pda FROM firmware_hits WHERE is_fumo=1 ORDER BY device_model")
    rows = c.fetchall(); conn.close()
    
    grouped = defaultdict(lambda: defaultdict(list))
    for r in rows:
        m, csc, pda = r[0], r[1], r[2]
        fam, name = DeviceIntel.identify(m)
        suffix = m[-1] if m[-1] in ['U','1','B','N','0','W'] else 'B'
        if m.endswith("U1"): suffix = "U1"
        exists = False
        for e in grouped[fam][suffix]:
            if e['model'] == m and e['csc'] == csc: exists = True; break
        if not exists:
            grouped[fam][suffix].append({"model": m, "csc": csc, "latest": pda, "nice_name": name})
    return grouped

def run_batch_ui():
    grouped = get_grouped_entries()
    if not grouped: UI.status("No entries found in database.", C_ERR); time.sleep(2); return

    step = 1; selected_fams = []
    while True:
        Dashboard.header()
        if step == 1:
            sorted_fams = sorted(grouped.keys(), key=lambda x: DeviceIntel.FAMILY_RANK.get(x, 99))
            fam_choices = [Choice("all", "SELECT ALL FAMILIES"), Separator(f"   {'-'*30}")] + [Choice(f, f) for f in sorted_fams] + [Choice("back", "Go Back")]
            console.print(f"\n[{C_GOLD}]STEP 1: SELECT FAMILIES[/{C_GOLD}]")
            sel = inquirer.checkbox(message="Families:", choices=fam_choices, style=MENU_STYLE, cycle=True, height="60%", instruction="(Space to Toggle)").execute()
            if "back" in sel or not sel: return
            selected_fams = list(grouped.keys()) if "all" in sel else sel
            step = 2
        elif step == 2:
            all_suffixes = set()
            for f in selected_fams:
                for s in grouped[f].keys(): all_suffixes.add(s)
            suffix_map = {"B": "International (B)", "U": "US Carrier (U)", "U1": "US Unlocked (U1)", "N": "Korea (N)", "0": "China/HK (0)", "W": "Canada (W)"}
            reg_choices = [Choice("all", "■  SELECT ALL REGIONS")] + [Choice(s, suffix_map.get(s, f"Variant {s}")) for s in sorted(list(all_suffixes))] + [Choice("back", "Go Back")]
            console.print(f"\n[{C_GOLD}]STEP 2: SELECT REGIONS[/{C_GOLD}]")
            sel = inquirer.checkbox(message="Regions:", choices=reg_choices, style=MENU_STYLE, cycle=True, height="50%", instruction="(Space to Toggle)").execute()
            if "back" in sel or not sel: step = 1; continue 

            target_entries = []
            for fam in selected_fams:
                for s, entries in grouped[fam].items():
                    if "all" in sel or s in sel: target_entries.extend(entries)

            if not target_entries: UI.status("No matching devices found.", C_ERR); time.sleep(2); step = 1; continue
            
            use_eco = inquirer.confirm(message=f"Enable Ecosystem (Multi-CSC) Scan for {len(target_entries)} items?", default=False).execute()
            console.print(f"\n[{C_OK}]Queueing {len(target_entries)} devices...[/{C_OK}]"); time.sleep(1)

            for e in target_entries:
                model_name = e['model']; nice_name = e.get('nice_name', model_name)
                run_decrypter(model_name, e['csc'], selection_mode=False, ecosystem_mode=use_eco)
            
            console.input(f"\n[{C_DIM}]Batch Complete. Press Enter to return...[/{C_DIM}]"); return

def main():
    while True:
        Dashboard.header()
        tg_state = "ON" if TelegramService.ENABLED else "OFF"
        limit_state = TelegramService.REPORT_LIMIT
        
        op = inquirer.select(message="MENU:", choices=[
            Choice("single", "Single Decrypt"),
            Choice("batch", "Batch Decrypt (Database)"),
            Choice("tg", f"Toggle Telegram [{tg_state}]"),
            Choice("limit", f"Set Telegram Limit [{limit_state}]"),
            Choice("quit", "Back to Hub"),
        ], style=MENU_STYLE).execute()
        
        if op == "single":
            while True:
                m = inquirer.text(message="Model [b to back]:", style=MENU_STYLE).execute().strip()
                if m.lower() in ['b', 'back', '']: break 
                c = inquirer.text(message="CSC [b to back]:", style=MENU_STYLE).execute().strip()
                if c.lower() in ['b', 'back', '']: continue 
                found = run_decrypter(m, c, selection_mode=True, ecosystem_mode=None)
                
                if found:
                    try:
                        import logistics_v150
                        controller = logistics_v150.LogisticsController()
                        batch = found if isinstance(found, list) else [found]
                
                        console.print(f"[bold {C_OK}]>> PROCESSING {len(batch)} BUILD(S)...[/]")
                
                        for item in batch:
                            if isinstance(item, dict) and item.get("version"):
                                controller.execute_scan_logic(
                                    m,
                                    [c],
                                    "base",
                                    queue_mode=False,
                                    manual_version=item["version"],
                                    custom_imeis=None,
                                    silent=False
                                )
                    except Exception as e:
                        console.print(f"[{C_ERR}]Standalone scan-ahead failed: {e}[/]")
                
                console.input(f"[{C_DIM}]Press Enter to continue...[/{C_DIM}]")
                break
        elif op == "batch":
            run_batch_ui()
            
        elif op == "tg":
            TelegramService.ENABLED = not TelegramService.ENABLED
            
        elif op == "limit":
            raw = inquirer.text(message="Enter Max Builds to Send (1-10):", default=str(limit_state), style=MENU_STYLE).execute()
            if raw.isdigit():
                TelegramService.REPORT_LIMIT = int(raw)
                UI.status(f"Limit set to {TelegramService.REPORT_LIMIT}", C_OK)
                time.sleep(1)
            
        elif op == "quit":
            break

if __name__ == "__main__":
    try:
        sys.stdout.write("\033[?1049h"); sys.stdout.flush()
        main()
    except KeyboardInterrupt: pass
    except Exception: sys.stdout.write("\033[?1049l"); sys.stdout.flush(); console.print_exception()
    finally: sys.stdout.write("\033[?1049l"); sys.stdout.flush()
