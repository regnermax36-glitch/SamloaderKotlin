"""Crypto utilities used by the FotaAgent.

Light improvements:
- Exceptions logged via logging instead of print
"""

from __future__ import annotations

import hashlib
import logging
from FotaAgent.Crypto.DesCrypt import DesCrypt

# --- Module-level Constants ---

DICT = [
    1, 15, 5, 11, 19, 28, 23, 47, 35, 44, 2, 14, 6, 10, 18, 13, 22, 26, 32, 47, 3, 13, 7, 9, 17, 30, 21, 25,
    33, 45, 4, 12, 8, 63, 16, 31, 20, 24, 34, 46
]
HEX_TABLE = ['0', '1', '2', '3', '4', '5', '6', '7', '8', '9', 'a', 'b', 'c', 'd', 'e', 'f']


def _adp_encode_hex(b_arr: bytes) -> list[str]:
    """Converts a byte array to a list of hexadecimal characters."""
    c_arr = [''] * (len(b_arr) * 2)
    i = 0
    for b in b_arr:
        i2 = i + 1
        # Low nibble
        c_arr[i] = HEX_TABLE[b & 15]
        # High nibble
        c_arr[i2] = HEX_TABLE[(b >> 4) & 15]
        i = i2 + 1
    return c_arr


def _adp_shuffle(var0: str) -> str:
    """Performs a specific shuffling algorithm on a string."""
    var1 = len(var0)
    var2 = var1 % 2
    var3 = var1 // 2
    if var2 != 0:
        var3 += 1

    char_list = list(var0)

    while var3 < var1:
        var4 = char_list.pop(var3)
        var5 = var1 - var3
        if var2 == 0:
            var5 -= 1

        char_list.insert(var5, var4)
        var3 += 1

    return "".join(char_list)


def generate_client_password(str_val: str, str2: str) -> str | None:
    """
    Generates a complex client password hash based on two input strings.
    Keeps original behavior (returns "" on unexpected errors).
    """
    try:
        try:
            substring = str_val.split(':', 1)[1]
        except IndexError:
            return None

        sub_length = len(substring)
        if sub_length == 0:
            return None

        c_arr = [char for char in substring if char.isalnum()]
        i = len(c_arr)

        j = 0
        j2 = 0
        for i3 in range(i - 1):
            j3 = ord(c_arr[i3])
            b_arr = DICT
            j += j3 * b_arr[i3]
            j2 += ord(c_arr[i3]) * ord(c_arr[(i - i3) - 1]) * b_arr[i3]

        dev_pwd_key = f"{j}{j2}"
        if not dev_pwd_key:
            return None

        data_to_hash = (str2 + dev_pwd_key + str_val).encode('utf-8')

        md5_hash = hashlib.md5(data_to_hash).digest()
        hex_chars = _adp_encode_hex(md5_hash)

        str_val_bytes = str_val.encode('utf-8')
        salt_bytes = bytes([str_val_bytes[len(str_val_bytes) - 2], str_val_bytes[len(str_val_bytes) - 1]])

        descrypt = DesCrypt()
        des_part = descrypt.generate(str_val, salt_bytes)

        concat = "".join([hex_chars[1], hex_chars[4], hex_chars[5], hex_chars[7]]) + des_part

        string_buffer = concat
        for _ in range(3):
            string_buffer = _adp_shuffle(string_buffer)

        return string_buffer

    except Exception as e:
        logging.getLogger(__name__).debug("Error in generate_client_password: %s", e)
        return ""